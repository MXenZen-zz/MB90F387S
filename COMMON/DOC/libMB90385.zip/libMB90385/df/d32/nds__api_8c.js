var nds__api_8c =
[
    [ "NDSSharedData", "df/d32/nds__api_8c.html#a2c74dc586c36470b52e40f922c30d8d2", null ]
];