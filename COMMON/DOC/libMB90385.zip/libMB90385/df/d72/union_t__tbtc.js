var union_t__tbtc =
[
    [ "__pad0__", "df/d72/union_t__tbtc.html#ae2f11ba89dd3753a7970a7b7d01ee213", null ],
    [ "bit", "df/d72/union_t__tbtc.html#a5fdc811fa6d70bc7510a4d381b443a83", null ],
    [ "byte", "df/d72/union_t__tbtc.html#a909cd1fed8d6e44a86e0bddf3e5c497e", null ],
    [ "TBC", "df/d72/union_t__tbtc.html#a01036a5aeb61814f665741c0784cdc0f", null ],
    [ "TBIE", "df/d72/union_t__tbtc.html#a674d3df7267ea29c5ef1b9ab914a4ddf", null ],
    [ "TBOF", "df/d72/union_t__tbtc.html#ac87583be5dc1a1d9e0d45ba6e704eae4", null ],
    [ "TBR", "df/d72/union_t__tbtc.html#afee520c6786a7b63f937e358c4e6850b", null ]
];