var union_t__ssr =
[
    [ "BDS", "df/d25/union_t__ssr.html#a25a02582bbafe98376b9323e3adbc856", null ],
    [ "bit", "df/d25/union_t__ssr.html#a505056a8b2b165352353ce1b2aed5669", null ],
    [ "byte", "df/d25/union_t__ssr.html#acd29887a7053d05735a2c62de8fb369a", null ],
    [ "FRE", "df/d25/union_t__ssr.html#af951c35613e65f9d426887d87580290e", null ],
    [ "ORE", "df/d25/union_t__ssr.html#aa9a461731ac26785d32a90fd7217acc2", null ],
    [ "PE", "df/d25/union_t__ssr.html#a99e18c1bff268f49301a19c034d5a7e9", null ],
    [ "RDRF", "df/d25/union_t__ssr.html#ad17bf5616ad35ebbbb13091621c06cf0", null ],
    [ "RIE", "df/d25/union_t__ssr.html#ac0990c98a646b03cbe982f451c7a3669", null ],
    [ "TDRE", "df/d25/union_t__ssr.html#a4228f4cca186d88b152a113b781b4b0e", null ],
    [ "TIE", "df/d25/union_t__ssr.html#a684fdad85d489ca64e7a31933d71aad2", null ]
];