var clk__io_8h =
[
    [ "GetCLK_CKSCR", "d0/d3d/clk__io_8h.html#aeae03ad10f2f4c9dc2d218d8880dbfe6", null ],
    [ "IsCLKPLLOpClockMain", "d0/d3d/clk__io_8h.html#ae2d0a9fc07aab5413b7f2347b8abaabc", null ],
    [ "IsCLKPLLOpClockPLL", "d0/d3d/clk__io_8h.html#aacb192ab527fa63169a948bf08939e1e", null ],
    [ "IsCLKSubOpClockMain", "d0/d3d/clk__io_8h.html#acd210f1a2f1da70358e8c65c523cdd93", null ],
    [ "IsCLKSubOpClockSub", "d0/d3d/clk__io_8h.html#a34e7fbfb334f6812013f6ac5dc9e0501", null ],
    [ "SetCLK_CKSCR", "d0/d3d/clk__io_8h.html#a41095b85e8e084921400d1fc70748c23", null ],
    [ "SetCLKMultiplier", "d0/d3d/clk__io_8h.html#abebd399fa6e3b513966d305285e14b36", null ],
    [ "SetCLKOscStabWaitTime", "d0/d3d/clk__io_8h.html#a710990c8502841d76519257762fea76b", null ],
    [ "SetCLKPLLClockMain", "d0/d3d/clk__io_8h.html#a219ae0884b5a120a2985093a491fe193", null ],
    [ "SetCLKPLLClockPLL", "d0/d3d/clk__io_8h.html#a44119f54ffcb57f565367b663b47d444", null ],
    [ "SetCLKSubClockMain", "d0/d3d/clk__io_8h.html#a1e771c5bc9969be5d743234b575d6891", null ],
    [ "SetCLKSubClockSub", "d0/d3d/clk__io_8h.html#a8b4bc6b23ee7cd9836d25c9fd9d88eba", null ],
    [ "T_clkOperation", "d0/d3d/clk__io_8h.html#aed77265a724cf76ac1f6fbd26741953b", [
      [ "CLK_OP_PLL", "d0/d3d/clk__io_8h.html#aed77265a724cf76ac1f6fbd26741953ba43c28fe5f1a2d55202f933ae930d2164", null ],
      [ "CLK_OP_SUB", "d0/d3d/clk__io_8h.html#aed77265a724cf76ac1f6fbd26741953ba13cad25826e8b20ba19af100c3c5de86", null ],
      [ "CLK_OP_MAIN_SUB", "d0/d3d/clk__io_8h.html#aed77265a724cf76ac1f6fbd26741953ba324fa5c184a8aef384dc92250d02e8f1", null ],
      [ "CLK_OP_MAIN_PLL", "d0/d3d/clk__io_8h.html#aed77265a724cf76ac1f6fbd26741953ba42460feec191c7d27a3c9985879bc58d", null ]
    ] ],
    [ "T_clkOscStabWaitTime", "d0/d3d/clk__io_8h.html#ae03cfbf40dc568f6d98671149843aaec", [
      [ "CLK_WAIT_2T10", "d0/d3d/clk__io_8h.html#ae03cfbf40dc568f6d98671149843aaeca331df5facb42f585edc82b710db81daf", null ],
      [ "CLK_WAIT_2T13", "d0/d3d/clk__io_8h.html#ae03cfbf40dc568f6d98671149843aaecada9751762ca7dcc7c0215de7d563ddb1", null ],
      [ "CLK_WAIT_2T15", "d0/d3d/clk__io_8h.html#ae03cfbf40dc568f6d98671149843aaeca37700eec3c5775203ea1f4ff15b99a72", null ],
      [ "CLK_WAIT_2T17_18", "d0/d3d/clk__io_8h.html#ae03cfbf40dc568f6d98671149843aaeca7a737dad5c87e5147dc223dc7962226b", null ]
    ] ],
    [ "T_clkRate", "d0/d3d/clk__io_8h.html#ae727b82a6ee59a7cd215daa6570ea397", [
      [ "CLK_1xHCLK", "d0/d3d/clk__io_8h.html#ae727b82a6ee59a7cd215daa6570ea397a33d26ecfd4f268f4aff7bc4a1d2dee7e", null ],
      [ "CLK_2xHCLK", "d0/d3d/clk__io_8h.html#ae727b82a6ee59a7cd215daa6570ea397a2ca8ea1f30d7de84a9d16215f4b81fa2", null ],
      [ "CLK_3xHCLK", "d0/d3d/clk__io_8h.html#ae727b82a6ee59a7cd215daa6570ea397af42f4b6574bb1885613d21bbf1a02156", null ],
      [ "CLK_4xHCLK", "d0/d3d/clk__io_8h.html#ae727b82a6ee59a7cd215daa6570ea397af72c61c5c5cd3fcb895e8d8420a61de4", null ]
    ] ],
    [ "T_clkSelection", "d0/d3d/clk__io_8h.html#a0b8f41cd0c8ec30371acc6bbf337e3f1", [
      [ "CLK_SEL_PLL", "d0/d3d/clk__io_8h.html#a0b8f41cd0c8ec30371acc6bbf337e3f1a2f992570f85cf301abc77a600d278dce", null ],
      [ "CLK_SEL_SUB", "d0/d3d/clk__io_8h.html#a0b8f41cd0c8ec30371acc6bbf337e3f1a6e08122ef17fcb15623886b01a9cab55", null ],
      [ "CLK_SEL_MAIN", "d0/d3d/clk__io_8h.html#a0b8f41cd0c8ec30371acc6bbf337e3f1a2172d6fcfe8dffc7644ee72f81433b45", null ]
    ] ]
];