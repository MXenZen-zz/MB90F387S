var union_t__bvalr =
[
    [ "bit", "d0/d1a/union_t__bvalr.html#acc5d5f4d36fa724ac69f91e4aa670f33", null ],
    [ "BVAL0", "d0/d1a/union_t__bvalr.html#a161bdd397e550129afa8c4eed17905e1", null ],
    [ "BVAL1", "d0/d1a/union_t__bvalr.html#a7cdf21f9bf17c5ec5ee3a65e0b9920d6", null ],
    [ "BVAL2", "d0/d1a/union_t__bvalr.html#acd517914712469978363ebd122dc7253", null ],
    [ "BVAL3", "d0/d1a/union_t__bvalr.html#a1cae5f44be1f235d49a0489038ee4169", null ],
    [ "BVAL4", "d0/d1a/union_t__bvalr.html#a5c1fd6709bb613f2f0508049f0d65002", null ],
    [ "BVAL5", "d0/d1a/union_t__bvalr.html#a0940fa3c2914e260c841cb04fea97d93", null ],
    [ "BVAL6", "d0/d1a/union_t__bvalr.html#a7fe1a18a3774ab66ff2c439182e38d23", null ],
    [ "BVAL7", "d0/d1a/union_t__bvalr.html#ac41dd3581580de59686af5f4ce835ef0", null ],
    [ "byte", "d0/d1a/union_t__bvalr.html#a0f4654e78cfb836af81ba9645b0cade3", null ]
];