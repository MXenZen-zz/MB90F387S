var union_t__adcrlh =
[
    [ "__pad0__", "d0/dca/union_t__adcrlh.html#a49874638a3df33e901a396a5c168b803", null ],
    [ "ADCRH", "d0/dca/union_t__adcrlh.html#a9eaddf7fa9b395b94fc0cf7074e0cf52", null ],
    [ "bit", "d0/dca/union_t__adcrlh.html#ab51b506df406f10d8ea8467a2f82bacb", null ],
    [ "byte", "d0/dca/union_t__adcrlh.html#a2a0c589f7b1e01225fce42f1f602073b", null ],
    [ "CT", "d0/dca/union_t__adcrlh.html#a339468b4e59d0344a12250b084edab17", null ],
    [ "DATA10", "d0/dca/union_t__adcrlh.html#a139a28c7b3e8777ba4acbb03f1dff7b0", null ],
    [ "DATA8", "d0/dca/union_t__adcrlh.html#a0fa887a209dfd4d8f879bed27c8cd92a", null ],
    [ "S10", "d0/dca/union_t__adcrlh.html#aec67895022dc586e1977c3d9b98c9d1b", null ],
    [ "ST", "d0/dca/union_t__adcrlh.html#a532f5bd5925636bb3367cd777ba3d370", null ],
    [ "word", "d0/dca/union_t__adcrlh.html#a849cdfa3c2b82036ff0f67d8c4955cbc", null ]
];