var adc__io_8h =
[
    [ "ClearADCIRQ", "d0/de3/adc__io_8h.html#a74af5205f47b020e945f6e1919647712", null ],
    [ "DisableADCChannel", "d0/de3/adc__io_8h.html#a426b784af0fe0b935ee86e77b5c10a4b", null ],
    [ "DisableADCInterrupt", "d0/de3/adc__io_8h.html#ac2f688d85d2d69bf1ae6c95945bf0804", null ],
    [ "EnableADCChannel", "d0/de3/adc__io_8h.html#a1751978f24e159402a7255147c939c5f", null ],
    [ "EnableADCInterrupt", "d0/de3/adc__io_8h.html#a82df75ef5dce11fdef1d1502f20b2205", null ],
    [ "GetADC_ADCRH", "d0/de3/adc__io_8h.html#a01f8c9993c97a99c40a1d95ca6977dd8", null ],
    [ "GetADC_ADCSH", "d0/de3/adc__io_8h.html#a3801ff2803da4cf873d88e02517768b3", null ],
    [ "GetADC_ADCSL", "d0/de3/adc__io_8h.html#afd2b27d8ad8294b7a5417b768fb8b1cc", null ],
    [ "GetADC_ADER", "d0/de3/adc__io_8h.html#aa416825f97863b5531ad3159962b2f9d", null ],
    [ "GetADCChannelPointer", "d0/de3/adc__io_8h.html#a4005e534738d386071ba6ba86742c649", null ],
    [ "IsADC8bitDataResolution", "d0/de3/adc__io_8h.html#a8998df1e38289ebf1cffad884dbb3024", null ],
    [ "IsADConversionDone", "d0/de3/adc__io_8h.html#a94c051deb4a7daa5797a2e855c6c9e45", null ],
    [ "IsADConversionPaused", "d0/de3/adc__io_8h.html#ac13cc973778e8675b9fecc11f457c546", null ],
    [ "IsADConversionStarted", "d0/de3/adc__io_8h.html#aa97f822563266e0cd290881b9e8a30e4", null ],
    [ "ReadADC10bitData", "d0/de3/adc__io_8h.html#ad1291639e368c1b895c0cc10532b0e92", null ],
    [ "ReadADC8bitData", "d0/de3/adc__io_8h.html#a6c5d05e4c5d9535f1d5e9c390bb05ca0", null ],
    [ "SetADC10bitDataResolution", "d0/de3/adc__io_8h.html#acce1e120823971f963dc5ef5c363d803", null ],
    [ "SetADC8bitDataResolution", "d0/de3/adc__io_8h.html#a3a09b45822d3905cc1923cabac2f619b", null ],
    [ "SetADC_ADCRH", "d0/de3/adc__io_8h.html#aa3b399e7c06e223a2a0dee8bb2a65795", null ],
    [ "SetADC_ADCSH", "d0/de3/adc__io_8h.html#a6368d43fdb88f7d2a7f32ab0b8764771", null ],
    [ "SetADC_ADCSL", "d0/de3/adc__io_8h.html#a333bbd1c1fee989d5c8d9d8de55160ac", null ],
    [ "SetADC_ADER", "d0/de3/adc__io_8h.html#ac8f2f1114043a4eba7fcc089aeeb51eb", null ],
    [ "SetADCCompareTime", "d0/de3/adc__io_8h.html#a6455ca25632b164af93c27b0c79e4835", null ],
    [ "SetADCEndChannel", "d0/de3/adc__io_8h.html#aac0c56c205b3a3d5eb7fa92efb6a0aec", null ],
    [ "SetADConversionMode", "d0/de3/adc__io_8h.html#aff1c5640f5a3c146434d76857623c57a", null ],
    [ "SetADCSamplingTime", "d0/de3/adc__io_8h.html#a15ea8d7c445cfd797c8177d0b92bbcb5", null ],
    [ "SetADCStartChannel", "d0/de3/adc__io_8h.html#a3bf9e9e31dee73c10db36a2b6fc42fd5", null ],
    [ "SetADCStartTrigger", "d0/de3/adc__io_8h.html#a59ff876d7034edc9d530c37c2f94afcf", null ],
    [ "StartADC", "d0/de3/adc__io_8h.html#a0378f07a7cadbd7cd2d4dc4e485993f3", null ],
    [ "StopADC", "d0/de3/adc__io_8h.html#a7fe3c7eb576f17dfdb45789a1146a36f", null ],
    [ "T_adcCompareTime", "d0/de3/adc__io_8h.html#a94d917e303c22ad58b11f54114135202", [
      [ "ADC_CT_44T", "d0/de3/adc__io_8h.html#a94d917e303c22ad58b11f54114135202a56c130035ca60923c684f08cfabedaab", null ],
      [ "ADC_CT_66T", "d0/de3/adc__io_8h.html#a94d917e303c22ad58b11f54114135202a813dc454024b4cabccbf9244b3043bab", null ],
      [ "ADC_CT_88T", "d0/de3/adc__io_8h.html#a94d917e303c22ad58b11f54114135202a69395a61fa5062d07dbd6c90de37d51a", null ],
      [ "ADC_CT_176T", "d0/de3/adc__io_8h.html#a94d917e303c22ad58b11f54114135202ab9905e4b2afdba4bf60fd4cfc221fa29", null ]
    ] ],
    [ "T_adcConvChannel", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fd", [
      [ "ADC_AN0", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fda2b312b52fe5d414d9bd2cba051dcd72a", null ],
      [ "ADC_AN1", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fda1c51560713abb867567f99d4c78763bd", null ],
      [ "ADC_AN2", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fdacfaa570d9fd2190be56d1fc8cb23ef32", null ],
      [ "ADC_AN3", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fdadf2a7a958cab5ddfa2a8cde10bc6ab93", null ],
      [ "ADC_AN4", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fdae49a2be73668a8a80ade91a04d4024f0", null ],
      [ "ADC_AN5", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fda58f2a6c0fc96c0c60973208bd7884bb2", null ],
      [ "ADC_AN6", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fda16c1323077858412c0fcf5edb70fb371", null ],
      [ "ADC_AN7", "d0/de3/adc__io_8h.html#a6dc2dcddad0ad5cfd89f9c1aab4612fda7393eb867fdf4239ce48ae43ad6f1cb3", null ]
    ] ],
    [ "T_adcConvMode", "d0/de3/adc__io_8h.html#a91a6750788a97e2486f65d2cc04bc8ba", [
      [ "ADC_MD_SINGLE_REACTIVE", "d0/de3/adc__io_8h.html#a91a6750788a97e2486f65d2cc04bc8baa159d570f96fd9247b1ec7e711f99fa2a", null ],
      [ "ADC_MD_SINGLE_ONCE", "d0/de3/adc__io_8h.html#a91a6750788a97e2486f65d2cc04bc8baac487bd293da592f0fd8c997ea4b87757", null ],
      [ "ADC_MD_CONTINUOUS", "d0/de3/adc__io_8h.html#a91a6750788a97e2486f65d2cc04bc8baa4074e891a8f07a2275b60a81fda06ff9", null ],
      [ "ADC_MD_PAUSE_CONVERT", "d0/de3/adc__io_8h.html#a91a6750788a97e2486f65d2cc04bc8baa3a32a6b359990759e3f33809c9094b3b", null ]
    ] ],
    [ "T_adcConvOperation", "d0/de3/adc__io_8h.html#acdae4a204494cba1c76fba846f61d3b5", [
      [ "ADC_CONV_TERMINATED", "d0/de3/adc__io_8h.html#acdae4a204494cba1c76fba846f61d3b5a4e9bd21ef9c74a310f64739f6d4af0f6", null ],
      [ "ADC_CONV_OPERATING", "d0/de3/adc__io_8h.html#acdae4a204494cba1c76fba846f61d3b5a27650fbc67cf2b3813d14b77878e03ea", null ]
    ] ],
    [ "T_adcConvPause", "d0/de3/adc__io_8h.html#aef5f25a21bcaf2eae7086c643f7baf31", [
      [ "ADC_NO_PAUSE", "d0/de3/adc__io_8h.html#aef5f25a21bcaf2eae7086c643f7baf31acb187e24df6409e66ccd3b4167c55ef1", null ],
      [ "ADC_PAUSE", "d0/de3/adc__io_8h.html#aef5f25a21bcaf2eae7086c643f7baf31afcfc2930836a87f8344aa1549d86baa3", null ]
    ] ],
    [ "T_adcDataResolution", "d0/de3/adc__io_8h.html#ae8fd69ea865006086e26671fdc88b56f", [
      [ "ADC_RES_10BITS", "d0/de3/adc__io_8h.html#ae8fd69ea865006086e26671fdc88b56fad4b0b330afbeab6d70573b3d047cb390", null ],
      [ "ADC_RES_8BITS", "d0/de3/adc__io_8h.html#ae8fd69ea865006086e26671fdc88b56fa8ee658f921031b721ecd239e0632ad8f", null ]
    ] ],
    [ "T_adcInputEnable", "d0/de3/adc__io_8h.html#a920db3396fdb72283ef29d5f8cd7178a", [
      [ "ADC_INPUT_DISABLED", "d0/de3/adc__io_8h.html#a920db3396fdb72283ef29d5f8cd7178aaf900d8c6868adb3f442307bc53193645", null ],
      [ "ADC_INPUT_ENABLED", "d0/de3/adc__io_8h.html#a920db3396fdb72283ef29d5f8cd7178aaad7bbaf3102ad60a1b1af4cced7528dc", null ]
    ] ],
    [ "T_adcINTEnable", "d0/de3/adc__io_8h.html#a1bcc9a354a482461350fc5bb4c985672", [
      [ "ADC_INT_DISABLED", "d0/de3/adc__io_8h.html#a1bcc9a354a482461350fc5bb4c985672a64535c92c7c464f467ca108b6584d5ed", null ],
      [ "ADC_INT_ENABLED", "d0/de3/adc__io_8h.html#a1bcc9a354a482461350fc5bb4c985672a0295b6a81c9b3d90395e27781a63e67f", null ]
    ] ],
    [ "T_adcIRQ", "d0/de3/adc__io_8h.html#a45c21d025196126894f311b7973b97c4", [
      [ "ADC_IRQ_CLEARED", "d0/de3/adc__io_8h.html#a45c21d025196126894f311b7973b97c4a007632b281117a313774cc16e4ef26e5", null ],
      [ "ADC_IRQ_CONV_TERMINATED", "d0/de3/adc__io_8h.html#a45c21d025196126894f311b7973b97c4a8529a85ca3b738f58048997811f0ac04", null ]
    ] ],
    [ "T_adcSampleTime", "d0/de3/adc__io_8h.html#a84d34b00965ab78817449036ea054b85", [
      [ "ADC_ST_20T", "d0/de3/adc__io_8h.html#a84d34b00965ab78817449036ea054b85a8f25c8a5f4b7420612ac6007fea6e801", null ],
      [ "ADC_ST_32T", "d0/de3/adc__io_8h.html#a84d34b00965ab78817449036ea054b85a2163479764f7a63edd39e2fd19820cfe", null ],
      [ "ADC_ST_48T", "d0/de3/adc__io_8h.html#a84d34b00965ab78817449036ea054b85ac1d3ddb7c1c20c1fde00e2c398077173", null ],
      [ "ADC_ST_128T", "d0/de3/adc__io_8h.html#a84d34b00965ab78817449036ea054b85aa94709a185c3bde63252b899183535d3", null ]
    ] ],
    [ "T_adcStartTrigger", "d0/de3/adc__io_8h.html#aec77f5e78f2f45d8afd662be7aa8dad6", [
      [ "ADC_STS_SW", "d0/de3/adc__io_8h.html#aec77f5e78f2f45d8afd662be7aa8dad6a53debc54c4cd0c6ae425d43eabc7e72a", null ],
      [ "ADC_STS_SW_XTRIG", "d0/de3/adc__io_8h.html#aec77f5e78f2f45d8afd662be7aa8dad6a9d1193ef2167dcd871dce6d46814c60b", null ],
      [ "ADC_STS_SW_TMR", "d0/de3/adc__io_8h.html#aec77f5e78f2f45d8afd662be7aa8dad6a910f0a885af2e3d67d343788abf50ecf", null ],
      [ "ADC_STS_SW_XTRIG_TMR", "d0/de3/adc__io_8h.html#aec77f5e78f2f45d8afd662be7aa8dad6ac8236226b511cbc67536b92201eafe38", null ]
    ] ],
    [ "T_adcSWStart", "d0/de3/adc__io_8h.html#af2ec286b7ac2ddf0dc400ca081c239ce", [
      [ "ADC_STOP", "d0/de3/adc__io_8h.html#af2ec286b7ac2ddf0dc400ca081c239cea3ce5b3b06ffd24b358cf65efdee69f30", null ],
      [ "ADC_START", "d0/de3/adc__io_8h.html#af2ec286b7ac2ddf0dc400ca081c239cea7cfbed16e7b14cca402b036c19d69647", null ]
    ] ]
];