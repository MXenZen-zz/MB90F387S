var union_t__lpmcr =
[
    [ "__pad0__", "d0/d32/union_t__lpmcr.html#ac742290c154d37a01fa8842bb9b6bb25", null ],
    [ "bit", "d0/d32/union_t__lpmcr.html#add2d54ef4140a09676835d1b228bd7e9", null ],
    [ "bitc", "d0/d32/union_t__lpmcr.html#ac67df0bedd380b74a4b2d8a450945f1d", null ],
    [ "byte", "d0/d32/union_t__lpmcr.html#a5db6601299ae5ad0d80714450aef36f8", null ],
    [ "CG", "d0/d32/union_t__lpmcr.html#a861aadebd73289526c189a0231f07237", null ],
    [ "RST", "d0/d32/union_t__lpmcr.html#af48cb6a5d2a25c60468acab84e22700e", null ],
    [ "SLP", "d0/d32/union_t__lpmcr.html#ad1ca69f9ddf23c4dee52fa6437f26c07", null ],
    [ "SLPSTP", "d0/d32/union_t__lpmcr.html#aa465b3273ca26a90695a0e1e2c0b021d", null ],
    [ "SPL", "d0/d32/union_t__lpmcr.html#ac455880cff68182a0216df22b51b70e5", null ],
    [ "STP", "d0/d32/union_t__lpmcr.html#a9bbebb93760b6b27f084cf4b32e0e7a0", null ],
    [ "TMD", "d0/d32/union_t__lpmcr.html#a2c95afb47d61695056fd04040f126c61", null ]
];