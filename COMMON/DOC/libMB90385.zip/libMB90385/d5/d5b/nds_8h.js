var nds_8h =
[
    [ "initNDS", "d5/d5b/nds_8h.html#a557a9d1a2054c9eb666d6d6735e07ce0", null ],
    [ "manageNDSIncoming", "d5/d5b/nds_8h.html#a133f261b64b638a0ee63ecd851f45559", null ],
    [ "manageNDSOutgoing", "d5/d5b/nds_8h.html#a228adff1b29f38a35f8622244a84c48c", null ],
    [ "NDSAllocIncoming", "d5/d5b/nds_8h.html#ac1917c93133cd9cf155f13233e6d2e41", null ],
    [ "NDSAllocOutgoing", "d5/d5b/nds_8h.html#aa553c20c1f85fafdd4822fb64693047f", null ],
    [ "NDSSharedData", "d5/d5b/nds_8h.html#a2c74dc586c36470b52e40f922c30d8d2", null ]
];