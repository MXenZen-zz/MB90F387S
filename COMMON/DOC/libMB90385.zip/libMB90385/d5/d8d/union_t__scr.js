var union_t__scr =
[
    [ "AD", "d5/d8d/union_t__scr.html#aa3d5c2133007aaa92d446c78fbee3e12", null ],
    [ "bit", "d5/d8d/union_t__scr.html#ac47fc90d8c9ab1d774fcee19c30a1ea6", null ],
    [ "byte", "d5/d8d/union_t__scr.html#afaa5726924d0acded41ecc59d98b4b07", null ],
    [ "CL", "d5/d8d/union_t__scr.html#a9ab1a881e4c124324c358971434e3aa6", null ],
    [ "P", "d5/d8d/union_t__scr.html#a76ad3c8e846b3361953c24602bed70f6", null ],
    [ "PEN", "d5/d8d/union_t__scr.html#aa3901fdda3a87dd0b65e19597a6ce6bf", null ],
    [ "REC", "d5/d8d/union_t__scr.html#a4a401a7f7577516bba8e5a8d8df86b3b", null ],
    [ "RXE", "d5/d8d/union_t__scr.html#a82427dbff4d056c6f40bd81310ed0e50", null ],
    [ "SBL", "d5/d8d/union_t__scr.html#ace4f068334882f016038f691d89196e1", null ],
    [ "TXE", "d5/d8d/union_t__scr.html#a76c92ba9a0bec2df31c225a78681308c", null ]
];