var port__io_8h =
[
    [ "GetPORT_DDR1", "d5/d2a/port__io_8h.html#a40de82f9eacef87db794949554c3ac34", null ],
    [ "GetPORT_DDR2", "d5/d2a/port__io_8h.html#a697997938743a5af922ed0a6c1c2b102", null ],
    [ "GetPORT_DDR3", "d5/d2a/port__io_8h.html#afd1fa484442cd8a3c8befe2b4203a003", null ],
    [ "GetPORT_DDR4", "d5/d2a/port__io_8h.html#aa307bd551e8734fba1c6803749a3f87c", null ],
    [ "GetPORT_DDR5", "d5/d2a/port__io_8h.html#acac352f35a4a61bd89b6a627e21023db", null ],
    [ "GetPORT_PDR1", "d5/d2a/port__io_8h.html#ad9e737c4d7f4388b14e47f8bbf61bc23", null ],
    [ "GetPORT_PDR2", "d5/d2a/port__io_8h.html#a7d34b79da761323839238f34cc85380a", null ],
    [ "GetPORT_PDR3", "d5/d2a/port__io_8h.html#a55e81dd0678e3da04d818b4b27f8ed66", null ],
    [ "GetPORT_PDR4", "d5/d2a/port__io_8h.html#a1700a5a0eea77068ae0c127a5ab8ab79", null ],
    [ "GetPORT_PDR5", "d5/d2a/port__io_8h.html#a4aabdfc3b09165c2cd7eb97d060957c5", null ],
    [ "SetPORT_DDR1", "d5/d2a/port__io_8h.html#af58b234ee59e52fd15b4907affc5875a", null ],
    [ "SetPORT_DDR2", "d5/d2a/port__io_8h.html#af565fe2fee5d7d5343dec2897973379d", null ],
    [ "SetPORT_DDR3", "d5/d2a/port__io_8h.html#a54e61d7d38ed230129efd5dd0f4774d5", null ],
    [ "SetPORT_DDR4", "d5/d2a/port__io_8h.html#af4092ebee758c8ef9d9aac1d22e342d2", null ],
    [ "SetPORT_DDR5", "d5/d2a/port__io_8h.html#ab16dc9007019beb2e76c4a9cc2b2e061", null ],
    [ "SetPORT_PDR1", "d5/d2a/port__io_8h.html#aabdfafc19221e6fc1cd840023e2805c0", null ],
    [ "SetPORT_PDR2", "d5/d2a/port__io_8h.html#a644c3f78ce028d432c62a45dfa88e44a", null ],
    [ "SetPORT_PDR3", "d5/d2a/port__io_8h.html#aa9d9df75bc0625dc4eea76644dcce0a0", null ],
    [ "SetPORT_PDR4", "d5/d2a/port__io_8h.html#a99d9b5743dc820e20500343b6e11616f", null ],
    [ "SetPORT_PDR5", "d5/d2a/port__io_8h.html#a134a4b688c97fa019c6704d20dae94d3", null ],
    [ "T_portDirection", "d5/d2a/port__io_8h.html#a2a04fc10744139991fc487304ae02bef", [
      [ "PORT_INPUT", "d5/d2a/port__io_8h.html#a2a04fc10744139991fc487304ae02befa0b5620a49d84dd316a3e87a6974cf230", null ],
      [ "PORT_OUTPUT", "d5/d2a/port__io_8h.html#a2a04fc10744139991fc487304ae02befa49ccc9fd2797ed1a153996a13aadfcd5", null ]
    ] ],
    [ "T_portLevel", "d5/d2a/port__io_8h.html#ab420b3170ce607d3c4db563bec9c37bb", [
      [ "PORT_LOW", "d5/d2a/port__io_8h.html#ab420b3170ce607d3c4db563bec9c37bba8e75db57b0443f90469c38fe0269c884", null ],
      [ "PORT_HIGH", "d5/d2a/port__io_8h.html#ab420b3170ce607d3c4db563bec9c37bba606dd54613df09eb7de70181e591e7bd", null ]
    ] ]
];