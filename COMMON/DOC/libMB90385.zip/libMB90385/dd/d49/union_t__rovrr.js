var union_t__rovrr =
[
    [ "bit", "dd/d49/union_t__rovrr.html#a2161f35a9d5870ecc465da5ddfe61e55", null ],
    [ "byte", "dd/d49/union_t__rovrr.html#ac6106f54297ec8e75252677773be4bea", null ],
    [ "ROVR0", "dd/d49/union_t__rovrr.html#aed0009f04c0f40df381b045ed4aa3735", null ],
    [ "ROVR1", "dd/d49/union_t__rovrr.html#adfb0b6c5048c780b5842cb6f17b7d13f", null ],
    [ "ROVR2", "dd/d49/union_t__rovrr.html#a7cdebe325ae82019ba9ddab158acaabe", null ],
    [ "ROVR3", "dd/d49/union_t__rovrr.html#a49323dacda87f26bf3833e7c3ead82d6", null ],
    [ "ROVR4", "dd/d49/union_t__rovrr.html#af6aafd1a6fa20cc9b4d9de80f38dec25", null ],
    [ "ROVR5", "dd/d49/union_t__rovrr.html#a09a4dca2b008505d7cdd003955a4b162", null ],
    [ "ROVR6", "dd/d49/union_t__rovrr.html#ab47cdd0c80a19641eab0fbccb593d4aa", null ],
    [ "ROVR7", "dd/d49/union_t__rovrr.html#aa7b379c3d217270af25274cf3478e6c2", null ]
];