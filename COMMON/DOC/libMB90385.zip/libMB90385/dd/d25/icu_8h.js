var icu_8h =
[
    [ "T_icuISRHook", "dd/d25/icu_8h.html#a49b27a3d12681291ffa93aaf6528606f", null ],
    [ "T_icuChannel", "dd/d25/icu_8h.html#ab91465c2b9d7a93578ee8de5b34a66e6", [
      [ "ICU_CH0", "dd/d25/icu_8h.html#ab91465c2b9d7a93578ee8de5b34a66e6ad1e9480833e7a698452ef62564c1a5dd", null ],
      [ "ICU_CH1", "dd/d25/icu_8h.html#ab91465c2b9d7a93578ee8de5b34a66e6a6f4ede523804d0f7b6c710478cbac8fe", null ],
      [ "ICU_CH2", "dd/d25/icu_8h.html#ab91465c2b9d7a93578ee8de5b34a66e6ae572814cf642f36473e83a07f1dee482", null ],
      [ "ICU_CH3", "dd/d25/icu_8h.html#ab91465c2b9d7a93578ee8de5b34a66e6a3f8919c171ca3fdf09df08ed601d992a", null ]
    ] ],
    [ "attachICU", "dd/d25/icu_8h.html#a27b5ce8fc6de7c256be839c093a7771d", null ],
    [ "detachICU", "dd/d25/icu_8h.html#a7ec73d99b67b13404998bb6d6881b32b", null ],
    [ "ICU0_IRQHandler", "dd/d25/icu_8h.html#a9ce96af49d94cd496b0effd95fb82ca5", null ],
    [ "ICU1_IRQHandler", "dd/d25/icu_8h.html#a66d46fc3d919a0b322907d33dfcddbfd", null ],
    [ "ICU23_IRQHandler", "dd/d25/icu_8h.html#a3a5f249181c1571c2536f42a7ed9ff25", null ],
    [ "initICU", "dd/d25/icu_8h.html#a7e42404c5b0e74ef4bd6a243b45bc05e", null ],
    [ "PRIO_ICU0_ISR", "dd/d25/icu_8h.html#a183908d4e87f65fb89ac07ea363357c9", null ],
    [ "PRIO_ICU1_ISR", "dd/d25/icu_8h.html#a37ef41d5ec936fcbcfd5b55be1b5f753", null ],
    [ "PRIO_ICU23_ISR", "dd/d25/icu_8h.html#ae2c58a6c802fbe0e9dfb1c5a72e854e5", null ]
];