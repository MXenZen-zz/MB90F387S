var icu__io_8h =
[
    [ "ClearICU0DetectedEdge", "dd/daa/icu__io_8h.html#a11333eeb5d196b1494e790a5f7f639bf", null ],
    [ "ClearICU1DetectedEdge", "dd/daa/icu__io_8h.html#acdcb4b3de857001055e2af9b2667942b", null ],
    [ "ClearICU2DetectedEdge", "dd/daa/icu__io_8h.html#a642222a13f61c792f76cf4d535766f13", null ],
    [ "ClearICU3DetectedEdge", "dd/daa/icu__io_8h.html#adfa76a4466c97fae58fde73d08332f2b", null ],
    [ "DisableICU0Interrupt", "dd/daa/icu__io_8h.html#ac694d52d63013c69e6f78599e7a159fc", null ],
    [ "DisableICU1Interrupt", "dd/daa/icu__io_8h.html#aac2360da03e0f14dcab3b05b296763e8", null ],
    [ "DisableICU2Interrupt", "dd/daa/icu__io_8h.html#a2c7f355c23af59cb72b9144b843d1ca2", null ],
    [ "DisableICU3Interrupt", "dd/daa/icu__io_8h.html#a0f13362bdd55457864f98f384e2b0e7a", null ],
    [ "EnableICU0Interrupt", "dd/daa/icu__io_8h.html#a89a0eacdb50f5c79f6ee78112ade25c5", null ],
    [ "EnableICU1Interrupt", "dd/daa/icu__io_8h.html#af3395d0b60e009443a33cbc5411cf76c", null ],
    [ "EnableICU2Interrupt", "dd/daa/icu__io_8h.html#a41bbcd11f8a41c349a801693ca072af8", null ],
    [ "EnableICU3Interrupt", "dd/daa/icu__io_8h.html#a17151173a2766cccc442ae2f0031f243", null ],
    [ "GetICU_ICS01", "dd/daa/icu__io_8h.html#aefb0c025fc62b1a3343837d211d4b755", null ],
    [ "GetICU_ICS23", "dd/daa/icu__io_8h.html#a0779620b1a084a27c90dd97627f03df4", null ],
    [ "IsICU0IRQActive", "dd/daa/icu__io_8h.html#a77a7eb7643eb476ecbac6b744f4d704c", null ],
    [ "IsICU1IRQActive", "dd/daa/icu__io_8h.html#a5c14279ae43155709489d5663a974306", null ],
    [ "IsICU2IRQActive", "dd/daa/icu__io_8h.html#afeac3f37cf99f4eba8d2e5fe8d324b08", null ],
    [ "IsICU3IRQActive", "dd/daa/icu__io_8h.html#aee30b4ef74cf4a2ab59d734ba6570310", null ],
    [ "ReadICU0Data", "dd/daa/icu__io_8h.html#ae2fd2118347c07bde4e479b3194189a9", null ],
    [ "ReadICU1Data", "dd/daa/icu__io_8h.html#a060fd05e64f12f3dbbb73085580171d3", null ],
    [ "ReadICU2Data", "dd/daa/icu__io_8h.html#a02113aeb7600993f6200df1d7ac4567d", null ],
    [ "ReadICU3Data", "dd/daa/icu__io_8h.html#a16d9e730a918594b7d5535b1209c8483", null ],
    [ "SetICU0InputCaptureEdge", "dd/daa/icu__io_8h.html#ac30607ed4ed0fbb0af87d3c409d2f8f5", null ],
    [ "SetICU1InputCaptureEdge", "dd/daa/icu__io_8h.html#a1a20bd79535e2136be57dd049de7fcf3", null ],
    [ "SetICU2InputCaptureEdge", "dd/daa/icu__io_8h.html#a296c242a12bcbffdb50b91261a5c351e", null ],
    [ "SetICU3InputCaptureEdge", "dd/daa/icu__io_8h.html#ae4cadbeee15092f795fa48175247828d", null ],
    [ "SetICU_ICS01", "dd/daa/icu__io_8h.html#af3b7d6330a3b2bfd7ec7f5843092c43f", null ],
    [ "SetICU_ICS23", "dd/daa/icu__io_8h.html#a67df9f78658b8706e054d5090e747968", null ],
    [ "T_icuDetectEdge", "dd/daa/icu__io_8h.html#aad694f6ddd347f85b1077ae3bd81c5e4", [
      [ "ICU_DETECT_NONE", "dd/daa/icu__io_8h.html#aad694f6ddd347f85b1077ae3bd81c5e4ad7ce79bc09190351cbafb1dbcbacb3a4", null ],
      [ "ICU_DETECT_RISE", "dd/daa/icu__io_8h.html#aad694f6ddd347f85b1077ae3bd81c5e4aa2a9ae31b1d27f33569be7782f021280", null ],
      [ "ICU_DETECT_FALL", "dd/daa/icu__io_8h.html#aad694f6ddd347f85b1077ae3bd81c5e4acc56fb2e54cc967d66ffd1e9a6d38991", null ],
      [ "ICU_DETECT_BOTH", "dd/daa/icu__io_8h.html#aad694f6ddd347f85b1077ae3bd81c5e4a1fc8e1c69edf54dbfd9b49d220fd0a2a", null ]
    ] ],
    [ "T_icuINTEnable", "dd/daa/icu__io_8h.html#a0115d2608d24ad93440fc972e65de699", [
      [ "ICU_INT_DISABLED", "dd/daa/icu__io_8h.html#a0115d2608d24ad93440fc972e65de699a18ef89839e75d98dbda121d9dbf77859", null ],
      [ "ICU_INT_ENABLED", "dd/daa/icu__io_8h.html#a0115d2608d24ad93440fc972e65de699a5f629b87dbd2f178d8daf74b99477d1f", null ]
    ] ],
    [ "T_icuIRQ", "dd/daa/icu__io_8h.html#acbc18facb0f0e9789eeda2ba6952c81f", [
      [ "ICU_IRQ_CLEARED", "dd/daa/icu__io_8h.html#acbc18facb0f0e9789eeda2ba6952c81fa11343a493791400750ba0382dff3c8cb", null ],
      [ "ICU_IRQ_DETECTED", "dd/daa/icu__io_8h.html#acbc18facb0f0e9789eeda2ba6952c81fa65e3c714b282ccfa09048afe989caf65", null ]
    ] ]
];