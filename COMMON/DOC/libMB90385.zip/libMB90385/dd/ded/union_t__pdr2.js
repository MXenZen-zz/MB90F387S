var union_t__pdr2 =
[
    [ "bit", "dd/ded/union_t__pdr2.html#acab46a823042aa00a83039ed357937eb", null ],
    [ "byte", "dd/ded/union_t__pdr2.html#a38479cdaecfe13420698bd446ab99987", null ],
    [ "P20", "dd/ded/union_t__pdr2.html#a4c7a2d44440785da0a988ef1339063d6", null ],
    [ "P21", "dd/ded/union_t__pdr2.html#a5943b604e5103366cd3255527855d5eb", null ],
    [ "P22", "dd/ded/union_t__pdr2.html#a70f82b4da403053909bf69eacd16b078", null ],
    [ "P23", "dd/ded/union_t__pdr2.html#a754439102d781458c8e6c02993468eff", null ],
    [ "P24", "dd/ded/union_t__pdr2.html#a21efdec64953301c770d6b5b88c3bd2e", null ],
    [ "P25", "dd/ded/union_t__pdr2.html#a37821b23819ea1dd94375331d19f4bad", null ],
    [ "P26", "dd/ded/union_t__pdr2.html#a02195e00a57c6bee3ffff7bf3e92fcb6", null ],
    [ "P27", "dd/ded/union_t__pdr2.html#aff6e4bb5667098883e91712ee14f12e2", null ]
];