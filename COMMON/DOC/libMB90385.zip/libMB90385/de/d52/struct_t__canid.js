var struct_t__canid =
[
    [ "DLCR", "de/d52/struct_t__canid.html#aeaa1939f45f7a3fc19c55f9fc363336b", null ],
    [ "DTR", "de/d52/struct_t__canid.html#aea771b61b228fb51be7e232b41026c3e", null ],
    [ "IDR", "de/d52/struct_t__canid.html#affecd6424fa9bcc94ca6b6ff437973a1", null ],
    [ "RAM", "de/d52/struct_t__canid.html#a3d751ea2afb01ef85e33e98350e48d6c", null ]
];