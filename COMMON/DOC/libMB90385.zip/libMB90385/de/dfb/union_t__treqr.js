var union_t__treqr =
[
    [ "bit", "de/dfb/union_t__treqr.html#ae84847e4838835dd4bd9f1ad54eedb22", null ],
    [ "byte", "de/dfb/union_t__treqr.html#afc901f8ff0b179789185c49993b8fe45", null ],
    [ "TREQ0", "de/dfb/union_t__treqr.html#ad3eb992c9aed7691acbb777f9fb077cc", null ],
    [ "TREQ1", "de/dfb/union_t__treqr.html#a6616b6045d408863c5d94d45f4c0805b", null ],
    [ "TREQ2", "de/dfb/union_t__treqr.html#a1688bb00a2262563de06e0a51d1ada15", null ],
    [ "TREQ3", "de/dfb/union_t__treqr.html#ae0b3f9edb413179c125a0950ddb258f7", null ],
    [ "TREQ4", "de/dfb/union_t__treqr.html#a54c54e8e6a7ccae8cd11fc65bfb293a3", null ],
    [ "TREQ5", "de/dfb/union_t__treqr.html#a15b09a37aed4de9848129cc1e90f1fca", null ],
    [ "TREQ6", "de/dfb/union_t__treqr.html#afe786c759537d0bbaefac8f155273f0c", null ],
    [ "TREQ7", "de/dfb/union_t__treqr.html#aedf9634030572300fcd153c0653d8a6f", null ]
];