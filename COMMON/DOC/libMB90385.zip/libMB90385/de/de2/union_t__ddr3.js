var union_t__ddr3 =
[
    [ "bit", "de/de2/union_t__ddr3.html#a8b928fab16651cdd341b0a8f098265a3", null ],
    [ "byte", "de/de2/union_t__ddr3.html#ada3c8a50945862263a442ce11e800ad1", null ],
    [ "D30", "de/de2/union_t__ddr3.html#ad8b2280878cc0fc698e98c6c022ea6c2", null ],
    [ "D31", "de/de2/union_t__ddr3.html#a27a2809fc20dae697d941d2892a88172", null ],
    [ "D32", "de/de2/union_t__ddr3.html#ab1821d49d46ea52b4810a0e89cec95d4", null ],
    [ "D33", "de/de2/union_t__ddr3.html#a5643e8578e1b81a39af3d1d7bb4bf110", null ],
    [ "D34", "de/de2/union_t__ddr3.html#a54b32abc18a5c9583f70ccabba2a3bb3", null ],
    [ "D35", "de/de2/union_t__ddr3.html#a99f7c3968ce0a110b427a2930d5ae9bd", null ],
    [ "D36", "de/de2/union_t__ddr3.html#a549b720b48bed1fda5d1005478b00b22", null ],
    [ "D37", "de/de2/union_t__ddr3.html#ad95a49d32e89b0f5fc5deb586b10bd3b", null ]
];