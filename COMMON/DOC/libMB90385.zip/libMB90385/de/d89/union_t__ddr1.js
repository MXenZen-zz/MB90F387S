var union_t__ddr1 =
[
    [ "bit", "de/d89/union_t__ddr1.html#a06dc1e5e166c5824f4837a3c5ede576e", null ],
    [ "byte", "de/d89/union_t__ddr1.html#af6d41ea41e7b63ef424bcd33db4cde24", null ],
    [ "D10", "de/d89/union_t__ddr1.html#a6b6b8eb771b378bd87f8612075cf9286", null ],
    [ "D11", "de/d89/union_t__ddr1.html#a29b0c00a7e9dd1dcac96b12f061515c0", null ],
    [ "D12", "de/d89/union_t__ddr1.html#a267d467b1dc6ee5dad11086b7e185bba", null ],
    [ "D13", "de/d89/union_t__ddr1.html#a0371bfac05192ca680f46bc8229483b1", null ],
    [ "D14", "de/d89/union_t__ddr1.html#ab0a428d768f7e84063ed14518e9a0910", null ],
    [ "D15", "de/d89/union_t__ddr1.html#af9775340bbc234de090099859dd386a3", null ],
    [ "D16", "de/d89/union_t__ddr1.html#a7a91c4fef20d787309399ddc344b4da3", null ],
    [ "D17", "de/d89/union_t__ddr1.html#aeaef0b5861c56778d44e2c8e5dccf3dd", null ]
];