var union_t__pdr1 =
[
    [ "bit", "de/d83/union_t__pdr1.html#a01399e5e0dd158c32db9e832a8fa9ab0", null ],
    [ "byte", "de/d83/union_t__pdr1.html#a0c07a4bc4b030f3fad61dacabcd7b028", null ],
    [ "P10", "de/d83/union_t__pdr1.html#a4b32033e7e1ce2d01597d5867e429ad4", null ],
    [ "P11", "de/d83/union_t__pdr1.html#a85427ffe3f4c4d6e77961270efe1c946", null ],
    [ "P12", "de/d83/union_t__pdr1.html#a1480cabf7a91991188b321856a73e5d2", null ],
    [ "P13", "de/d83/union_t__pdr1.html#a84464e140055881f55e8b4db323393c2", null ],
    [ "P14", "de/d83/union_t__pdr1.html#af6c6ea76c36650625f612145b5918af7", null ],
    [ "P15", "de/d83/union_t__pdr1.html#a8a78f99660a6eb6340ee5c9b7ff859c3", null ],
    [ "P16", "de/d83/union_t__pdr1.html#a5cab8388520863d905b43820b01cc612", null ],
    [ "P17", "de/d83/union_t__pdr1.html#a206a1923d42ea0e9958654c9984857a7", null ]
];