var union_t__eirr =
[
    [ "__pad0__", "de/da5/union_t__eirr.html#a2ec855ff4a8b46cc58bbf6ce11596184", null ],
    [ "bit", "de/da5/union_t__eirr.html#a8d35df91e8d6a0e2ca357d753e194f92", null ],
    [ "byte", "de/da5/union_t__eirr.html#acbbbc567da333e39825e996dbbff39e9", null ],
    [ "ER0", "de/da5/union_t__eirr.html#ac41e9d283dbba7e51b0c82789c80fe1b", null ],
    [ "ER4", "de/da5/union_t__eirr.html#adc609dd90285623df3eb3a45b2af5e66", null ],
    [ "ER5", "de/da5/union_t__eirr.html#a6bf357e0e9126385b641d98085098a73", null ],
    [ "ER6", "de/da5/union_t__eirr.html#ac8bfdc0dfa4175ad28770effb3edaa32", null ],
    [ "ER7", "de/da5/union_t__eirr.html#a29bfc3e7c631cdfb103c0c492ec9bfd0", null ]
];