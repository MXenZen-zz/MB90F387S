var lpm__io_8h =
[
    [ "GetLPM_LPMCR", "d6/d4e/lpm__io_8h.html#a4baad012d55e14db447fcd81cbe5f83d", null ],
    [ "LPMConfig", "d6/d4e/lpm__io_8h.html#a4afbeaaef557476ed4f10fb46337d15e", null ],
    [ "LPMHalt0Cycle", "d6/d4e/lpm__io_8h.html#ab092927ba8e4e4d394492ed1b5727762", null ],
    [ "LPMHalt16Cycles", "d6/d4e/lpm__io_8h.html#ae2c40e7c4458895ce97229f5e5824f01", null ],
    [ "LPMHalt32Cycles", "d6/d4e/lpm__io_8h.html#aa9cca6fdd3192cd7fab0740d7aae95e7", null ],
    [ "LPMHalt8Cycles", "d6/d4e/lpm__io_8h.html#a3ab1c5ac0258b04d7faa5b8025b13bc6", null ],
    [ "LPMReset", "d6/d4e/lpm__io_8h.html#a59ae9c66e60fc9179763b895e29f063e", null ],
    [ "LPMSleepMode", "d6/d4e/lpm__io_8h.html#af412d5b09290ddbc3fd1fff3315ac26c", null ],
    [ "LPMStopModeHeldIO", "d6/d4e/lpm__io_8h.html#a31d6d357cbf39b9372742a4199a1c894", null ],
    [ "LPMStopModeHiZ", "d6/d4e/lpm__io_8h.html#a3e7304998355796e0b28979870fdb15d", null ],
    [ "LPMTBTModeHeldIO", "d6/d4e/lpm__io_8h.html#a1fdc477ede033f510154d12731dcc367", null ],
    [ "LPMTBTModeHiZ", "d6/d4e/lpm__io_8h.html#adcc753a370e9cf3dd2d1bebaff462b72", null ]
];