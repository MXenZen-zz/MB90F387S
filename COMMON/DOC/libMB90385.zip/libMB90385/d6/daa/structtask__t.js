var structtask__t =
[
    [ "hiPrio", "d6/daa/structtask__t.html#aeb0fa4596c1c611a53d670883f0d3210", null ],
    [ "nextTask", "d6/daa/structtask__t.html#ae21f8368d222198a964d5142c4af6b3f", null ],
    [ "nextTime", "d6/daa/structtask__t.html#a595ead58b4182d4eabc1c4331217645a", null ],
    [ "properties", "d6/daa/structtask__t.html#ad3eded6af891c7cbccbf4a0ac3fe80d0", null ],
    [ "state", "d6/daa/structtask__t.html#a74173fc51212247f866df5f08fb72768", null ]
];