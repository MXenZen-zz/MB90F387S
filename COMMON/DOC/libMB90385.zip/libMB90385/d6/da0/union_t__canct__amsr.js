var union_t__canct__amsr =
[
    [ "AMS0", "d6/da0/union_t__canct__amsr.html#a47488983d2190b426187e83a2fa1e97a", null ],
    [ "AMS1", "d6/da0/union_t__canct__amsr.html#ab91ac3e501b599320a7e31a69031b276", null ],
    [ "AMS2", "d6/da0/union_t__canct__amsr.html#a179ed2429b0a1af6ac95f2d589d5943c", null ],
    [ "AMS3", "d6/da0/union_t__canct__amsr.html#ad96c683ccd85d8a0bb816023b7330c45", null ],
    [ "AMS4", "d6/da0/union_t__canct__amsr.html#aa54bc94e8d47e33c1c7c0bd96ba5aa3a", null ],
    [ "AMS5", "d6/da0/union_t__canct__amsr.html#a93cc973c5a4666f63ea2454b5da9cc63", null ],
    [ "AMS6", "d6/da0/union_t__canct__amsr.html#a9e3f8310516864210151dce26aa8a924", null ],
    [ "AMS7", "d6/da0/union_t__canct__amsr.html#a2a8cf27095016518e4ca2c7c0cf0e63a", null ],
    [ "bit", "d6/da0/union_t__canct__amsr.html#a303ea2a50905c0f85b74ab2d01239c65", null ],
    [ "word", "d6/da0/union_t__canct__amsr.html#ab5d2d13c2f9af47c5dbbb6aed0a999a8", null ]
];