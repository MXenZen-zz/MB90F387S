var union_t__ddr5 =
[
    [ "bit", "d6/d08/union_t__ddr5.html#a1b640d11427edb5dfc6686aec4f9fa8d", null ],
    [ "byte", "d6/d08/union_t__ddr5.html#a74db3a9437d4ddf28c2a8d466c44a5b0", null ],
    [ "D50", "d6/d08/union_t__ddr5.html#a5363968c04a8bc3d1f5a84f07ccc154b", null ],
    [ "D51", "d6/d08/union_t__ddr5.html#a062da87e9e8964012d5875b9d98ae61c", null ],
    [ "D52", "d6/d08/union_t__ddr5.html#ad052aad60f588b8d44935fb371ec4e8d", null ],
    [ "D53", "d6/d08/union_t__ddr5.html#a9bcc4149fc77e8e9ae6465c1dc1d9aef", null ],
    [ "D54", "d6/d08/union_t__ddr5.html#a8cc562016c2fcb303094b8c65083329b", null ],
    [ "D55", "d6/d08/union_t__ddr5.html#a1f3c3e0bba1440ca0835cfb90e650921", null ],
    [ "D56", "d6/d08/union_t__ddr5.html#ab75493b51298a3efa300cd8627ab657c", null ],
    [ "D57", "d6/d08/union_t__ddr5.html#a8f855a71a3aa8845388dd032cf169beb", null ]
];