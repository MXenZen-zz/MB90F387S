var ppg_8h =
[
    [ "T_ppgChannel", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008c", [
      [ "PPG_CH0", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca92204f1ea7fe6a06a735c46bcb555b24", null ],
      [ "PPG_CH1", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca29816ba99612d95f7a6f1efba8951197", null ],
      [ "PPG_CH2", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca58011415a466de222226aa9243539d2c", null ],
      [ "PPG_CH3", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca289a10759e0cfd7eefa4db9c631c9a0f", null ],
      [ "PPG_CH01", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca98d20b3898b4f8d652dd9a6a73ab9b3c", null ],
      [ "PPG_CH23", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca05d757a0f65e3585df254fee16903bdb", null ],
      [ "PPG_CH01_CH0", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca17faa610365d8f1cb7d445ed91f0e2e3", null ],
      [ "PPG_CH01_CH1", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008caee92ca7061d2dbb81655faf9fa02b54d", null ],
      [ "PPG_CH23_CH2", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca140a1eaa6e9c7d0fb21e2b488acae943", null ],
      [ "PPG_CH23_CH3", "d6/da6/ppg_8h.html#a0cc523a7bea916303ffa8e13bb45008ca1f9fb950df08adb3a96cef31d92e695f", null ]
    ] ],
    [ "haltPPGTimer", "d6/da6/ppg_8h.html#a210fb1cd99c065480a4eb9b9e2d6a18f", null ],
    [ "initPPG", "d6/da6/ppg_8h.html#aa2d7d0bae567ce944197540ecca2a786", null ],
    [ "PPG01_IRQHandler", "d6/da6/ppg_8h.html#acadf4b9342f3171081d8984f3564f942", null ],
    [ "PPG23_IRQHandler", "d6/da6/ppg_8h.html#a539f804ddc053c427289bf2d85d84784", null ],
    [ "pulseOutByFrequency", "d6/da6/ppg_8h.html#addde6f607504e665ab1b9ba8a8e3d192", null ],
    [ "pulseOutByPeriod", "d6/da6/ppg_8h.html#a27bae541c58af1ef7985c11c1b5bb26f", null ],
    [ "runPPGTimer", "d6/da6/ppg_8h.html#a5d1efc40f4f8017eda36ba39e1c4b804", null ],
    [ "setupPPGTimer", "d6/da6/ppg_8h.html#a76c56abbb450cf91e5ebe136e42f315a", null ],
    [ "startPPG", "d6/da6/ppg_8h.html#ae5f515b8b29304bdd21e51033e929b92", null ],
    [ "stopPPG", "d6/da6/ppg_8h.html#a07bc87a3fe3755ee910d56b172640f96", null ],
    [ "PRIO_PPG01_ISR", "d6/da6/ppg_8h.html#ae8b4b352fd1dd0435325f36978d917f2", null ],
    [ "PRIO_PPG23_ISR", "d6/da6/ppg_8h.html#afc31462d9558a48623f71255f6c62347", null ]
];