var union_t__canct__btr =
[
    [ "__pad0__", "d6/d69/union_t__canct__btr.html#a52df34720999bdc35f5a4f90230749a0", null ],
    [ "bit", "d6/d69/union_t__canct__btr.html#a51726b584c9e2b329c2834e6ab700eab", null ],
    [ "PSC", "d6/d69/union_t__canct__btr.html#abd440463b023d904dce22958208a4f74", null ],
    [ "RSJ", "d6/d69/union_t__canct__btr.html#a7d415d721dc7c772defca3c2e77fa028", null ],
    [ "TS1", "d6/d69/union_t__canct__btr.html#a534c6f883feb6296f2d80bbcc324c7af", null ],
    [ "TS2", "d6/d69/union_t__canct__btr.html#aa17f87ef5d126b50523eff8a7d84342e", null ],
    [ "word", "d6/d69/union_t__canct__btr.html#a56b8755eab06a50228417e2d62ff5d58", null ]
];