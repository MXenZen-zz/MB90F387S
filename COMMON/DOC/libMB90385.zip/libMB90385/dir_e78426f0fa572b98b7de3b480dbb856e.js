var dir_e78426f0fa572b98b7de3b480dbb856e =
[
    [ "idle_api.c", "d2/dc3/idle__api_8c.html", "d2/dc3/idle__api_8c" ],
    [ "timer_api.c", "d3/d5b/timer__api_8c.html", "d3/d5b/timer__api_8c" ]
];