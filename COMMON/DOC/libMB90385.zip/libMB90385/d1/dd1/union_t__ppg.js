var union_t__ppg =
[
    [ "__pad0__", "d1/dd1/union_t__ppg.html#acde279cb31d89ca4a858d6ed26ba60ce", null ],
    [ "bit", "d1/dd1/union_t__ppg.html#a6b6192b30fe0633c9920f044b0964e79", null ],
    [ "byte", "d1/dd1/union_t__ppg.html#a3992930923df1aca85c3fb4aecbe2fdb", null ],
    [ "PCM", "d1/dd1/union_t__ppg.html#a3b32699ab98d6070fa23e4f9f344697c", null ],
    [ "PCS", "d1/dd1/union_t__ppg.html#a097b585103fe81c1dc8c71278dc9410f", null ]
];