var exi__io_8h =
[
    [ "ClearEXI0IRQ", "d1/d54/exi__io_8h.html#a7866319d63a6e833ba5a04fdde5b1d4a", null ],
    [ "ClearEXI4IRQ", "d1/d54/exi__io_8h.html#adc434dd51ce17cc8a7e7f422b948a018", null ],
    [ "ClearEXI5IRQ", "d1/d54/exi__io_8h.html#a271c93ecdef11dff00631f048377a7e6", null ],
    [ "ClearEXI6IRQ", "d1/d54/exi__io_8h.html#acc03e9943515bbe350b86f5a69c6b65b", null ],
    [ "ClearEXI7IRQ", "d1/d54/exi__io_8h.html#a9f227cd9f4fcacd2cb17ad8f55af161f", null ],
    [ "DisableEXI0", "d1/d54/exi__io_8h.html#a5bd535017e80d60356a0aae45a38216a", null ],
    [ "DisableEXI4", "d1/d54/exi__io_8h.html#ab4d0f9090c616de000e55b2cfe9d3bd4", null ],
    [ "DisableEXI5", "d1/d54/exi__io_8h.html#a09a76ed50be35a8a674b82ea7bc8cd1a", null ],
    [ "DisableEXI6", "d1/d54/exi__io_8h.html#a4c6dcbf5a112b29df9b1d2a07adfdbac", null ],
    [ "DisableEXI7", "d1/d54/exi__io_8h.html#aeba06832033163a6fddb83bc31d55902", null ],
    [ "EnableEXI0", "d1/d54/exi__io_8h.html#adf3d145e667652c01280ee673d23c3fa", null ],
    [ "EnableEXI4", "d1/d54/exi__io_8h.html#ab07842283a3a903ff983edbd8063ad9a", null ],
    [ "EnableEXI5", "d1/d54/exi__io_8h.html#a3872335fd660f0a57509b4213566d62e", null ],
    [ "EnableEXI6", "d1/d54/exi__io_8h.html#a3ae71505ca21fcf2466b874c58c99452", null ],
    [ "EnableEXI7", "d1/d54/exi__io_8h.html#a81abe2b91786f039f96689b040406196", null ],
    [ "GetEXI_EIRR", "d1/d54/exi__io_8h.html#a114a65682a2578d499ac0bc84aafa81f", null ],
    [ "GetEXI_ELVR", "d1/d54/exi__io_8h.html#a7b04101cdf0e6819e4426c4da2524369", null ],
    [ "GetEXI_ENIR", "d1/d54/exi__io_8h.html#a09f5e2973fc05198e60f81fde0d20e25", null ],
    [ "IsEXI0RQActive", "d1/d54/exi__io_8h.html#a221a26db2ff5c779bf68a5716b2185a6", null ],
    [ "IsEXI4RQActive", "d1/d54/exi__io_8h.html#ad1af0c864a51bb65ce88f0ca8e044846", null ],
    [ "IsEXI5RQActive", "d1/d54/exi__io_8h.html#a2bfe9c09219c060fd5098daf8313ed01", null ],
    [ "IsEXI6RQActive", "d1/d54/exi__io_8h.html#a4336a598673399519fbd8192f0ff0515", null ],
    [ "IsEXI7RQActive", "d1/d54/exi__io_8h.html#a10742cc0067bf1f2c5f92b17f4057020", null ],
    [ "SetEXI0DetectionLevel", "d1/d54/exi__io_8h.html#acd5ccccb5a9e52d7293365aabe70f74e", null ],
    [ "SetEXI4DetectionLevel", "d1/d54/exi__io_8h.html#affb4e42fc0daddc65773b39e642959f0", null ],
    [ "SetEXI5DetectionLevel", "d1/d54/exi__io_8h.html#abcf0fe673fe5364cb9466c5790a4abdf", null ],
    [ "SetEXI6DetectionLevel", "d1/d54/exi__io_8h.html#a951b24124cefdee228722f5e7f9de4fd", null ],
    [ "SetEXI7DetectionLevel", "d1/d54/exi__io_8h.html#afb708d18bbab1a6aaa336bbcaf2985c0", null ],
    [ "SetEXI_EIRR", "d1/d54/exi__io_8h.html#a1491403bb606b7c0d5a34f6d217575b2", null ],
    [ "SetEXI_ELVR", "d1/d54/exi__io_8h.html#a541792538af45f2d52e4a0b165834d2d", null ],
    [ "SetEXI_ENIR", "d1/d54/exi__io_8h.html#a77be0fec14d6d75d08be9571f687f6e4", null ],
    [ "T_exiDetectLevel", "d1/d54/exi__io_8h.html#a018bc8fe70d64c27250aa7fdf7305de6", [
      [ "EXI_DETECT_LOW", "d1/d54/exi__io_8h.html#a018bc8fe70d64c27250aa7fdf7305de6a5cbf4fb333d83c04c62300077e31afea", null ],
      [ "EXI_DETECT_HIGH", "d1/d54/exi__io_8h.html#a018bc8fe70d64c27250aa7fdf7305de6a1acaebbd28eb560fcf08f90b5ddbaab9", null ],
      [ "EXI_DETECT_RISE", "d1/d54/exi__io_8h.html#a018bc8fe70d64c27250aa7fdf7305de6a31d59e8f8ac9787cbc8400f985e29bbc", null ],
      [ "EXI_DETECT_FALL", "d1/d54/exi__io_8h.html#a018bc8fe70d64c27250aa7fdf7305de6abe6dfe7510917b88f7f8504ab9abbb24", null ]
    ] ],
    [ "T_exINTEnable", "d1/d54/exi__io_8h.html#ab2dc9be76a668f945517dd9998431a99", [
      [ "EXI_INT_DISABLED", "d1/d54/exi__io_8h.html#ab2dc9be76a668f945517dd9998431a99ab358e0d3984ce67d113b28f95889d708", null ],
      [ "EXI_INT_ENABLED", "d1/d54/exi__io_8h.html#ab2dc9be76a668f945517dd9998431a99a7e3e323a71fdc96d8c2c39cf0b552332", null ]
    ] ],
    [ "T_exIRQ", "d1/d54/exi__io_8h.html#aaf2a2d60a37d79aabad061fc6df4fd6f", [
      [ "EXI_IRQ_CLEARED", "d1/d54/exi__io_8h.html#aaf2a2d60a37d79aabad061fc6df4fd6fa08bcbedcae50c4c35907483c27ca78d9", null ],
      [ "EXI_IRQ_DETECTED", "d1/d54/exi__io_8h.html#aaf2a2d60a37d79aabad061fc6df4fd6faeb2152064722a39ac6122e980f67cfd4", null ]
    ] ]
];