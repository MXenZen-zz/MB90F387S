var union_t__tcanr =
[
    [ "bit", "d1/df8/union_t__tcanr.html#a42c4e893c1cf3f55b737d40afce48afb", null ],
    [ "byte", "d1/df8/union_t__tcanr.html#ab7fe0c66290d6f4c2b9a494ae3c33afc", null ],
    [ "TCAN0", "d1/df8/union_t__tcanr.html#a1030e4e9fa10e1bae02cd6d4617163a9", null ],
    [ "TCAN1", "d1/df8/union_t__tcanr.html#a80c58c08abc602f81513be734ebf079c", null ],
    [ "TCAN2", "d1/df8/union_t__tcanr.html#a8e31f7ac28b8d4762a42643e0d0f1ca9", null ],
    [ "TCAN3", "d1/df8/union_t__tcanr.html#a22054f53fad4a1617ff02ac4073cb3ff", null ],
    [ "TCAN4", "d1/df8/union_t__tcanr.html#a63fb4080264bbe014552497584103540", null ],
    [ "TCAN5", "d1/df8/union_t__tcanr.html#a115029adad4e66e2207f262590e0b004", null ],
    [ "TCAN6", "d1/df8/union_t__tcanr.html#aa627e9eaab7215a814a6b73111657cd7", null ],
    [ "TCAN7", "d1/df8/union_t__tcanr.html#a61c9f17d84b723f49722672f2a802cf6", null ]
];