var mcu_8h =
[
    [ "__wait_us", "d1/d10/mcu_8h.html#acf1b01b667c567d1417bc5dd204766ba", null ],
    [ "initClock", "d1/d10/mcu_8h.html#a37c69da5d5ed51227894e3cffde0c23e", null ],
    [ "initMCU", "d1/d10/mcu_8h.html#a7de50b8347b090acab6579946e0ae6eb", null ],
    [ "resetMCU", "d1/d10/mcu_8h.html#ad55d5b33843f79924063813a14d3fa37", null ],
    [ "sleepMCU", "d1/d10/mcu_8h.html#a50789990f07376c7663afcbadd829e4d", null ],
    [ "stopMCU", "d1/d10/mcu_8h.html#a365399c436cdfc21d96a805e0d6e110c", null ],
    [ "tbtModeMCU", "d1/d10/mcu_8h.html#a11f59e2209256e5962cb897ef577cb3d", null ]
];