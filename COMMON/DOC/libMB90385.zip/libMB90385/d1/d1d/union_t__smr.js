var union_t__smr =
[
    [ "bit", "d1/d1d/union_t__smr.html#a6a68ef46290fd3eb2372b66956c01358", null ],
    [ "byte", "d1/d1d/union_t__smr.html#a2d5d48f316a7ce679f84340ed223e626", null ],
    [ "CS", "d1/d1d/union_t__smr.html#a267c1148a9f6a5ad8db863aa61d4a51c", null ],
    [ "MD", "d1/d1d/union_t__smr.html#ab7271350a03f4ea7dc0a56be9aeb2a16", null ],
    [ "RST", "d1/d1d/union_t__smr.html#a168ae53721bc1fc423d80199ce8114ee", null ],
    [ "SCKE", "d1/d1d/union_t__smr.html#afef00d9b5ae3d453f19ccf254a06eef1", null ],
    [ "SOE", "d1/d1d/union_t__smr.html#a9373ceac8facb17b21b928179c054ee7", null ]
];