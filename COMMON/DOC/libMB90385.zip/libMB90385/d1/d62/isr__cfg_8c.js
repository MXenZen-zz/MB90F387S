var isr__cfg_8c =
[
    [ "PRIO_ADC_ISR", "d1/d62/isr__cfg_8c.html#af4e53bc564b606aac3b8908ff09b0ec5", null ],
    [ "PRIO_CAN_ISR", "d1/d62/isr__cfg_8c.html#a3d7ec553a28158692b6cfcf2e000ef09", null ],
    [ "PRIO_DIG_ISR", "d1/d62/isr__cfg_8c.html#ae741fa0a79acc197f971836de0e299e5", null ],
    [ "PRIO_EXI45_ISR", "d1/d62/isr__cfg_8c.html#a81db837992b65e43743afe8713390465", null ],
    [ "PRIO_EXI67_ISR", "d1/d62/isr__cfg_8c.html#a043e39ef606f115a69a1e0e95418bd24", null ],
    [ "PRIO_EXIRX_ISR", "d1/d62/isr__cfg_8c.html#a1eaea3773b159cbe0af010d44287ef2d", null ],
    [ "PRIO_ICU0_ISR", "d1/d62/isr__cfg_8c.html#ad7e5f7430210e5e2a4799fdefc716353", null ],
    [ "PRIO_ICU1_ISR", "d1/d62/isr__cfg_8c.html#a6f8327872f36312e3e775d26d0c4a256", null ],
    [ "PRIO_ICU23_ISR", "d1/d62/isr__cfg_8c.html#a4456ab12a47af225a79a200121d93f12", null ],
    [ "PRIO_IOT_ISR", "d1/d62/isr__cfg_8c.html#acb590d68effc2f06289987b42be13efc", null ],
    [ "PRIO_PPG01_ISR", "d1/d62/isr__cfg_8c.html#ae374b7d3ff7aa3f04f56762986508bd2", null ],
    [ "PRIO_PPG23_ISR", "d1/d62/isr__cfg_8c.html#abc9764343a80e1cd37e02579d7e6f3d9", null ],
    [ "PRIO_RLT0_ISR", "d1/d62/isr__cfg_8c.html#a7cfd528cab179fb955e823d07c17cf6a", null ],
    [ "PRIO_RLT1_ISR", "d1/d62/isr__cfg_8c.html#a19658f30fc88a2b136952d1fe70cd553", null ],
    [ "PRIO_SER_ISR", "d1/d62/isr__cfg_8c.html#a99fd5885c67560fe7b1b3beb688323e5", null ],
    [ "PRIO_TBT_ISR", "d1/d62/isr__cfg_8c.html#a8d7282148e6332da522285faa4cae076", null ],
    [ "PRIO_WTT_ISR", "d1/d62/isr__cfg_8c.html#af541c5c1241828c8cdf3c50aabd730d5", null ]
];