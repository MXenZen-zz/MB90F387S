var idle_8h =
[
    [ "OSIdleTask", "d1/def/idle_8h.html#aee4fd493d12c1dc258f03459087bf274", null ],
    [ "idleTaskRoutine", "d1/def/idle_8h.html#aa54849d1de8024d837750b969dd83981", null ]
];