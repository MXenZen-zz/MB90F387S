var union_t__cdcr =
[
    [ "__pad0__", "d1/d83/union_t__cdcr.html#a86004417d0acb7bc82aabfadecb3cb1f", null ],
    [ "bit", "d1/d83/union_t__cdcr.html#a75e20ec005b1c2e923b94462a5eb0238", null ],
    [ "byte", "d1/d83/union_t__cdcr.html#ae41843e37d771f802c3a63530a0b38d7", null ],
    [ "DIV", "d1/d83/union_t__cdcr.html#a54e0e19e365a392c2d4a7246a8f31955", null ],
    [ "MD", "d1/d83/union_t__cdcr.html#acc269b64630664cdfa7e2b1b99ed8e9e", null ]
];