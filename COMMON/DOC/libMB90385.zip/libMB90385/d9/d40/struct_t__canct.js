var struct_t__canct =
[
    [ "__pad0__", "d9/d40/struct_t__canct.html#aa4023c128f95f4875ee6bf05d88ffa0f", null ],
    [ "__pad1__", "d9/d40/struct_t__canct.html#a375cf0828134fa4f886b18e97f24d2a1", null ],
    [ "__pad2__", "d9/d40/struct_t__canct.html#a05b0e7132c8b7e52672a59465b79476d", null ],
    [ "__pad3__", "d9/d40/struct_t__canct.html#aa3f91f1644e87551f28520e5151dda7b", null ],
    [ "__pad4__", "d9/d40/struct_t__canct.html#a58eae0dbbfca1db4cee560f1dbf2e6d7", null ],
    [ "__pad5__", "d9/d40/struct_t__canct.html#a05ad94bdc2831ba2dfe61fc53f9e928d", null ],
    [ "AMR0", "d9/d40/struct_t__canct.html#af74d2511a5469998d2294c080f2a5396", null ],
    [ "AMR1", "d9/d40/struct_t__canct.html#ab21b402bf8cec83efdf20599acf30ead", null ],
    [ "AMSR", "d9/d40/struct_t__canct.html#af9019dd31f672882844ae8ceb242e16c", null ],
    [ "BTR", "d9/d40/struct_t__canct.html#ab7c5bd12173efd57137b7798cfd3af63", null ],
    [ "CSR", "d9/d40/struct_t__canct.html#aec6deca8bcffc73ad9f33c65688c0972", null ],
    [ "IDER", "d9/d40/struct_t__canct.html#a6ac6793e2e0dc5819eb6021398d7403a", null ],
    [ "LEIR", "d9/d40/struct_t__canct.html#a454f0faf27cd5e57ba6294cc0b82647a", null ],
    [ "RFWTR", "d9/d40/struct_t__canct.html#a69424f738538b6db67913a060e037225", null ],
    [ "RTEC", "d9/d40/struct_t__canct.html#a2dd571988842b84a8c87285d7c3e859e", null ],
    [ "TIER", "d9/d40/struct_t__canct.html#a8c03979bcf5293cdffdaab26da4670bf", null ],
    [ "TRTRR", "d9/d40/struct_t__canct.html#a4a201139c7873730cf4fe5ba60fe8d30", null ]
];