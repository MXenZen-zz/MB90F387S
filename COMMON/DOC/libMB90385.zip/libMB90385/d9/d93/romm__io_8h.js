var romm__io_8h =
[
    [ "DisableROMM", "d9/d93/romm__io_8h.html#a556d9cdfcab86445eb4f1a39315b38a8", null ],
    [ "EnableROMM", "d9/d93/romm__io_8h.html#a018dadf6372645d5a20e3949b0f1d2dc", null ],
    [ "GetROMM", "d9/d93/romm__io_8h.html#ac15c3d8448364b34fa00cfc56502b3b6", null ],
    [ "SetROMM", "d9/d93/romm__io_8h.html#a3f79d9b1be5b71ad5e48e91a4694654f", null ],
    [ "T_mirEnable", "d9/d93/romm__io_8h.html#a41f1ed9f3ba7ca00e8d78196771a20f7", [
      [ "ROMM_DISABLE", "d9/d93/romm__io_8h.html#a41f1ed9f3ba7ca00e8d78196771a20f7a24aa1de9af0c180ce7e535d0e51f6fb2", null ],
      [ "ROMM_ENABLE", "d9/d93/romm__io_8h.html#a41f1ed9f3ba7ca00e8d78196771a20f7ae0806894e0695ab5562c25b52949a964", null ]
    ] ]
];