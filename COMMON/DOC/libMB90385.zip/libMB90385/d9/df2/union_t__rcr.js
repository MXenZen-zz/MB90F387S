var union_t__rcr =
[
    [ "bit", "d9/df2/union_t__rcr.html#a30602e9bed525f9a9c7642085f3d5c53", null ],
    [ "byte", "d9/df2/union_t__rcr.html#a29a9a72bb5dc5f2024085bd4b375380f", null ],
    [ "RC0", "d9/df2/union_t__rcr.html#ac5795cb64c9d223d5c82cec4d0986c1b", null ],
    [ "RC1", "d9/df2/union_t__rcr.html#aab5edfb04a9a0e9692776c8b33622500", null ],
    [ "RC2", "d9/df2/union_t__rcr.html#a1546114f17223e9c3592aa7ff71dce7e", null ],
    [ "RC3", "d9/df2/union_t__rcr.html#ad839bfeb3d41bf00f44b9ef5e8482427", null ],
    [ "RC4", "d9/df2/union_t__rcr.html#a400f2d5be59d5d3d481d6ec5a8ef4a57", null ],
    [ "RC5", "d9/df2/union_t__rcr.html#acb7e4044310837762f71a791b9fa708f", null ],
    [ "RC6", "d9/df2/union_t__rcr.html#a3490d7c69e7595fafbdd650e84096319", null ],
    [ "RC7", "d9/df2/union_t__rcr.html#abd7cbb010295d234c52172f963fc7511", null ]
];