var union_t__canct__rfwtr =
[
    [ "bit", "d9/d27/union_t__canct__rfwtr.html#adcd5db5a4f615c46c35301162609237b", null ],
    [ "byte", "d9/d27/union_t__canct__rfwtr.html#a4df85f803d87c3bfb29a1c2496fbebda", null ],
    [ "RFWT0", "d9/d27/union_t__canct__rfwtr.html#a3a10fa5fb8eeb2ffb76246c9bba2612d", null ],
    [ "RFWT1", "d9/d27/union_t__canct__rfwtr.html#ac33daebfd0d9cc3b9759ee0f9110e40f", null ],
    [ "RFWT2", "d9/d27/union_t__canct__rfwtr.html#ad3feeb3f1de752576578cedf7fad2781", null ],
    [ "RFWT3", "d9/d27/union_t__canct__rfwtr.html#ab7b3bcb33325d9f6858f1d3c93f450ad", null ],
    [ "RFWT4", "d9/d27/union_t__canct__rfwtr.html#ae4fe63bb188303af57162ece334d2d2e", null ],
    [ "RFWT5", "d9/d27/union_t__canct__rfwtr.html#ae8b2c537cea922700cf111e7c6f04c74", null ],
    [ "RFWT6", "d9/d27/union_t__canct__rfwtr.html#aeed7fc81d9738a7326cffece68c97d67", null ],
    [ "RFWT7", "d9/d27/union_t__canct__rfwtr.html#a128e24145990c7e6f7b249c16d302d3c", null ]
];