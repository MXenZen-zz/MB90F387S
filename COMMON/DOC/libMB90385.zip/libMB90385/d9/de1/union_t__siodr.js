var union_t__siodr =
[
    [ "__pad0__", "d9/de1/union_t__siodr.html#aa76c6998b71c7e0f9daa7b05d0b4ef09", null ],
    [ "bit", "d9/de1/union_t__siodr.html#ae1b63702d05063cdbaa1bf63e01d1872", null ],
    [ "byte", "d9/de1/union_t__siodr.html#a51f3209cd59d9ce3f3d3e0d37aff306c", null ],
    [ "D", "d9/de1/union_t__siodr.html#a8f3198908f78f946dd378d4026bb9632", null ]
];