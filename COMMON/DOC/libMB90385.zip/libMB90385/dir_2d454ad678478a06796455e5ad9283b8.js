var dir_2d454ad678478a06796455e5ad9283b8 =
[
    [ "idle.h", "d1/def/idle_8h.html", "d1/def/idle_8h" ],
    [ "scheduler.h", "d2/dd8/scheduler_8h.html", "d2/dd8/scheduler_8h" ],
    [ "task.h", "db/da4/task_8h.html", "db/da4/task_8h" ],
    [ "timer.h", "d5/dd0/timer_8h.html", "d5/dd0/timer_8h" ]
];