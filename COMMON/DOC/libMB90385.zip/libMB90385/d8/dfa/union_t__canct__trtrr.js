var union_t__canct__trtrr =
[
    [ "bit", "d8/dfa/union_t__canct__trtrr.html#ac392f804f5599a36538d08315e752820", null ],
    [ "byte", "d8/dfa/union_t__canct__trtrr.html#af2663806ab692c4062833e0538b8578c", null ],
    [ "TRTR0", "d8/dfa/union_t__canct__trtrr.html#a3350c3c180023ac0012de15c7ced1993", null ],
    [ "TRTR1", "d8/dfa/union_t__canct__trtrr.html#a8c75f469e5c440bfa2aedbb2bd1d4918", null ],
    [ "TRTR2", "d8/dfa/union_t__canct__trtrr.html#af8b3880617e4ab199812b0ac0cf8c5ac", null ],
    [ "TRTR3", "d8/dfa/union_t__canct__trtrr.html#a79bdf2e04ef25407ecf9758ea1e13633", null ],
    [ "TRTR4", "d8/dfa/union_t__canct__trtrr.html#ad71bc81d374701e2aeea0f1d54abbd52", null ],
    [ "TRTR5", "d8/dfa/union_t__canct__trtrr.html#a599bd477654f07ba0d25f2f355982592", null ],
    [ "TRTR6", "d8/dfa/union_t__canct__trtrr.html#a55f53a6cbf49d9b884e48de3fb414b6c", null ],
    [ "TRTR7", "d8/dfa/union_t__canct__trtrr.html#a40d9e18ff6c4c6aa259e324b5ccb0dc7", null ]
];