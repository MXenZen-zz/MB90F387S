var dig_8h =
[
    [ "T_digISRHook", "d8/df0/dig_8h.html#a65b8dcd8b126dff2b95b9d21b342b920", null ],
    [ "DIG_IRQHandler", "d8/df0/dig_8h.html#a10b82ea59bc8a93dead15b36999fd8ea", null ],
    [ "initDIG", "d8/df0/dig_8h.html#af061578f3f01fc38045cd2b2056f3982", null ],
    [ "setDIGFunction", "d8/df0/dig_8h.html#a0015ca6d65e99a0b4a97ef2b93c2ea3f", null ],
    [ "PRIO_DIG_ISR", "d8/df0/dig_8h.html#aafb1d5b0bbd0f155e14529e9149a6e88", null ]
];