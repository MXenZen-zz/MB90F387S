var pul_8h =
[
    [ "IsPulseCaptureCompleted", "da/d56/pul_8h.html#a7020d48f5f653f3730240ab6be350b2a", null ],
    [ "IsPulseCaptureExpired", "da/d56/pul_8h.html#a482c7a774d7ba57413ac7f17c0dfcf10", null ],
    [ "IsPulseCaptureFinished", "da/d56/pul_8h.html#acc4657f6e8d88a6a6b3c099f41e29b91", null ],
    [ "IsPulseCaptureLocked", "da/d56/pul_8h.html#ad45a87a031b0bdc128ee35bc3eafc39d", null ],
    [ "initPUL", "da/d56/pul_8h.html#ad44bdfa3063f87dcec24485a30b68a5c", null ],
    [ "pulseDetected", "da/d56/pul_8h.html#aa48894871e3177b8a7a3b80cc704c973", null ],
    [ "setupPULCapture", "da/d56/pul_8h.html#a6dfc1f34bc37015c4a633d00f2e7a9c2", null ],
    [ "pPULCaptureEnded", "da/d56/pul_8h.html#a53ca572cd8f9dc2cf86a00de0abdee0c", null ],
    [ "pPULCaptureExpired", "da/d56/pul_8h.html#adf8663c55127dbf45e1455ab75c0d8eb", null ],
    [ "pPULCaptureLocked", "da/d56/pul_8h.html#ad4b686c5f22eaf5f64dcc927e0a9d4a4", null ],
    [ "pPULCaptureStarted", "da/d56/pul_8h.html#ae2b2d4eb7b08280ec7f26f8a30a40b76", null ]
];