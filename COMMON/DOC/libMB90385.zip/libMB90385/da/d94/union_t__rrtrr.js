var union_t__rrtrr =
[
    [ "bit", "da/d94/union_t__rrtrr.html#abc54e1051537575c760dda8cb20b9eb3", null ],
    [ "byte", "da/d94/union_t__rrtrr.html#a9b9204515e9f764c242a593a155caa00", null ],
    [ "RRTR0", "da/d94/union_t__rrtrr.html#ac18c4cb957daa7e974e0843107aa4212", null ],
    [ "RRTR1", "da/d94/union_t__rrtrr.html#a9117d6398dab8b10f830f14543ba4c86", null ],
    [ "RRTR2", "da/d94/union_t__rrtrr.html#aa75e33f7306ac23a8f178a0559bf4e02", null ],
    [ "RRTR3", "da/d94/union_t__rrtrr.html#ae7da2dbb0e9096017c3b1166ce1410de", null ],
    [ "RRTR4", "da/d94/union_t__rrtrr.html#aa822b588a934db4d9cd0bb0d4256f47b", null ],
    [ "RRTR5", "da/d94/union_t__rrtrr.html#a3bdde25eb28ecbf86c487fdbbd662f37", null ],
    [ "RRTR6", "da/d94/union_t__rrtrr.html#abe8b1fd04cddbb355ad90a4b7659a3fe", null ],
    [ "RRTR7", "da/d94/union_t__rrtrr.html#a39ba4b7d6cb2ad81b5f2973d18631e77", null ]
];