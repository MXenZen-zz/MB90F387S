var struct_t__canct__rtec =
[
    [ "REC", "da/d3d/struct_t__canct__rtec.html#a6789d6359d2d9e5d23feb2db67ea9eac", null ],
    [ "TEC", "da/d3d/struct_t__canct__rtec.html#a3909770ad1701f5635550613f5e862c8", null ]
];