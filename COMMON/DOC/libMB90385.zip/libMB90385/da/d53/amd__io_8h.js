var amd__io_8h =
[
    [ "DisableAMD0", "da/d53/amd__io_8h.html#a93cf6d8526466835594d98f230db37fc", null ],
    [ "DisableAMD1", "da/d53/amd__io_8h.html#a0b00f405aa2634d331d3c817756f88a7", null ],
    [ "EnableAMD0", "da/d53/amd__io_8h.html#a7345755ed1c0fcc307934bd6cfd1a8bf", null ],
    [ "EnableAMD1", "da/d53/amd__io_8h.html#a3cd7e2e1767709011bb342bcc2a9cee8", null ],
    [ "GetAMD_PACSR", "da/d53/amd__io_8h.html#af93c5383e0527bca9fce34ae597ec9a6", null ],
    [ "SetAMD_PACSR", "da/d53/amd__io_8h.html#ac70fd12ab16e8212b5faf6d7b90332c9", null ],
    [ "T_amdEnable", "da/d53/amd__io_8h.html#ace870e76b824b0c6ef22f68601fdcd43", [
      [ "AMD_DISABLE", "da/d53/amd__io_8h.html#ace870e76b824b0c6ef22f68601fdcd43ac1ab188675c7341737e2e59586bbd169", null ],
      [ "AMD_ENABLE", "da/d53/amd__io_8h.html#ace870e76b824b0c6ef22f68601fdcd43a9d48aceba7924f10bc98a7072a33e988", null ]
    ] ]
];