var exi_8h =
[
    [ "T_exISRHook", "da/d0d/exi_8h.html#adf0f8605537a0e5aff8cda9202a4c852", null ],
    [ "T_exiChannel", "da/d0d/exi_8h.html#a84e722f91ed2c57aa2a7f91c3351e7a0", [
      [ "EXI_CH4", "da/d0d/exi_8h.html#a84e722f91ed2c57aa2a7f91c3351e7a0af59a380d7dcec4e3b23eb236af7879e8", null ],
      [ "EXI_CH5", "da/d0d/exi_8h.html#a84e722f91ed2c57aa2a7f91c3351e7a0aecf92a87bff4ae30b0852820aeb5ecf2", null ],
      [ "EXI_CH6", "da/d0d/exi_8h.html#a84e722f91ed2c57aa2a7f91c3351e7a0ac4a56d8a82472195c0205e4a31cec979", null ],
      [ "EXI_CH7", "da/d0d/exi_8h.html#a84e722f91ed2c57aa2a7f91c3351e7a0a1b4290261b5c5f7c58a236656c30648d", null ],
      [ "EXI_RX", "da/d0d/exi_8h.html#a84e722f91ed2c57aa2a7f91c3351e7a0a2411f2f6b17d7f47d5574ba9cd7203ab", null ]
    ] ],
    [ "attachEXI", "da/d0d/exi_8h.html#ac3d8a2e0b67cee49341906970360bff2", null ],
    [ "detachEXI", "da/d0d/exi_8h.html#a100e62b388e276044afc0cb31a75c36e", null ],
    [ "EXI45_IRQHandler", "da/d0d/exi_8h.html#a3c3805de89e6a9e41b9d9d31fdc2e023", null ],
    [ "EXI67_IRQHandler", "da/d0d/exi_8h.html#aa5e442f6cd7f6af83d5eeb21be2abd06", null ],
    [ "EXIRX_IRQHandler", "da/d0d/exi_8h.html#a1a108b309c570b1d2d8455e4ffba73f6", null ],
    [ "initEXI", "da/d0d/exi_8h.html#a011a1d68e94a3001e4fdd4188116fd50", null ],
    [ "PRIO_EXI45_ISR", "da/d0d/exi_8h.html#a3a0fad7ebc0a65ab6960e0c8b5b032ee", null ],
    [ "PRIO_EXI67_ISR", "da/d0d/exi_8h.html#a82b743416740e24159f53a6d6708c369", null ],
    [ "PRIO_EXIRX_ISR", "da/d0d/exi_8h.html#aa2b0ab0c722841e6950e49f78f2d5d37", null ]
];