var ppg__types_8h =
[
    [ "T_ppgCntClk", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7", [
      [ "PPG_MCLK_1T", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7aa59ad9a276a8326967d72cd1c412e1de", null ],
      [ "PPG_MCLK_2T", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7ade83f122affb935f045a95ebcd838642", null ],
      [ "PPG_MCLK_4T", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7a3e4cece50ad3dd6285248d4a84891411", null ],
      [ "PPG_MCLK_8T", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7ad6e4d4ecadb28a15bc90fe3b9d7c4d54", null ],
      [ "PPG_MCLK_16T", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7acf10686007bf0e11861a9f9d2a16e015", null ],
      [ "PPG_CLK_DISABLED", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7a98289b5c5eeb8e3aacaf09604e820a97", null ],
      [ "PPG_CLK_NO_CLOCK", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7a50f9067e64573ff8b7b8b37f951cb054", null ],
      [ "PPG_HCLK_512T", "da/d15/ppg__types_8h.html#a2f556c9d7be42401742aed6c594e12f7acc04c75f2b04ed60ff53b09f745cfd02", null ]
    ] ],
    [ "T_ppgINTEnable", "da/d15/ppg__types_8h.html#ada156335808f2a2c5dc505c5bfee3a0b", [
      [ "PPG_INT_DISABLED", "da/d15/ppg__types_8h.html#ada156335808f2a2c5dc505c5bfee3a0ba257e3c45573b3898e26037c8db5e913c", null ],
      [ "PPG_INT_ENABLED", "da/d15/ppg__types_8h.html#ada156335808f2a2c5dc505c5bfee3a0ba1ee47e02c33e6cbbd972d703f2467e98", null ]
    ] ],
    [ "T_ppgIRQ", "da/d15/ppg__types_8h.html#a4b8bbc5dc67d8e304aa2763b97145e44", [
      [ "PPG_IRQ_CLEARED", "da/d15/ppg__types_8h.html#a4b8bbc5dc67d8e304aa2763b97145e44a6196e4d81e586b4082aaa9765a4141af", null ],
      [ "PPG_IRQ_UNDERFLOWED", "da/d15/ppg__types_8h.html#a4b8bbc5dc67d8e304aa2763b97145e44a8ab9e2c10fc3b5fb458dc24544b3153a", null ]
    ] ],
    [ "T_ppgOperation", "da/d15/ppg__types_8h.html#a83a1531920a32b4d2403bd01d22cf359", [
      [ "PPG_OP_DISABLED", "da/d15/ppg__types_8h.html#a83a1531920a32b4d2403bd01d22cf359ab9f671a9a9eb3b848995bd9ac20a18c5", null ],
      [ "PPG_OP_ENABLED", "da/d15/ppg__types_8h.html#a83a1531920a32b4d2403bd01d22cf359a905f9db3a58556f7fc7e09d3397d224e", null ]
    ] ],
    [ "T_ppgOpMode", "da/d15/ppg__types_8h.html#a63e5b8e5d28e93d2b8b7d91bf49255dc", [
      [ "PPG_MOD_8BIT_2CH", "da/d15/ppg__types_8h.html#a63e5b8e5d28e93d2b8b7d91bf49255dcad6becdf8a5b04e656ab4928f8ce58194", null ],
      [ "PPG_MOD_8_8BIT_1CH", "da/d15/ppg__types_8h.html#a63e5b8e5d28e93d2b8b7d91bf49255dca410ba11b748da6eef6f08849d7f4968a", null ],
      [ "PPG_MOD_DISABLED", "da/d15/ppg__types_8h.html#a63e5b8e5d28e93d2b8b7d91bf49255dcaf2250223c1a823c5e1f7aef07362b14c", null ],
      [ "PPG_MOD_16BIT_1CH", "da/d15/ppg__types_8h.html#a63e5b8e5d28e93d2b8b7d91bf49255dca33839002eb278ecd6dd803ed37d7276a", null ]
    ] ],
    [ "T_ppgPin", "da/d15/ppg__types_8h.html#ab1ac07ff5335a75c34fdf65201bb6e3a", [
      [ "PPG_PIN_GPIO", "da/d15/ppg__types_8h.html#ab1ac07ff5335a75c34fdf65201bb6e3aadbca7a68b6adebed8e318b013d7fa8a0", null ],
      [ "PPG_PIN_ENABLED", "da/d15/ppg__types_8h.html#ab1ac07ff5335a75c34fdf65201bb6e3aa9d8f99387f9c70553a59a9f394956b5b", null ]
    ] ]
];