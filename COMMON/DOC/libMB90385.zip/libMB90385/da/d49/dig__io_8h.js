var dig__io_8h =
[
    [ "ClearDIG", "da/d49/dig__io_8h.html#a83c3c86574dd12054ccd69175c544671", null ],
    [ "GetDIG_DIRR", "da/d49/dig__io_8h.html#a9b9730dee125a730fb61f227293b61f8", null ],
    [ "RequestDIG", "da/d49/dig__io_8h.html#a482daf3380419c2f432d28e180985762", null ],
    [ "SetDIG_DIRR", "da/d49/dig__io_8h.html#ad4c5b48252542a0c83da4d0cbfe7d626", null ],
    [ "T_digIRQ", "da/d49/dig__io_8h.html#a721b99d0a34b91be42b3cbd4bbdc4a96", [
      [ "DIG_IRQ_CLEARED", "da/d49/dig__io_8h.html#a721b99d0a34b91be42b3cbd4bbdc4a96a7d614c25df78753ef90744f3107b2494", null ],
      [ "DIG_IRQ_ENABLED", "da/d49/dig__io_8h.html#a721b99d0a34b91be42b3cbd4bbdc4a96a4c9b68ba68bb819d8658195b81b5d49f", null ]
    ] ]
];