var union_t__enir =
[
    [ "__pad0__", "d2/d1a/union_t__enir.html#a46d9fe92d4c68aa4d4ef48c3d1322498", null ],
    [ "bit", "d2/d1a/union_t__enir.html#a6c7325b04b814a2460a193b04942aa4e", null ],
    [ "byte", "d2/d1a/union_t__enir.html#a6a6f63646a8e78868c6d507372a12066", null ],
    [ "EN0", "d2/d1a/union_t__enir.html#a3172ca28c7d74c6b616ef6b3c9590625", null ],
    [ "EN4", "d2/d1a/union_t__enir.html#a276764b7cb7a4c71dc77ef8706180c65", null ],
    [ "EN5", "d2/d1a/union_t__enir.html#a214f9c88858218b7bc3c999c111565a0", null ],
    [ "EN6", "d2/d1a/union_t__enir.html#a2ea48e3bc0328651459bacef985e9b89", null ],
    [ "EN7", "d2/d1a/union_t__enir.html#a037a6fad5c567979e03bc60d9cf05697", null ]
];