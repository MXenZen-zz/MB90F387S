var union_t__canct__csr =
[
    [ "__pad0__", "d2/ddd/union_t__canct__csr.html#aea4a205754a103f493131ea06536c6ab", null ],
    [ "__pad1__", "d2/ddd/union_t__canct__csr.html#ad136494a41d130d3a791cf8c68f7b832", null ],
    [ "__pad2__", "d2/ddd/union_t__canct__csr.html#a86145b4067aa1f28470b6d767b92ef18", null ],
    [ "bit", "d2/ddd/union_t__canct__csr.html#af5c00832eda637aed40e8d18e0005310", null ],
    [ "HALT", "d2/ddd/union_t__canct__csr.html#a82700112dd24dcf1cba318825b944683", null ],
    [ "NIE", "d2/ddd/union_t__canct__csr.html#aa0fda1504bf49749b7d4ba79be7c1d42", null ],
    [ "NS", "d2/ddd/union_t__canct__csr.html#ad003977dae11aaaa0ab5a484330ca732", null ],
    [ "NT", "d2/ddd/union_t__canct__csr.html#a58697500828a04028db440032843470b", null ],
    [ "RS", "d2/ddd/union_t__canct__csr.html#af9319d37fd16b4907075ebab42bb791c", null ],
    [ "TOE", "d2/ddd/union_t__canct__csr.html#acab9bb3f27cc1faa4df815eb8a40685c", null ],
    [ "TS", "d2/ddd/union_t__canct__csr.html#aea3024cef6b7777692edac16ab114e86", null ],
    [ "word", "d2/ddd/union_t__canct__csr.html#ada5aadaeed0eb24964031488c4620f8b", null ]
];