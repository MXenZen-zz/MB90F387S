var struct_t__kalman =
[
    [ "estError", "d2/d12/struct_t__kalman.html#a5cce6fae58ab12061308964d6e597d69", null ],
    [ "estimate", "d2/d12/struct_t__kalman.html#a133006842d7ea92e74681ffe1209c25b", null ],
    [ "gain", "d2/d12/struct_t__kalman.html#ac0904248d223f67f10f208ef479f41e9", null ],
    [ "meaNoise", "d2/d12/struct_t__kalman.html#a5223ce1b27e3cf1c7d00969d022d59e3", null ],
    [ "procNoise", "d2/d12/struct_t__kalman.html#a35433db44b44ce4c0372ab5f60ad5a1f", null ],
    [ "value", "d2/d12/struct_t__kalman.html#ac1024671a97ce717cbee4955aaec3241", null ]
];