var icr__io_8h =
[
    [ "DisableEI2OS", "d2/d0a/icr__io_8h.html#a3d25021f0b3baa4ba677bea0599c5a85", null ],
    [ "EnableEI2OS", "d2/d0a/icr__io_8h.html#aae2cff1c756461307c7aed063dee9a50", null ],
    [ "GetICR", "d2/d0a/icr__io_8h.html#ae991a99b83d5e59f959fba3c59cb1a8b", null ],
    [ "GetICRIntLevel", "d2/d0a/icr__io_8h.html#a1a690fb9546c442e5c2672b8fe4ac180", null ],
    [ "GetISD_BAP", "d2/d0a/icr__io_8h.html#afe659a084c69c63bebcf83ac60380c0a", null ],
    [ "GetISD_DCT", "d2/d0a/icr__io_8h.html#a29a64463d3c54834f56eccb45c088aa3", null ],
    [ "GetISD_IOA", "d2/d0a/icr__io_8h.html#a54561d785af479a18433c8411cf6b53d", null ],
    [ "GetISD_ISCS", "d2/d0a/icr__io_8h.html#afc2e32007b9da505cc00719f04374ad6", null ],
    [ "ICR_ADC", "d2/d0a/icr__io_8h.html#ad95da8372050bfcdd8a87ea0d4659b6b", null ],
    [ "ICR_CAN", "d2/d0a/icr__io_8h.html#aa8537115d0d520caa9c4a060c9220790", null ],
    [ "ICR_DIG", "d2/d0a/icr__io_8h.html#afa58bbdec2018895996c8bba20e6a32e", null ],
    [ "ICR_EXI45", "d2/d0a/icr__io_8h.html#a6273ee714192cd427b6fa92119f644b4", null ],
    [ "ICR_EXI67", "d2/d0a/icr__io_8h.html#ab40913ed46415812e1eee36d4c33e343", null ],
    [ "ICR_EXIRX", "d2/d0a/icr__io_8h.html#a6ac2f9c21e09e6c21c5db34036eeaf18", null ],
    [ "ICR_ICU0", "d2/d0a/icr__io_8h.html#a477e692c990f018fb37d875c4fa8f71f", null ],
    [ "ICR_ICU1", "d2/d0a/icr__io_8h.html#a77e0c2661e176bd3060c8b0b3ef8915a", null ],
    [ "ICR_ICU23", "d2/d0a/icr__io_8h.html#af4b9299df5e6c3bd34f743e311505ee5", null ],
    [ "ICR_IOT", "d2/d0a/icr__io_8h.html#a351c016afacb60fc62ce91e4950daed8", null ],
    [ "ICR_PBASE", "d2/d0a/icr__io_8h.html#a87c836ef65f624fe4c6dba614e2dc907", null ],
    [ "ICR_PPG01", "d2/d0a/icr__io_8h.html#affde89880464b9943efa7e509a0c47c6", null ],
    [ "ICR_PPG23", "d2/d0a/icr__io_8h.html#a88a9bdf70820d1d59db4331f1e92e19d", null ],
    [ "ICR_PTOP", "d2/d0a/icr__io_8h.html#a569edbe3dac61c833558c3410cafcdc6", null ],
    [ "ICR_RLT0", "d2/d0a/icr__io_8h.html#ac89c15ed7ac4247711fb1082c3fc21e2", null ],
    [ "ICR_RLT1", "d2/d0a/icr__io_8h.html#a6d363aad876c7123243023b050fc720f", null ],
    [ "ICR_SER", "d2/d0a/icr__io_8h.html#a6fa88711c1b9889731bc4e659a2aebcb", null ],
    [ "ICR_TBT", "d2/d0a/icr__io_8h.html#aae763df7cdba54eb6d28dfd6d182fb90", null ],
    [ "ICR_WTT", "d2/d0a/icr__io_8h.html#ad175465a6fffab96416054070377147c", null ],
    [ "IsEI2OSEnabled", "d2/d0a/icr__io_8h.html#a1a8cb804efaf0e66b891ce586d2f80bc", null ],
    [ "IsEI2OSInOperation", "d2/d0a/icr__io_8h.html#acddd3f9135af55f0c37bf333e391c994", null ],
    [ "IsEI2OSInStopByEOC", "d2/d0a/icr__io_8h.html#a22100032dd68e99d2756075bad6d705b", null ],
    [ "IsEI2OSInStopByReqRes", "d2/d0a/icr__io_8h.html#aaff79b1d88ee4eb6f312ce9efcb2160a", null ],
    [ "SetEI2OSChannel", "d2/d0a/icr__io_8h.html#a9b1e702b93aec0cc13eae3d7a612050b", null ],
    [ "SetICR", "d2/d0a/icr__io_8h.html#a86819b11e89e88b6bf75ed5b9fd35e8b", null ],
    [ "SetICRIntLevel", "d2/d0a/icr__io_8h.html#a4c3376ba7993eae9d322591897acae16", null ],
    [ "SetISD_BAP", "d2/d0a/icr__io_8h.html#a7ff83cc04ed709f76d4ea625e932ab13", null ],
    [ "SetISD_DCT", "d2/d0a/icr__io_8h.html#a98fa9f32f07b360e5ee2bc6dab29bdaa", null ],
    [ "SetISD_IOA", "d2/d0a/icr__io_8h.html#a0b357a08da08dab60ca2c739aa04967c", null ],
    [ "SetISD_ISCS", "d2/d0a/icr__io_8h.html#a4a9c79c2ac4311df5d7e1ff4f11c7e16", null ],
    [ "SetISDBAPFixed", "d2/d0a/icr__io_8h.html#ab19dbec202ea8abca87996c91ee55c7a", null ],
    [ "SetISDBAPUpdated", "d2/d0a/icr__io_8h.html#a0eb552888f003904c273421f476f7d10", null ],
    [ "SetISDIOAFixed", "d2/d0a/icr__io_8h.html#a3c87c9f02c775bbb4c3b113c4545de3d", null ],
    [ "SetISDIOAUpdated", "d2/d0a/icr__io_8h.html#a9f64fa309e8622acb50f3e54b1ee370a", null ],
    [ "SetISDNoTermination", "d2/d0a/icr__io_8h.html#abd89798f42ab5a470f34fdb2507e9bc3", null ],
    [ "SetISDTerminatedByResReq", "d2/d0a/icr__io_8h.html#a72bd89695692ec97dbc720cb0e182ac1", null ],
    [ "SetISDTransferBUFtoIOA", "d2/d0a/icr__io_8h.html#acc2d4470deded790dfff90a31e42e325", null ],
    [ "SetISDTransferByteLength", "d2/d0a/icr__io_8h.html#a4c983c1d9a8ab34e02defc37631ed3f6", null ],
    [ "SetISDTransferIOAtoBUF", "d2/d0a/icr__io_8h.html#a72f50a9fe71225fd517ec7eadeb8a596", null ],
    [ "SetISDTransferWordLength", "d2/d0a/icr__io_8h.html#acf38807eeae2fbf2c79f0bc810790c69", null ],
    [ "T_icrEI2OSBAPUpdate", "d2/d0a/icr__io_8h.html#aa0e629702ca71a7b0cd710d77babecf8", [
      [ "ICR_EI2OS_BAP_UPDATED", "d2/d0a/icr__io_8h.html#aa0e629702ca71a7b0cd710d77babecf8a7e47ca6ce13b66232c5505b17df0b012", null ],
      [ "ICR_EI2OS_BAP_FIXED", "d2/d0a/icr__io_8h.html#aa0e629702ca71a7b0cd710d77babecf8a13595974c6e84421022cb559c6c4667b", null ]
    ] ],
    [ "T_icrEI2OSChannel", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318", [
      [ "ICR_EI2OS_CH0", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318ade3a8b343ee46bda86704b477a426e64", null ],
      [ "ICR_EI2OS_CH1", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a8a02b822ff4f0efb013493450f53b4ee", null ],
      [ "ICR_EI2OS_CH2", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a5050e6195a49fce6b56b68e733e192f2", null ],
      [ "ICR_EI2OS_CH3", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a70e9538f208868782f76320d5e15f325", null ],
      [ "ICR_EI2OS_CH4", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a3b487bc0158e4c2bd8f960922ded25e8", null ],
      [ "ICR_EI2OS_CH5", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318acbef3a8e9d705138dd883e54e2443238", null ],
      [ "ICR_EI2OS_CH6", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318af32be3ae589d57bc212150ef89031919", null ],
      [ "ICR_EI2OS_CH7", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a95d06b501a1f16f807409d046cf65d08", null ],
      [ "ICR_EI2OS_CH8", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a8209f995c0ea886565ed84936c7d833d", null ],
      [ "ICR_EI2OS_CH9", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a4fa14d8216baccc3e00179bdb96c4b9a", null ],
      [ "ICR_EI2OS_CH10", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a39b9ed81763158ace192afd6d6b6d8d5", null ],
      [ "ICR_EI2OS_CH11", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a50ba1f136c5423dc487634bc98e92c36", null ],
      [ "ICR_EI2OS_CH12", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a443b0777f5778c919b960037b261b253", null ],
      [ "ICR_EI2OS_CH13", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318aefde57c1769c0f280f919ea4d41b50da", null ],
      [ "ICR_EI2OS_CH14", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318a87b0a7ba53614d71785eba05b3009627", null ],
      [ "ICR_EI2OS_CH15", "d2/d0a/icr__io_8h.html#af90fb5c9e4090e06209ea64432cd3318ab7edb2db9e57721c7bd9ada4a05cdefd", null ]
    ] ],
    [ "T_icrEI2OSDLength", "d2/d0a/icr__io_8h.html#a67558de81e773caa0d4ef8fcc16eb208", [
      [ "ICR_EI2OS_DL_BYTE", "d2/d0a/icr__io_8h.html#a67558de81e773caa0d4ef8fcc16eb208ae7563199b90b7b5c35f3ff8de9c81745", null ],
      [ "ICR_EI2OS_DL_WORD", "d2/d0a/icr__io_8h.html#a67558de81e773caa0d4ef8fcc16eb208a5854ed11cc79530547add12ddcf539ed", null ]
    ] ],
    [ "T_icrEI2OSDTrans", "d2/d0a/icr__io_8h.html#a605879159fa11f9c4f613ac645100619", [
      [ "ICR_EI2OS_IOA_TO_BUF", "d2/d0a/icr__io_8h.html#a605879159fa11f9c4f613ac645100619a95d01485034e2f669a4bffe192ed8ade", null ],
      [ "ICR_EI2OS_BUF_TO_IOA", "d2/d0a/icr__io_8h.html#a605879159fa11f9c4f613ac645100619a7651d095b9a5e9a52a4628f3bb139d08", null ]
    ] ],
    [ "T_icrEI2OSIOAUpdate", "d2/d0a/icr__io_8h.html#a12d136fcd6e9ba2ad916c8513c75f45f", [
      [ "ICR_EI2OS_IOA_UPDATED", "d2/d0a/icr__io_8h.html#a12d136fcd6e9ba2ad916c8513c75f45fae753f8526a859b7a5b0075116f6ecc08", null ],
      [ "ICR_EI2OS_IOA_FIXED", "d2/d0a/icr__io_8h.html#a12d136fcd6e9ba2ad916c8513c75f45fa39375846359f44f8720df0138b85524c", null ]
    ] ],
    [ "T_icrEI2OSState", "d2/d0a/icr__io_8h.html#a84bab2ed320b3e02a56a3ca06782c5d4", [
      [ "ICR_EI2OS_OPERATING", "d2/d0a/icr__io_8h.html#a84bab2ed320b3e02a56a3ca06782c5d4af9a3c51606c772331ec0f2b31f55e641", null ],
      [ "ICR_EI2OS_STOP_EOC", "d2/d0a/icr__io_8h.html#a84bab2ed320b3e02a56a3ca06782c5d4aaaa8dcdadd89c05f1a8ed407674975b1", null ],
      [ "ICR_EI2OS_RSV", "d2/d0a/icr__io_8h.html#a84bab2ed320b3e02a56a3ca06782c5d4a15e26f7c06eaf51e158c1034b08c09f0", null ],
      [ "ICR_EI2OS_STOP_RES_REQ", "d2/d0a/icr__io_8h.html#a84bab2ed320b3e02a56a3ca06782c5d4a279bb03956771b90d87ec81efcfd60a4", null ]
    ] ],
    [ "T_icrEI2OSTermCtrl", "d2/d0a/icr__io_8h.html#a8e559e1fcc2436ade68364cb117e2bd5", [
      [ "ICR_EI2OS_NOTERM", "d2/d0a/icr__io_8h.html#a8e559e1fcc2436ade68364cb117e2bd5aa89ec0f0a252e622a2f0d03b6b15134a", null ],
      [ "ICR_EI2OS_TERM_RES_REQ", "d2/d0a/icr__io_8h.html#a8e559e1fcc2436ade68364cb117e2bd5a73b2ee66fb7c3c6e1e5a0c4e21b02bcb", null ]
    ] ],
    [ "T_icrINT", "d2/d0a/icr__io_8h.html#a2e821b0287fe17204b9d1d2957ae7310", [
      [ "ICR_INT_NORMAL", "d2/d0a/icr__io_8h.html#a2e821b0287fe17204b9d1d2957ae7310a54ea0d9a6eacf83c81f79b16774e1aeb", null ],
      [ "ICR_INT_EI2OS", "d2/d0a/icr__io_8h.html#a2e821b0287fe17204b9d1d2957ae7310aafe014e3ef99553f8f8a4c92718f326a", null ]
    ] ],
    [ "T_icrINTLevel", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910", [
      [ "ICR_LVL_0", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910a02c0eab7845ede123897afaad6541299", null ],
      [ "ICR_LVL_1", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910a29f7d22f9715703f571fb4b7546a47e6", null ],
      [ "ICR_LVL_2", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910a3e06ebca5c3041fde471eca942f93cd0", null ],
      [ "ICR_LVL_3", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910ab17ccc9e2e7c98012d0eb61eb64819c6", null ],
      [ "ICR_LVL_4", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910a2043f6ea8fe791078ea7d853dd74b6a1", null ],
      [ "ICR_LVL_5", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910a78a80b5ad2b1bc63489ef0f3ddff24af", null ],
      [ "ICR_LVL_6", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910ad221217b1caadd4287f65dabe07ff79c", null ],
      [ "ICR_LVL_7", "d2/d0a/icr__io_8h.html#a9de2960c9c89f6ab6757a13097c5a910aeb525d69bb6d3a2c2439a325888d46d1", null ]
    ] ]
];