var union_t__wtc =
[
    [ "bit", "d2/d4f/union_t__wtc.html#ac86e3a35104bbec04030d5f566f02d5e", null ],
    [ "byte", "d2/d4f/union_t__wtc.html#a124424e56e1a244d30ae9639248154c2", null ],
    [ "SCE", "d2/d4f/union_t__wtc.html#ae0877a8393f1ea932b5a922110e827da", null ],
    [ "WDCS", "d2/d4f/union_t__wtc.html#a0afaae07ae054457f55573c42ee1e6d0", null ],
    [ "WTC", "d2/d4f/union_t__wtc.html#a214d73d9ab74055467566116562e1501", null ],
    [ "WTIE", "d2/d4f/union_t__wtc.html#aecdc1f52daea874d1270e576242060c9", null ],
    [ "WTOF", "d2/d4f/union_t__wtc.html#a7a65e66d38cfee09a078d58cd4f5fc4c", null ],
    [ "WTR", "d2/d4f/union_t__wtc.html#aaa08d9218c4c79ed3a79bbb2bd7d0139", null ]
];