var union_t__tccs =
[
    [ "__pad0__", "d2/dc3/union_t__tccs.html#ac9d05469b0331a4f6f912323419cfab9", null ],
    [ "bit", "d2/dc3/union_t__tccs.html#a350fcd1e984383b9eb30891319c578e5", null ],
    [ "byte", "d2/dc3/union_t__tccs.html#ae22929d6489212367e3d8422fa60a239", null ],
    [ "CLK", "d2/dc3/union_t__tccs.html#a629f4a35cb4d0845742b8f5dc7ad345f", null ],
    [ "CLR", "d2/dc3/union_t__tccs.html#a26f9f6a32529b68b5413720ae9d47688", null ],
    [ "IVF", "d2/dc3/union_t__tccs.html#a521f29d326f75c726e6bb168a409be52", null ],
    [ "IVFE", "d2/dc3/union_t__tccs.html#a8815864b2fde95ba5c7cce06b9059911", null ],
    [ "STOP", "d2/dc3/union_t__tccs.html#aa3959548b9a47a5fb325d22dc4c5196b", null ]
];