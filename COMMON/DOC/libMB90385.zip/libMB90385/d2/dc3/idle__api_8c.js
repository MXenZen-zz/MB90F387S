var idle__api_8c =
[
    [ "idleTaskRoutine", "d2/dc3/idle__api_8c.html#aa54849d1de8024d837750b969dd83981", null ]
];