var union_t__prl01 =
[
    [ "byte", "d2/d8e/union_t__prl01.html#a5d335bd19945e7cd188eb5ecd2eb2262", null ],
    [ "dword", "d2/d8e/union_t__prl01.html#a528f24f99dd3f2eeff687c665e4c7826", null ],
    [ "PRL0", "d2/d8e/union_t__prl01.html#a3b23184358b1ae7d01b72a4eb2f1eea9", null ],
    [ "PRL1", "d2/d8e/union_t__prl01.html#a9a604a101989a87c28f089054e69dd5b", null ],
    [ "PRLH0", "d2/d8e/union_t__prl01.html#aae7f475a6665e6ce47b3ddcedb2b036b", null ],
    [ "PRLH1", "d2/d8e/union_t__prl01.html#a352145aaa840940670435f53b7fdb0d7", null ],
    [ "PRLL0", "d2/d8e/union_t__prl01.html#ac3a41afa7a95d5bc2bf3e1d564727ade", null ],
    [ "PRLL1", "d2/d8e/union_t__prl01.html#af3adfbf95747d10fab80d4a585c41f62", null ],
    [ "word", "d2/d8e/union_t__prl01.html#a99b7551e86872a105cec33e921245805", null ]
];