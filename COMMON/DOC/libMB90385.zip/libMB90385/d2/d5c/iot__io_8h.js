var iot__io_8h =
[
    [ "ClearIOTCounter", "d2/d5c/iot__io_8h.html#a4e7d467ab26ed71bcfd95ec07d191ac1", null ],
    [ "ClearIOTIRQ", "d2/d5c/iot__io_8h.html#a7cdf222ae7d8adba09da16e2f0d1965d", null ],
    [ "DisableIOTInterrupt", "d2/d5c/iot__io_8h.html#a69938067cf9dc77102aa4e0be8513c17", null ],
    [ "EnableIOTInterrupt", "d2/d5c/iot__io_8h.html#a0d87dcf0c07da8d0a028ad48f8096d58", null ],
    [ "GetIOT_TCCS", "d2/d5c/iot__io_8h.html#a6f72997f193cba22bc752551355eea37", null ],
    [ "GetIOT_TCDT", "d2/d5c/iot__io_8h.html#a74f50fb4494abaffb19e64631358fb65", null ],
    [ "IOT_CLEAR_CTR", "d2/d5c/iot__io_8h.html#a1a98f847f3e72fc20a2b3990e2155864", null ],
    [ "SetIOT_TCCS", "d2/d5c/iot__io_8h.html#adc2810140a2487e668436047ff095c84", null ],
    [ "SetIOT_TCDT", "d2/d5c/iot__io_8h.html#abee254274da7709c4b70a8b5a0f66737", null ],
    [ "SetIOTCountClock", "d2/d5c/iot__io_8h.html#a71dd5e3a451e776d7cc0fe27762be749", null ],
    [ "StartIOT", "d2/d5c/iot__io_8h.html#a6ff1bde682094c306c8ded1b8c5a6b8b", null ],
    [ "StopIOT", "d2/d5c/iot__io_8h.html#ab5a499707352329a778d0f39bdbfb04a", null ],
    [ "T_iotCntClk", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051", [
      [ "IOT_CLK_1T", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051ae81d20f64fb4059395c32bb0c084c792", null ],
      [ "IOT_CLK_2T", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051a23843736606ed890814d5625cb1ba5d3", null ],
      [ "IOT_CLK_4T", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051ac229db9451661cdf5ece403228d7a3f4", null ],
      [ "IOT_CLK_8T", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051aec064dd8b857049e02e2964411367f3c", null ],
      [ "IOT_CLK_16T", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051a7ffde8830e32491bf91a7c61da3b7aa8", null ],
      [ "IOT_CLK_32T", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051a2c064e2975cf5e29e43396b7cbfa70cd", null ],
      [ "IOT_CLK_64T", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051ab56c7ca3fb2b3db69cf052bf45364d14", null ],
      [ "IOT_CLK_128T", "d2/d5c/iot__io_8h.html#ad43e68215614964def432a3fb3bc8051a1cb885b31a2e882e5ede0f5cbf65efe8", null ]
    ] ],
    [ "T_iotINTEnable", "d2/d5c/iot__io_8h.html#a91a357e650fc33ab987a4a8a23840110", [
      [ "IOT_INT_DISABLED", "d2/d5c/iot__io_8h.html#a91a357e650fc33ab987a4a8a23840110a8d8577c8794d2e584921dc5e371e228f", null ],
      [ "IOT_INT_ENABLED", "d2/d5c/iot__io_8h.html#a91a357e650fc33ab987a4a8a23840110aa447eb24c9064910bbb7260355af9522", null ]
    ] ],
    [ "T_iotIRQ", "d2/d5c/iot__io_8h.html#a255d2d40aa1420f38fe561c2cf0cb80a", [
      [ "IOT_IRQ_CLEARED", "d2/d5c/iot__io_8h.html#a255d2d40aa1420f38fe561c2cf0cb80aa37797a53f7c0a9342db0c500c8bcf84a", null ],
      [ "IOT_IRQ_OVERFLOWED", "d2/d5c/iot__io_8h.html#a255d2d40aa1420f38fe561c2cf0cb80aaab64f1223ec9627f543ede4586457179", null ]
    ] ],
    [ "T_iotSWStart", "d2/d5c/iot__io_8h.html#aaa96e70bbe4ff681f8ab960ea8bb1489", [
      [ "IOT_CNT_ENABLED", "d2/d5c/iot__io_8h.html#aaa96e70bbe4ff681f8ab960ea8bb1489a698b7fa42aec28853c7972346e0b5c85", null ],
      [ "IOT_CNT_DISABLED", "d2/d5c/iot__io_8h.html#aaa96e70bbe4ff681f8ab960ea8bb1489a0d249aadd05514eb9986fa1bab41cbaa", null ]
    ] ]
];