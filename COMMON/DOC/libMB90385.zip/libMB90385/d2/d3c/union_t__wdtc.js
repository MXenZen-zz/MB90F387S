var union_t__wdtc =
[
    [ "__pad0__", "d2/d3c/union_t__wdtc.html#a42c71b56e21b6174bf60fc092577cf01", null ],
    [ "bit", "d2/d3c/union_t__wdtc.html#a163b4aef91560215914a6f8a2732f425", null ],
    [ "byte", "d2/d3c/union_t__wdtc.html#a5d4e0d4dd61172e848b6178aa2f25ba6", null ],
    [ "ERST", "d2/d3c/union_t__wdtc.html#a2c65883574f8b295ff16c75bbb7be720", null ],
    [ "PONR", "d2/d3c/union_t__wdtc.html#a1ff67f3fe834b8caa4b3403096d6bf8d", null ],
    [ "SRST", "d2/d3c/union_t__wdtc.html#adacdf9cc8c563d2fa74ce9ec2bd10985", null ],
    [ "WRST", "d2/d3c/union_t__wdtc.html#a50eab7f36c3da98c496e9126e2611dbc", null ],
    [ "WT", "d2/d3c/union_t__wdtc.html#aeea239d009fa72722b1065f34473e03a", null ],
    [ "WTE", "d2/d3c/union_t__wdtc.html#a380a14c600a67fe857fdabc1a462e34a", null ]
];