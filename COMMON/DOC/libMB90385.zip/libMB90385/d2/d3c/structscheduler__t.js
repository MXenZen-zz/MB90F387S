var structscheduler__t =
[
    [ "linkedTask", "d2/d3c/structscheduler__t.html#a525c52f1ed57a724521d32031284cb36", null ],
    [ "scheduling", "d2/d3c/structscheduler__t.html#ae45bdac31e782411bc8e2c5797d52ccc", null ]
];