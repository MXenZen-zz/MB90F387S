var union_t__ddr2 =
[
    [ "bit", "d7/d25/union_t__ddr2.html#a033ca965f91c63252794cde434aacba4", null ],
    [ "byte", "d7/d25/union_t__ddr2.html#a47c135fbce8eac2b9ccca362dfe66633", null ],
    [ "D20", "d7/d25/union_t__ddr2.html#af7a9a2a6d74b7f1d61c15bdd307d618c", null ],
    [ "D21", "d7/d25/union_t__ddr2.html#a97c690d4915df8ab3bdfeaf7841d8601", null ],
    [ "D22", "d7/d25/union_t__ddr2.html#a1aed4cbcd688b9878503ea5d7b9c3033", null ],
    [ "D23", "d7/d25/union_t__ddr2.html#a6388b4e9ef4e75100654f375075c1b99", null ],
    [ "D24", "d7/d25/union_t__ddr2.html#a2076f50231153781f8a160ea8ac9e666", null ],
    [ "D25", "d7/d25/union_t__ddr2.html#a2dc9e98f7c0466feaf0d681eb0741131", null ],
    [ "D26", "d7/d25/union_t__ddr2.html#aa88955170a8cfaf1adad217afa588fbd", null ],
    [ "D27", "d7/d25/union_t__ddr2.html#a7ba1714ad43b964cfcfef4f66ca16bb1", null ]
];