var rlt__types_8h =
[
    [ "RLT_TRIG_SW_START", "d7/d8d/rlt__types_8h.html#afe71491ea5f0e2e1c12fb15f73cf7967", null ],
    [ "T_rltCntClk", "d7/d8d/rlt__types_8h.html#a8b1555f1cbeec6440f405311ce095cbe", [
      [ "RLT_CLK_2T", "d7/d8d/rlt__types_8h.html#a8b1555f1cbeec6440f405311ce095cbeae7fd53dcd04848d38099286423a8f8ad", null ],
      [ "RLT_CLK_8T", "d7/d8d/rlt__types_8h.html#a8b1555f1cbeec6440f405311ce095cbea530644bad6befe5d35204f39d5b389d8", null ],
      [ "RLT_CLK_32T", "d7/d8d/rlt__types_8h.html#a8b1555f1cbeec6440f405311ce095cbea2fad0c2563613d3a3ebd5a80f6261b54", null ],
      [ "RLT_CLK_EXT_EVT", "d7/d8d/rlt__types_8h.html#a8b1555f1cbeec6440f405311ce095cbea68f746517464da8d04f8e32781886d7b", null ]
    ] ],
    [ "T_rltINTEnable", "d7/d8d/rlt__types_8h.html#a65d6cd82ddeecf710648621f65d1862f", [
      [ "RLT_INT_DISABLED", "d7/d8d/rlt__types_8h.html#a65d6cd82ddeecf710648621f65d1862fabf45b5633b90ad307ec4aa92488d49b0", null ],
      [ "RLT_INT_ENABLED", "d7/d8d/rlt__types_8h.html#a65d6cd82ddeecf710648621f65d1862fa8a6dde680fcbd3ebb99a06a72c5c0f35", null ]
    ] ],
    [ "T_rltIRQ", "d7/d8d/rlt__types_8h.html#a0ed4d48f9d7d0edecb146cdab5685dfd", [
      [ "RLT_IRQ_CLEARED", "d7/d8d/rlt__types_8h.html#a0ed4d48f9d7d0edecb146cdab5685dfdabd91cf09ee958bc0ffd99ab0e9471814", null ],
      [ "RLT_IRQ_UNDERFLOWED", "d7/d8d/rlt__types_8h.html#a0ed4d48f9d7d0edecb146cdab5685dfdac15974f05b3b7df3de25abab2774fa68", null ]
    ] ],
    [ "T_rltOpAtUF", "d7/d8d/rlt__types_8h.html#aeeb208e7608716428c614d9cf68e850b", [
      [ "RLT_ONESHOT", "d7/d8d/rlt__types_8h.html#aeeb208e7608716428c614d9cf68e850ba628f46e27f28c44d8c9aa040b6c9af82", null ],
      [ "RLT_RELOAD", "d7/d8d/rlt__types_8h.html#aeeb208e7608716428c614d9cf68e850bad2091b64466d19b1bc2ccbf0f6e76b16", null ]
    ] ],
    [ "T_rltOperation", "d7/d8d/rlt__types_8h.html#a1d211fb50a54943a05d9f084fdbc9ffe", [
      [ "RLT_OP_DISABLED", "d7/d8d/rlt__types_8h.html#a1d211fb50a54943a05d9f084fdbc9ffeab433c450e615efdc36ae5176aa6f015b", null ],
      [ "RLT_OP_ENABLED", "d7/d8d/rlt__types_8h.html#a1d211fb50a54943a05d9f084fdbc9ffea1183a78eb2e4f4f88eb2ba2dbd665a5d", null ]
    ] ],
    [ "T_rltOpMode", "d7/d8d/rlt__types_8h.html#a3637cf48fe0eb45f8384534d425bb0c7", [
      [ "RLT_MOD_TRIG_DISABLED", "d7/d8d/rlt__types_8h.html#a3637cf48fe0eb45f8384534d425bb0c7a7412525d68eb05ae171432391a16021e", null ],
      [ "RLT_MOD_TRIG_RISE", "d7/d8d/rlt__types_8h.html#a3637cf48fe0eb45f8384534d425bb0c7a384c5df80c681ea1a1da67bc42e9ebd7", null ],
      [ "RLT_MOD_TRIG_FALL", "d7/d8d/rlt__types_8h.html#a3637cf48fe0eb45f8384534d425bb0c7a0109fdb01b7cbaecd302a1918f57c0f6", null ],
      [ "RLT_MOD_TRIG_BOTH", "d7/d8d/rlt__types_8h.html#a3637cf48fe0eb45f8384534d425bb0c7a96e1477b6368cd6613c7b1093db8d7dc", null ],
      [ "RLT_MOD_GATE_LOW", "d7/d8d/rlt__types_8h.html#a3637cf48fe0eb45f8384534d425bb0c7afc39727a37f501af60690f09cbb22114", null ],
      [ "RLT_MOD_GATE_HIGH", "d7/d8d/rlt__types_8h.html#a3637cf48fe0eb45f8384534d425bb0c7a22c264eaf5d56ab0882ffbc275805ea9", null ]
    ] ],
    [ "T_rltTOTOutLevel", "d7/d8d/rlt__types_8h.html#a3a34cc89e8593ee81f7b445c5eca872e", [
      [ "RLT_TOT_OUT_HRECT", "d7/d8d/rlt__types_8h.html#a3a34cc89e8593ee81f7b445c5eca872eac18b33cb2a6c4534bdaa259749946c17", null ],
      [ "RLT_TOT_OUT_LTOGGLE", "d7/d8d/rlt__types_8h.html#a3a34cc89e8593ee81f7b445c5eca872ea1a6da7e84237c089776103bb885761b9", null ],
      [ "RLT_TOT_OUT_LRECT", "d7/d8d/rlt__types_8h.html#a3a34cc89e8593ee81f7b445c5eca872ead3d18ac4d7932f84ee61b3321ab17293", null ],
      [ "RLT_TOT_OUT_HTOGGLE", "d7/d8d/rlt__types_8h.html#a3a34cc89e8593ee81f7b445c5eca872eae8aa43d8016f74d224ba4e025227d768", null ]
    ] ],
    [ "T_rltTOTPin", "d7/d8d/rlt__types_8h.html#a9acb63c76612889d7596229d62d9d93f", [
      [ "RLT_TOT_GPIO", "d7/d8d/rlt__types_8h.html#a9acb63c76612889d7596229d62d9d93fa8a4a1984d5a343482076b663c9b0a6d4", null ],
      [ "RLT_TOT_ENABLED", "d7/d8d/rlt__types_8h.html#a9acb63c76612889d7596229d62d9d93fa2d4153040b0c17d6e1934c9847068448", null ]
    ] ]
];