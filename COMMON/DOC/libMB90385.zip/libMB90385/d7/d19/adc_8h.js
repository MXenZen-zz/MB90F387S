var adc_8h =
[
    [ "ADC_DEF_CT", "d7/d19/adc_8h.html#a60eaef1d8b605fca2683b7442f72cd83", null ],
    [ "ADC_DEF_RES", "d7/d19/adc_8h.html#af8f3a41f3ddc43fec34eb48a77659728", null ],
    [ "ADC_DEF_ST", "d7/d19/adc_8h.html#a984c35a37a23e9c74896a3f46478dbe4", null ],
    [ "GetWordADCRead", "d7/d19/adc_8h.html#a6184eeed414a3af134e24d4a666c35de", null ],
    [ "T_adcBuffer", "d7/d19/adc_8h.html#af5620a83773b50e1334573aa8082148b", null ],
    [ "T_adcISRHook", "d7/d19/adc_8h.html#acbfc3d66ff8969f655498b20ddb6810d", null ],
    [ "ADC_IRQHandler", "d7/d19/adc_8h.html#a181f52c18c73753c57ca5fe2167a9242", null ],
    [ "initADC", "d7/d19/adc_8h.html#a7fc456cdfe3a3afe58e84832b3ac2c5b", null ],
    [ "pinModeAnalog", "d7/d19/adc_8h.html#a45d2b37e7b4f5b80522037f8f88d7ea5", null ],
    [ "portModeAnalog", "d7/d19/adc_8h.html#af3038ceed49e126939ed36e9961695d1", null ],
    [ "readAnalog", "d7/d19/adc_8h.html#afc8aa739c700503bfbe786d76c8f5392", null ],
    [ "startADCGroup", "d7/d19/adc_8h.html#a416f6d186434d1a439f57c7f9325cf1b", null ],
    [ "stopADCGroup", "d7/d19/adc_8h.html#aa7b33fa7f9dafc025c068ff94c326484", null ],
    [ "pADCBuffer", "d7/d19/adc_8h.html#ac24f4935aca6b541c225811f532c345c", null ],
    [ "PRIO_ADC_ISR", "d7/d19/adc_8h.html#a8a0dfac151a35e693e22b189b9d1ecc9", null ]
];