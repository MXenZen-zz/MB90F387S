var can__io_8h =
[
    [ "CancelCANTransmit", "d7/d0d/can__io_8h.html#a40e55eafe450721f414ba8a4fc0ad702", null ],
    [ "ClearCANLENodeTransition", "d7/d0d/can__io_8h.html#a37bf51c2a5838acfe89c647c1778b038", null ],
    [ "ClearCANLEReception", "d7/d0d/can__io_8h.html#abb5a4ced50b3939584494694b466e76a", null ],
    [ "ClearCANLETransmission", "d7/d0d/can__io_8h.html#a0887caedf5ac1343ff552c73f7e6be33", null ],
    [ "ClearCANNSTransition", "d7/d0d/can__io_8h.html#aeae407ebcda4b2cc81b303243247adfd", null ],
    [ "ClearCANReceiveComp", "d7/d0d/can__io_8h.html#affd5ec598876164e18667414f3318ea1", null ],
    [ "ClearCANReceiveOvr", "d7/d0d/can__io_8h.html#aaac09d8d49cb8b6fb5788de22db79656", null ],
    [ "ClearCANReceiveRTRComp", "d7/d0d/can__io_8h.html#a3c5bb3259b0d3218550a4bd5df09eb36", null ],
    [ "ClearCANTransmitComp", "d7/d0d/can__io_8h.html#ae0988c659cb766799b1021c37b650c3a", null ],
    [ "DisableCANMsgBuff", "d7/d0d/can__io_8h.html#af3e4d513460565dc49ee298bb78876a1", null ],
    [ "DisableCANNSInterrupt", "d7/d0d/can__io_8h.html#a24603f2ac268e0589011a5e0694372e0", null ],
    [ "DisableCANReceptionINT", "d7/d0d/can__io_8h.html#a30f26a95e4f922ba0c1b1a0462b77df1", null ],
    [ "DisableCANTransmitINT", "d7/d0d/can__io_8h.html#a345357524abe2b23c2e9184709dc800c", null ],
    [ "DisableCANTxOutputPin", "d7/d0d/can__io_8h.html#a5d112a98e3017bbce50500501109fbea", null ],
    [ "EnableCANMsgBuff", "d7/d0d/can__io_8h.html#ac794e31b686d9f72d0665471a1aadf3b", null ],
    [ "EnableCANNSInterrupt", "d7/d0d/can__io_8h.html#ad3b9d60b5503d61d77b8b3211d48bf72", null ],
    [ "EnableCANReceptionINT", "d7/d0d/can__io_8h.html#a2ce16570a04e0ea01581b22c5174b756", null ],
    [ "EnableCANTransmitINT", "d7/d0d/can__io_8h.html#ac268f6bb0d78b0723fd64edb3a35090a", null ],
    [ "EnableCANTxOutputPin", "d7/d0d/can__io_8h.html#ad916b7bb571f183406b47b7a5a8c1fc6", null ],
    [ "GetCAN_AMR0", "d7/d0d/can__io_8h.html#a022133bf273238133e688efc69b99f6d", null ],
    [ "GetCAN_AMR1", "d7/d0d/can__io_8h.html#af4f0ced56f989e2c9c9ce2f9891baa44", null ],
    [ "GetCAN_AMSR", "d7/d0d/can__io_8h.html#a65e7be3688f3b062271656b199008561", null ],
    [ "GetCAN_BTR", "d7/d0d/can__io_8h.html#ae2f709265d33d9979acc3e0dda716b71", null ],
    [ "GetCAN_BVALR", "d7/d0d/can__io_8h.html#a9cac07aa9cb8b0c50a8c51d9cad0f5bc", null ],
    [ "GetCAN_CSR", "d7/d0d/can__io_8h.html#a72967c9879d14c2c182a0519268dc641", null ],
    [ "GetCAN_DLCR", "d7/d0d/can__io_8h.html#a6ceb3c7d6dd675900a9ea9b2dc59e8e2", null ],
    [ "GetCAN_DTR_BYTE", "d7/d0d/can__io_8h.html#a7d4f84d62c398f281f325ce5c0a6ab17", null ],
    [ "GetCAN_DTR_DOUBLE", "d7/d0d/can__io_8h.html#aabadfacc1467fd4b7228d8106c46933e", null ],
    [ "GetCAN_DTR_DWORD", "d7/d0d/can__io_8h.html#a995c8b743ba037a5433e2894ce578c2a", null ],
    [ "GetCAN_DTR_FLOAT", "d7/d0d/can__io_8h.html#a1a0cd4979a60e5faaf6d98aba8baf193", null ],
    [ "GetCAN_DTR_WORD", "d7/d0d/can__io_8h.html#af1deed80ad6cefb67b9dccf246571a13", null ],
    [ "GetCAN_IDER", "d7/d0d/can__io_8h.html#a47e0db5f321b15e91868bf37b07af38b", null ],
    [ "GetCAN_IDR", "d7/d0d/can__io_8h.html#a98e65f2b1e6f668219e4a1102a10f6ae", null ],
    [ "GetCAN_LEIR", "d7/d0d/can__io_8h.html#afdb1c8c4e7a0d92fb3b85f313f7db197", null ],
    [ "GetCAN_RCR", "d7/d0d/can__io_8h.html#a2f49d74115d4ef18132d546ca7cb92e8", null ],
    [ "GetCAN_REC", "d7/d0d/can__io_8h.html#a5b19f729184a310c4ef192b530045f5a", null ],
    [ "GetCAN_RFWTR", "d7/d0d/can__io_8h.html#a627768d38b7b9d3e4b5c2c02c5ebc0d1", null ],
    [ "GetCAN_RIER", "d7/d0d/can__io_8h.html#a8237e588f43727e4c2e5583455dae348", null ],
    [ "GetCAN_ROVRR", "d7/d0d/can__io_8h.html#a62cb6aada555922483f83d1c6ef8a089", null ],
    [ "GetCAN_RRTRR", "d7/d0d/can__io_8h.html#a98c503754448ede87983fc517b6c6cd3", null ],
    [ "GetCAN_TCANR", "d7/d0d/can__io_8h.html#ac750b5273c9b687f6583f4d2d0d32f71", null ],
    [ "GetCAN_TCR", "d7/d0d/can__io_8h.html#ad19c1badef29e19b9b31ea36a80e613d", null ],
    [ "GetCAN_TEC", "d7/d0d/can__io_8h.html#ac46b62f33f00b1e72fcd309fcb034bd4", null ],
    [ "GetCAN_TIER", "d7/d0d/can__io_8h.html#af703b36aaf9d52165e5ec87522e10022", null ],
    [ "GetCAN_TREQR", "d7/d0d/can__io_8h.html#a4e9992e021a2fbc64842cca7b331ad09", null ],
    [ "GetCAN_TRTRR", "d7/d0d/can__io_8h.html#aacedc0c75cdc436f8a0e4de81b861ee0", null ],
    [ "GetCANNodeStatus", "d7/d0d/can__io_8h.html#a4ddd9b4b50aa07de2f533414619a1a72", null ],
    [ "IsCANBusOpHalted", "d7/d0d/can__io_8h.html#a8790ab59119652131ab3afbafb9aa390", null ],
    [ "IsCANLENodeTransition", "d7/d0d/can__io_8h.html#a10ffa090a0992490315905dc6b27e6a3", null ],
    [ "IsCANLEReception", "d7/d0d/can__io_8h.html#aeeaf4c07af004e237dfa3139c246eae8", null ],
    [ "IsCANLETransmission", "d7/d0d/can__io_8h.html#a470db4688e3966f87f9bd9574420635a", null ],
    [ "IsCANMsgOnReception", "d7/d0d/can__io_8h.html#a6fb32327ffe431c4b9b19aacb37a06d7", null ],
    [ "IsCANMsgOnTransmission", "d7/d0d/can__io_8h.html#afe1b0f60c76ccd1376dd8b343ac110d4", null ],
    [ "IsCANNSBusOff", "d7/d0d/can__io_8h.html#a8b594a41d5bd035f6f7bd38abf5d75b6", null ],
    [ "IsCANNSErrActive", "d7/d0d/can__io_8h.html#ac92f1245a0f8f32e3a0071bc099e9af7", null ],
    [ "IsCANNSErrPassive", "d7/d0d/can__io_8h.html#a8be15b36c8c170fd2a8dd3da073e9443", null ],
    [ "IsCANNSTransition", "d7/d0d/can__io_8h.html#af03f3fd56ef997ec12dd81f73afc2b79", null ],
    [ "IsCANNSWarning", "d7/d0d/can__io_8h.html#ac7a8776ede93d0bf8ef00654f04857b6", null ],
    [ "IsCANReceiveComp", "d7/d0d/can__io_8h.html#a050adbf5f47b51f06086fe9be99bab2c", null ],
    [ "IsCANReceiveOvr", "d7/d0d/can__io_8h.html#ad11b0c700b1c19be9d7d3356e812fc7d", null ],
    [ "IsCANReceiveRTRComp", "d7/d0d/can__io_8h.html#a46577906b2a9a866979f3798a7e1ce1e", null ],
    [ "IsCANTransmitComp", "d7/d0d/can__io_8h.html#a6451c4774bdbe4bdb9f132ce583286f5", null ],
    [ "RequestCANNoTransmit", "d7/d0d/can__io_8h.html#ab065e3e233156f49e0e614a9e280f353", null ],
    [ "RequestCANTransmit", "d7/d0d/can__io_8h.html#a417926d9d6999dc971e5fb55c35ac70b", null ],
    [ "SetCAN_AMR0", "d7/d0d/can__io_8h.html#aa92ff78a8064c960f1473467bcc1a1cd", null ],
    [ "SetCAN_AMR1", "d7/d0d/can__io_8h.html#aa7d31e0eca0b95623b72a98f68c786f6", null ],
    [ "SetCAN_AMSR", "d7/d0d/can__io_8h.html#abe3cf91b9e31d784eab1e695fbcb3620", null ],
    [ "SetCAN_BTR", "d7/d0d/can__io_8h.html#a343e7d02481d9d06b9bed4f9e5bdda78", null ],
    [ "SetCAN_BVALR", "d7/d0d/can__io_8h.html#a715e940e48efdd4859255bd92ec78868", null ],
    [ "SetCAN_CSR", "d7/d0d/can__io_8h.html#a96c0ce16f8842eb7ff2a46b2e3fc289a", null ],
    [ "SetCAN_DLCR", "d7/d0d/can__io_8h.html#a19f1207f7e931e70185842a4ed3c8e10", null ],
    [ "SetCAN_DTR_DOUBLE", "d7/d0d/can__io_8h.html#a2443f5cb7994c58d52d73e4ee0b466e7", null ],
    [ "SetCAN_DTR_DWORD", "d7/d0d/can__io_8h.html#ad0a4a702513ab8c5b087276d3f7e0a53", null ],
    [ "SetCAN_DTR_FLOAT", "d7/d0d/can__io_8h.html#ac32bf2bcb35d83ba0c17dc137e60c9f2", null ],
    [ "SetCAN_DTR_WORD", "d7/d0d/can__io_8h.html#a4f9eca6fb7e949ea3fcf214757c06056", null ],
    [ "SetCAN_IDER", "d7/d0d/can__io_8h.html#a2f50f98f3cf7bda6d400e041160528be", null ],
    [ "SetCAN_IDR", "d7/d0d/can__io_8h.html#a132a8b42241c922c70eb098ee107d411", null ],
    [ "SetCAN_LEIR", "d7/d0d/can__io_8h.html#aba56f1fe0185e42e6864ed8b06bd6950", null ],
    [ "SetCAN_RCR", "d7/d0d/can__io_8h.html#a79fe54f7131ef99147890ef87eb816cc", null ],
    [ "SetCAN_RFWTR", "d7/d0d/can__io_8h.html#a2c6c3f831364c9e217816669073eb380", null ],
    [ "SetCAN_RIER", "d7/d0d/can__io_8h.html#ab23584d1306fff4352ccecde1b7a39d0", null ],
    [ "SetCAN_ROVRR", "d7/d0d/can__io_8h.html#ad15739cb775effdd7fb43438513243f9", null ],
    [ "SetCAN_RRTRR", "d7/d0d/can__io_8h.html#a7b13031b6950f7cb5fe31828e5bdd3d8", null ],
    [ "SetCAN_TCANR", "d7/d0d/can__io_8h.html#a307b82afe6962f2b097d56325ef1c6b0", null ],
    [ "SetCAN_TCR", "d7/d0d/can__io_8h.html#afb74e6f638473b17c9c7bb3e04b11d11", null ],
    [ "SetCAN_TIER", "d7/d0d/can__io_8h.html#a9b394b0392550f2da7d17e6aa8394518", null ],
    [ "SetCAN_TREQR", "d7/d0d/can__io_8h.html#aa8f02838371516900df54add9e38ec65", null ],
    [ "SetCAN_TRTRR", "d7/d0d/can__io_8h.html#aca85fdc7fdb7187ef27268f2ff428a21", null ],
    [ "SetCANAccMaskOption", "d7/d0d/can__io_8h.html#a1e57def1c6863d5e4a6768e87af441dc", null ],
    [ "SetCANIDEExtendedFormat", "d7/d0d/can__io_8h.html#a1401911a8195935a50276eab00c1255f", null ],
    [ "SetCANIDEStandardFormat", "d7/d0d/can__io_8h.html#a11c54aadfea5bc6fa7720215b60bd953", null ],
    [ "SetCANPrescaler", "d7/d0d/can__io_8h.html#a8a34fdfc19cacebc5dd5ae3fb440a580", null ],
    [ "SetCANResyncJumpWidth", "d7/d0d/can__io_8h.html#aa8592f78cc2020dab0dd724f13433a49", null ],
    [ "SetCANTimeSegment1", "d7/d0d/can__io_8h.html#a837bf80229a72a4e4fd34242f7ecab89", null ],
    [ "SetCANTimeSegment2", "d7/d0d/can__io_8h.html#a4118a85adcaa19b6d820d53290d56595", null ],
    [ "StartCANAfterRFReceived", "d7/d0d/can__io_8h.html#a8a8d05754701ff9dcafacf7c7aa1311d", null ],
    [ "StartCANBusOp", "d7/d0d/can__io_8h.html#a9180c38de3b3f389ed5bbf71555ac095", null ],
    [ "StartCANTransmitImm", "d7/d0d/can__io_8h.html#a165628d8651a2604aa3239b86be824f1", null ],
    [ "StopCANBusOp", "d7/d0d/can__io_8h.html#a793052fc73868834f121075806abeec5", null ],
    [ "TransmitAsCANDataFrame", "d7/d0d/can__io_8h.html#a0827e0ab102ae546a03839d9d808fac5", null ],
    [ "TransmitAsCANRemoteFrame", "d7/d0d/can__io_8h.html#ab2677e1cbc278d49cfc5132eafbd35c0", null ],
    [ "T_canAccMaskOp", "d7/d0d/can__io_8h.html#a129d28530cfc8273e26017627801d18a", [
      [ "CAN_FULL_BIT_CMP", "d7/d0d/can__io_8h.html#a129d28530cfc8273e26017627801d18aa65a669472098d3835a8ac0a3ddaff7f5", null ],
      [ "CAN_FULL_BIT_MASK", "d7/d0d/can__io_8h.html#a129d28530cfc8273e26017627801d18aa4edf1e03b2423bbcc145e90190887b3f", null ],
      [ "CAN_USE_AMR0", "d7/d0d/can__io_8h.html#a129d28530cfc8273e26017627801d18aa6d184ed3361d43270f107cab366d544e", null ],
      [ "CAN_USE_AMR1", "d7/d0d/can__io_8h.html#a129d28530cfc8273e26017627801d18aa5057737509a677e1f8dc894414582162", null ]
    ] ],
    [ "T_canBitTimingSpeed", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9", [
      [ "CAN_BTR_10K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a94c85d59b4f1c3f82c7e93e550b048a9", null ],
      [ "CAN_BTR_20K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9aa5965893eb878bb395b62ac68670c870", null ],
      [ "CAN_BTR_20K8", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a6e2e7908d26c0aed90a93f380aed2e6e", null ],
      [ "CAN_BTR_25K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a44972e08d8688662cf2ad8d0894e905c", null ],
      [ "CAN_BTR_33K3", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9ae4fdb0244ca98c71869f1b549e13b111", null ],
      [ "CAN_BTR_40K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9af6b60a634d02ee6dfc46faf4bc2d60ec", null ],
      [ "CAN_BTR_50K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9ac2a06d44b73cb9116e6cae577451c295", null ],
      [ "CAN_BTR_83K3", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a65e179c84b12e30a81877934c1b50d4a", null ],
      [ "CAN_BTR_100K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a562296f64ce390d7c934a28ce4d57b7f", null ],
      [ "CAN_BTR_125K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9aaf8fabd2d406a038abc6471fcc44ce1e", null ],
      [ "CAN_BTR_200K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a4e767974bbda52e8d964f08ddd520343", null ],
      [ "CAN_BTR_250K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9ab860eebc25c22f19ead33e356663b7ea", null ],
      [ "CAN_BTR_400K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a7450847c0839253bdfee4e8c0275972f", null ],
      [ "CAN_BTR_500K", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a8fbb6bceee39ed7a63877b71db52886c", null ],
      [ "CAN_BTR_1M", "d7/d0d/can__io_8h.html#af187886adee916e66a2710f37aa2f0e9a8d3d8d90e89210fa5fe74c1a243219e2", null ]
    ] ],
    [ "T_canBus", "d7/d0d/can__io_8h.html#aa3d1999a1343a2636c77f6b3bb941173", [
      [ "CAN_CSR_STOP", "d7/d0d/can__io_8h.html#aa3d1999a1343a2636c77f6b3bb941173ac54c80e9f7d75ce71bb939ba39277403", null ],
      [ "CAN_CSR_START", "d7/d0d/can__io_8h.html#aa3d1999a1343a2636c77f6b3bb941173aeb5626f6a918ec41aab2b4b365f5d575", null ]
    ] ],
    [ "T_canBusHalt", "d7/d0d/can__io_8h.html#a5baaad95e60bac0297b253ae8874881f", [
      [ "CAN_BUS_OP_HALT_CANCELED", "d7/d0d/can__io_8h.html#a5baaad95e60bac0297b253ae8874881fa0ac9eacfe8db79a79a60ae70bb15e4fa", null ],
      [ "CAN_BUS_OP_HALTED", "d7/d0d/can__io_8h.html#a5baaad95e60bac0297b253ae8874881fa4c4948d0e1229e228aa23eac4a7d7da8", null ]
    ] ],
    [ "T_canDataLength", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152", [
      [ "CAN_DLC_0BYTE", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152aa7c133eead4bab7d98972f7c9a623fd8", null ],
      [ "CAN_DLC_1BYTE", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152af4832ae28e4b3b8408ec9cdb4f1b76cf", null ],
      [ "CAN_DLC_2BYTES", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152aa96afcc9f15d8ee02505292e28c1c629", null ],
      [ "CAN_DLC_3BYTES", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152a678f14e66033c65df2fcd67c698fc8d0", null ],
      [ "CAN_DLC_4BYTES", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152a7495c269bc809c6b1c4ecfb248e409a0", null ],
      [ "CAN_DLC_5BYTES", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152a6b0a5b464686001abeb2007517c3d424", null ],
      [ "CAN_DLC_6BYTES", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152ac48e522ac3eca6ddd20473fc60eb0db3", null ],
      [ "CAN_DLC_7BYTES", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152abc68d658b06836f83f65151ffa9e8f63", null ],
      [ "CAN_DLC_8BYTES", "d7/d0d/can__io_8h.html#a69f98ffee62cb4fff0e5e776ef46d152a89f5b1655511acba330ed7c6b4824108", null ]
    ] ],
    [ "T_canIDFormat", "d7/d0d/can__io_8h.html#ad6a9e5173f25f78f91b8bf93e02b5398", [
      [ "CAN_ID_STD_FORMAT", "d7/d0d/can__io_8h.html#ad6a9e5173f25f78f91b8bf93e02b5398ab6a718450d7cacc2dde7ff81d37e4c90", null ],
      [ "CAN_ID_EXT_FORMAT", "d7/d0d/can__io_8h.html#ad6a9e5173f25f78f91b8bf93e02b5398a5ecfafd7d1a0a1f96a97b318a7e66779", null ]
    ] ],
    [ "T_canLastEvent", "d7/d0d/can__io_8h.html#a022ce41cb313362bcc216c5969f485cd", [
      [ "CAN_LAST_EVT_RX_NONE", "d7/d0d/can__io_8h.html#a022ce41cb313362bcc216c5969f485cda062c549c2551718b5c54a6407a3192f6", null ],
      [ "CAN_LAST_EVT_TX_NONE", "d7/d0d/can__io_8h.html#a022ce41cb313362bcc216c5969f485cda729d36c8e068f126181315a6a3ec5dda", null ],
      [ "CAN_LAST_EVT_NS_NONE", "d7/d0d/can__io_8h.html#a022ce41cb313362bcc216c5969f485cda4d3a525943131a41e892094dc94e4b74", null ],
      [ "CAN_LAST_EVT_RX_SET", "d7/d0d/can__io_8h.html#a022ce41cb313362bcc216c5969f485cda3b4d94e0ee31200a982609e1f8459ded", null ],
      [ "CAN_LAST_EVT_TX_SET", "d7/d0d/can__io_8h.html#a022ce41cb313362bcc216c5969f485cdaba9b1a002876ab4d31a70bb585f487f5", null ],
      [ "CAN_LAST_EVT_NS_SET", "d7/d0d/can__io_8h.html#a022ce41cb313362bcc216c5969f485cdaca56085332378dbe19307d69f734e865", null ]
    ] ],
    [ "T_canMsgBuf", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63", [
      [ "CAN_MB_0", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63a264923f31004ebc9e36fe1e496820b02", null ],
      [ "CAN_MB_1", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63a6f03baa094198fb3638543ce2ed55274", null ],
      [ "CAN_MB_2", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63ae39ef49fa8693587de6e4c9c6bbefe39", null ],
      [ "CAN_MB_3", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63a67acd364bc433713cd1678d20f0245c8", null ],
      [ "CAN_MB_4", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63afd2ec85e2b2b83f0cb7191ef554aefd6", null ],
      [ "CAN_MB_5", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63af50a142f5a5456a1beceacbab5b10831", null ],
      [ "CAN_MB_6", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63a17a9a2d8e74b166209c06af6c4e7ee92", null ],
      [ "CAN_MB_7", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63abd7a99f376fb7a499f53fd4e837fbd55", null ],
      [ "CAN_MB_SIZE", "d7/d0d/can__io_8h.html#a16b2604934e3a9b30b9ba5c7800f0f63a50e11b3e7dfb545c3e89a60cbd1462c7", null ]
    ] ],
    [ "T_canMsgBufByteData", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05ef", [
      [ "CAN_MB_BYTE_0", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efa80ee385ebb05ab5d86618613b96b31dd", null ],
      [ "CAN_MB_BYTE_1", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efab696ef987c150f48fe8d5655734573e2", null ],
      [ "CAN_MB_BYTE_2", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efa1d6c34746eec51a8b2a032acdf8d4427", null ],
      [ "CAN_MB_BYTE_3", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efa704cb06e5b19776b87085d8137dc5d3b", null ],
      [ "CAN_MB_BYTE_4", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efa99847f9550f7a19db7a1c2507999a66a", null ],
      [ "CAN_MB_BYTE_5", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efa3010764fed67205642881282e1b7f33d", null ],
      [ "CAN_MB_BYTE_6", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efad8213152f86f96e7bdf86b280afd2066", null ],
      [ "CAN_MB_BYTE_7", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efa7b74a3df36f38447e5720cf92d1ccb37", null ],
      [ "CAN_MB_BYTE_SIZE", "d7/d0d/can__io_8h.html#ab2422bf2e4f2526bb70f7cb6096c05efa07e2980cbb0087b5135289ac6c014c55", null ]
    ] ],
    [ "T_canMsgBufDWordData", "d7/d0d/can__io_8h.html#a0def9bf8dce630877c804c3e71d8d10a", [
      [ "CAN_MB_DWORD_0", "d7/d0d/can__io_8h.html#a0def9bf8dce630877c804c3e71d8d10aa7eff0b2d0327b55b742fe4b5ac902ab3", null ],
      [ "CAN_MB_DWORD_1", "d7/d0d/can__io_8h.html#a0def9bf8dce630877c804c3e71d8d10aa42fff922db232c9485c2f2d2dcfec6bf", null ],
      [ "CAN_MB_DWORD_SIZE", "d7/d0d/can__io_8h.html#a0def9bf8dce630877c804c3e71d8d10aa4183e4640a7a8a6749701ea99a1b8672", null ]
    ] ],
    [ "T_canMsgBufFloat32Data", "d7/d0d/can__io_8h.html#abfc06cfc38051d1ada7ea5c5767e2f16", [
      [ "CAN_MB_FLOAT32_0", "d7/d0d/can__io_8h.html#abfc06cfc38051d1ada7ea5c5767e2f16ac88bbecab94182bf93737ea4fe5fb523", null ],
      [ "CAN_MB_FLOAT32_1", "d7/d0d/can__io_8h.html#abfc06cfc38051d1ada7ea5c5767e2f16a51ad5385514d1812fbf8545318a62100", null ],
      [ "CAN_MB_FLOAT32_SIZE", "d7/d0d/can__io_8h.html#abfc06cfc38051d1ada7ea5c5767e2f16a88962ddffb412eb1e4e4c89eac14d5da", null ]
    ] ],
    [ "T_canMsgBufValid", "d7/d0d/can__io_8h.html#a5de86a16b402a91d31a2b147f7119606", [
      [ "CAN_MSG_BUF_DISABLED", "d7/d0d/can__io_8h.html#a5de86a16b402a91d31a2b147f7119606a65a34b38f563b37b2a2cfd095225a7a8", null ],
      [ "CAN_MSG_BUF_ENABLED", "d7/d0d/can__io_8h.html#a5de86a16b402a91d31a2b147f7119606ad759f904bdcff9f8796efca6b899cf27", null ]
    ] ],
    [ "T_canMsgBufWordData", "d7/d0d/can__io_8h.html#af48ddeda22793c3ef034bfee7bb2024c", [
      [ "CAN_MB_WORD_0", "d7/d0d/can__io_8h.html#af48ddeda22793c3ef034bfee7bb2024cac34245a5e40db4363c54d39d80d33aeb", null ],
      [ "CAN_MB_WORD_1", "d7/d0d/can__io_8h.html#af48ddeda22793c3ef034bfee7bb2024ca479f64e59b478f15890c436aff1c8645", null ],
      [ "CAN_MB_WORD_2", "d7/d0d/can__io_8h.html#af48ddeda22793c3ef034bfee7bb2024ca7c9f72da69ce004373d9efd2a525e203", null ],
      [ "CAN_MB_WORD_3", "d7/d0d/can__io_8h.html#af48ddeda22793c3ef034bfee7bb2024ca24201fdfbb837dfcf9d4dd54227aa27c", null ],
      [ "CAN_MB_WORD_SIZE", "d7/d0d/can__io_8h.html#af48ddeda22793c3ef034bfee7bb2024ca15409c342823e100d0f39c40b3d2a768", null ]
    ] ],
    [ "T_canNS", "d7/d0d/can__io_8h.html#ab2255f23e8884d2993dc6f00a8be42ae", [
      [ "CAN_ERR_ACTIVE", "d7/d0d/can__io_8h.html#ab2255f23e8884d2993dc6f00a8be42aeaafaedf32aa99fa7672f4d0899b363143", null ],
      [ "CAN_ERR_WARNING", "d7/d0d/can__io_8h.html#ab2255f23e8884d2993dc6f00a8be42aead12060291794d46c1e08f385a91990a9", null ],
      [ "CAN_ERR_PASSIVE", "d7/d0d/can__io_8h.html#ab2255f23e8884d2993dc6f00a8be42aeafdedc5b0dbc2443446756091859c07b3", null ],
      [ "CAN_BUS_OFF", "d7/d0d/can__io_8h.html#ab2255f23e8884d2993dc6f00a8be42aeac8cadafe6fe9deff8a983e28190042b1", null ]
    ] ],
    [ "T_canNSTransition", "d7/d0d/can__io_8h.html#a2f8cc2eb5a0e24d239d4616e6bebd7b3", [
      [ "CAN_NS_TRANSIT_NONE", "d7/d0d/can__io_8h.html#a2f8cc2eb5a0e24d239d4616e6bebd7b3a60bb47625fdcb1140617e7331dd2b1f3", null ],
      [ "CAN_NS_TRANSIT_SET", "d7/d0d/can__io_8h.html#a2f8cc2eb5a0e24d239d4616e6bebd7b3a9d8daec79aef6b85652d58fa43e4519a", null ]
    ] ],
    [ "T_canNSTransitionINT", "d7/d0d/can__io_8h.html#a1fb1408170472900532955560faaf9d1", [
      [ "CAN_NS_INT_DISABLED", "d7/d0d/can__io_8h.html#a1fb1408170472900532955560faaf9d1afaab76e8089f0369275c7c71b7bcc823", null ],
      [ "CAN_NS_INT_ENABLED", "d7/d0d/can__io_8h.html#a1fb1408170472900532955560faaf9d1a8da4eae6d033be2c84429c1e2891166a", null ]
    ] ],
    [ "T_canRXComplete", "d7/d0d/can__io_8h.html#a3a3dfaaa038b7d47cafb9d622edd6023", [
      [ "CAN_RX_COMPLETE_NONE", "d7/d0d/can__io_8h.html#a3a3dfaaa038b7d47cafb9d622edd6023aa2c417bad1cf1a650334a72e23f32cd7", null ],
      [ "CAN_RX_COMPLETE_SET", "d7/d0d/can__io_8h.html#a3a3dfaaa038b7d47cafb9d622edd6023a9556117422cdf579b71e5cc22879ee32", null ]
    ] ],
    [ "T_canRXINT", "d7/d0d/can__io_8h.html#a6d072b795ea46d833d07c0802d19f5ed", [
      [ "CAN_RX_INT_DISABLED", "d7/d0d/can__io_8h.html#a6d072b795ea46d833d07c0802d19f5eda7f06df495ffe4bb43dc1f2493619ede5", null ],
      [ "CAN_RX_INT_ENABLED", "d7/d0d/can__io_8h.html#a6d072b795ea46d833d07c0802d19f5eda9f0dbc5342bada7075f8148cdd723233", null ]
    ] ],
    [ "T_canRXOverrun", "d7/d0d/can__io_8h.html#a8cc77e09746b53ab0c9c49817500545c", [
      [ "CAN_RX_OVERRUN_NONE", "d7/d0d/can__io_8h.html#a8cc77e09746b53ab0c9c49817500545ca6d7aa4f6ef118f196ec8a3e4f5f540e6", null ],
      [ "CAN_RX_OVERRUN_SET", "d7/d0d/can__io_8h.html#a8cc77e09746b53ab0c9c49817500545ca9654ba6d43758da090965522867486ee", null ]
    ] ],
    [ "T_canRXRemoteFrame", "d7/d0d/can__io_8h.html#a6c0b883827b7bd7a7219fd83614eb08e", [
      [ "CAN_RX_REMOTE_FRAME_NONE", "d7/d0d/can__io_8h.html#a6c0b883827b7bd7a7219fd83614eb08ea02b3bef217bf0e7d626ba20d5ea50a11", null ],
      [ "CAN_RX_REMOTE_FRAME_SET", "d7/d0d/can__io_8h.html#a6c0b883827b7bd7a7219fd83614eb08ea9ffab496dce75ce2f2fc09baaa660e89", null ]
    ] ],
    [ "T_canRXTX", "d7/d0d/can__io_8h.html#a08c42b2d30ec7b945753f9a770c5e84f", [
      [ "CAN_RX_NONE", "d7/d0d/can__io_8h.html#a08c42b2d30ec7b945753f9a770c5e84fac1eeff07c27e91608c272f3b7c657879", null ],
      [ "CAN_TX_NONE", "d7/d0d/can__io_8h.html#a08c42b2d30ec7b945753f9a770c5e84fa61baff4a366a222b3df6b079fbd55cef", null ],
      [ "CAN_RX_SET", "d7/d0d/can__io_8h.html#a08c42b2d30ec7b945753f9a770c5e84faba99082707d715150cc81dd60f92166f", null ],
      [ "CAN_TX_SET", "d7/d0d/can__io_8h.html#a08c42b2d30ec7b945753f9a770c5e84fab8446e946add62ee1da1f2a5c64b8b4a", null ]
    ] ],
    [ "T_canTXCancel", "d7/d0d/can__io_8h.html#a9b5e2f5f7d49d9ca6716dab0d0052405", [
      [ "CAN_TCANR_X", "d7/d0d/can__io_8h.html#a9b5e2f5f7d49d9ca6716dab0d0052405a29b13fb9ed3af6eca17ab33f5fad9186", null ],
      [ "CAN_TX_CANCEL", "d7/d0d/can__io_8h.html#a9b5e2f5f7d49d9ca6716dab0d0052405a5fd527ba54e81f48e31c74ec9e2bc432", null ]
    ] ],
    [ "T_canTXComplete", "d7/d0d/can__io_8h.html#a3666097f31f377bcd54bc94b0137228b", [
      [ "CAN_TX_COMPLETE_NONE", "d7/d0d/can__io_8h.html#a3666097f31f377bcd54bc94b0137228ba827b87974f70b4f8120a9bb9f4036db4", null ],
      [ "CAN_TX_COMPLETE_SET", "d7/d0d/can__io_8h.html#a3666097f31f377bcd54bc94b0137228ba237e684e653eaaf443fe3f3a6b5b64d7", null ]
    ] ],
    [ "T_canTXFrame", "d7/d0d/can__io_8h.html#a189979b40faa1177097fc4c6be3c971d", [
      [ "CAN_TX_DATA_FRAME", "d7/d0d/can__io_8h.html#a189979b40faa1177097fc4c6be3c971dabf156fc30e2ffab4b509b568ca908656", null ],
      [ "CAN_TX_REMOTE_FRAME", "d7/d0d/can__io_8h.html#a189979b40faa1177097fc4c6be3c971da78d026990befc705d11ef564a2c7a561", null ]
    ] ],
    [ "T_canTXINT", "d7/d0d/can__io_8h.html#ae021bb0a9c361a52c90c26e768d91659", [
      [ "CAN_TX_INT_DISABLED", "d7/d0d/can__io_8h.html#ae021bb0a9c361a52c90c26e768d91659af1e52c719b340895067191cefc690ef8", null ],
      [ "CAN_TX_INT_ENABLED", "d7/d0d/can__io_8h.html#ae021bb0a9c361a52c90c26e768d91659a92771fb638fbca336fa2da03d8e917ee", null ]
    ] ],
    [ "T_canTXPin", "d7/d0d/can__io_8h.html#af65ed770f45ee9c3db01273cc58feb85", [
      [ "CAN_TX_PIN_GPIO", "d7/d0d/can__io_8h.html#af65ed770f45ee9c3db01273cc58feb85ae7b1d451fac4d44747955100312661c7", null ],
      [ "CAN_TX_PIN_OUTPUT", "d7/d0d/can__io_8h.html#af65ed770f45ee9c3db01273cc58feb85aea2e6d1e61186d8cfeb2d068b7710fee", null ]
    ] ],
    [ "T_canTXRemoteFrameWait", "d7/d0d/can__io_8h.html#a777eccf41023cf277d89f8d138d99c10", [
      [ "CAN_TX_IMMEDIATELY", "d7/d0d/can__io_8h.html#a777eccf41023cf277d89f8d138d99c10a80ba0d8953c083e6742c29617fceb872", null ],
      [ "CAN_TX_WAIT_RF_RECEPTION", "d7/d0d/can__io_8h.html#a777eccf41023cf277d89f8d138d99c10aff3215f38989c84a672d8a58b0044320", null ]
    ] ],
    [ "T_canTXReq", "d7/d0d/can__io_8h.html#aa71e9803ba6c6ca534427d919ff6cdc7", [
      [ "CAN_TX_REQ_NONE", "d7/d0d/can__io_8h.html#aa71e9803ba6c6ca534427d919ff6cdc7a22282945ef81db78298aef97b2bab6d1", null ],
      [ "CAN_TX_REQ_SET", "d7/d0d/can__io_8h.html#aa71e9803ba6c6ca534427d919ff6cdc7af167f68996fee0664b066ac255d3809b", null ]
    ] ]
];