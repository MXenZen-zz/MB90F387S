var union_t__tcr =
[
    [ "bit", "d4/d5b/union_t__tcr.html#a78b5f278eda2a07635c1c333746fcad8", null ],
    [ "byte", "d4/d5b/union_t__tcr.html#a7645220dc283a9ba9a88e448533049d0", null ],
    [ "TC0", "d4/d5b/union_t__tcr.html#a24b63fb35b03a2cd7d7b4890346aeca7", null ],
    [ "TC1", "d4/d5b/union_t__tcr.html#a9c62a4166abe95e5294c01f30931e7e1", null ],
    [ "TC2", "d4/d5b/union_t__tcr.html#ac1ad393660ec8f635fa10d047636a82a", null ],
    [ "TC3", "d4/d5b/union_t__tcr.html#ad43e23001e0adf2854f161c18a2e7d92", null ],
    [ "TC4", "d4/d5b/union_t__tcr.html#a65c629bc0084bc905cf589a04ed4730e", null ],
    [ "TC5", "d4/d5b/union_t__tcr.html#a7a11c713550991ec00e5de84e94e9c08", null ],
    [ "TC6", "d4/d5b/union_t__tcr.html#a8a9edfb19e82f3410caa5008abffbcca", null ],
    [ "TC7", "d4/d5b/union_t__tcr.html#a666900b80ec7f609fec37ed163d82e38", null ]
];