var union_t__elvr =
[
    [ "__pad0__", "d4/d30/union_t__elvr.html#a54cefb5b2d9254930f3420cc59163dc7", null ],
    [ "bit", "d4/d30/union_t__elvr.html#af0b2a91a013a77cf532900f3b542d68f", null ],
    [ "LALB0", "d4/d30/union_t__elvr.html#ac0a795a60f36904e2cbf52b5498fa69d", null ],
    [ "LALB4", "d4/d30/union_t__elvr.html#a4a8b4563cee720729cba5ba3f7d41f3c", null ],
    [ "LALB5", "d4/d30/union_t__elvr.html#a98bc3207ae7ddf4893ddb4e652ffa38d", null ],
    [ "LALB6", "d4/d30/union_t__elvr.html#af5339f9105f432906ad4c1859ace8527", null ],
    [ "LALB7", "d4/d30/union_t__elvr.html#a91fca8335df057f880ab60f89846f8fa", null ],
    [ "word", "d4/d30/union_t__elvr.html#a0c13a9231a7596db72e5e367237bd570", null ]
];