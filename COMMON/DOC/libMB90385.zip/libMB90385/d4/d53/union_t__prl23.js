var union_t__prl23 =
[
    [ "byte", "d4/d53/union_t__prl23.html#a7dc4f99dc01679077b86bb79f270e3b4", null ],
    [ "dword", "d4/d53/union_t__prl23.html#a07971d43c7e49e0594681168ddd054bf", null ],
    [ "PRL2", "d4/d53/union_t__prl23.html#a0eca3a53729e3d3df287a5f91030c63f", null ],
    [ "PRL3", "d4/d53/union_t__prl23.html#a66659bf1eccd0b56735b6deffb8a875d", null ],
    [ "PRLH2", "d4/d53/union_t__prl23.html#a3196c37fb6a022244cfae35ccefa63e6", null ],
    [ "PRLH3", "d4/d53/union_t__prl23.html#a6a8c1d3f4dabc14a82185fb145b03097", null ],
    [ "PRLL2", "d4/d53/union_t__prl23.html#aa89f072907e7f74c3108c458fd5c61e7", null ],
    [ "PRLL3", "d4/d53/union_t__prl23.html#a00ee6a2886120834d2ac2bc3521d6cb9", null ],
    [ "word", "d4/d53/union_t__prl23.html#a78ac02ef18c32231e88802fa5e9e9141", null ]
];