var tbt__io_8h =
[
    [ "ClearTBTCounter", "d4/d35/tbt__io_8h.html#a3b58189196a15b8f9cf9bec0f24f0cea", null ],
    [ "ClearTBTIRQ", "d4/d35/tbt__io_8h.html#a8d9407a51135bf93789c97a63753c0ae", null ],
    [ "DisableTBTInterrupt", "d4/d35/tbt__io_8h.html#a77c2bc65f39ec4a999ba7d83fdb7e4d1", null ],
    [ "EnableTBTInterrupt", "d4/d35/tbt__io_8h.html#a0d8a52bf6726de3638b4d68766ed1ccb", null ],
    [ "GetTBT_TBTC", "d4/d35/tbt__io_8h.html#ae5bb9624f96cb41300c6acbfd0f1fa9e", null ],
    [ "SetTBT_TBTC", "d4/d35/tbt__io_8h.html#aa769709107970b04e44c7c5709ee6c84", null ],
    [ "SetTBTCountClock", "d4/d35/tbt__io_8h.html#a71a0d9c3d926f909b2e7459fb3a934dd", null ],
    [ "TBT_CLEAR_CTR", "d4/d35/tbt__io_8h.html#a505e3e04a91744ab8bb5045ca95f5abc", null ],
    [ "T_tbtINTEnable", "d4/d35/tbt__io_8h.html#a1ab5efa59a5a82c678b64175880a3bf0", [
      [ "TBT_INT_DISABLED", "d4/d35/tbt__io_8h.html#a1ab5efa59a5a82c678b64175880a3bf0a2f75604c80433d0626874ac0023af078", null ],
      [ "TBT_INT_ENABLED", "d4/d35/tbt__io_8h.html#a1ab5efa59a5a82c678b64175880a3bf0a09b24105c93fc632271c9a91e6385941", null ]
    ] ],
    [ "T_tbtInterval", "d4/d35/tbt__io_8h.html#a7c44a4da0b644b3d01321ac150e0ce97", [
      [ "TBT_CLK_2T12", "d4/d35/tbt__io_8h.html#a7c44a4da0b644b3d01321ac150e0ce97ac95419e117feb442260b83c75645abcc", null ],
      [ "TBT_CLK_2T14", "d4/d35/tbt__io_8h.html#a7c44a4da0b644b3d01321ac150e0ce97af2fff25225c2cf1c13eb22b642b9fb41", null ],
      [ "TBT_CLK_2T16", "d4/d35/tbt__io_8h.html#a7c44a4da0b644b3d01321ac150e0ce97a5888d4f6f113a8acd2dda2b48a57212a", null ],
      [ "TBT_CLK_2T19", "d4/d35/tbt__io_8h.html#a7c44a4da0b644b3d01321ac150e0ce97a9abbe9448ffe99b2860991929497a774", null ]
    ] ],
    [ "T_tbtIRQ", "d4/d35/tbt__io_8h.html#a494ff172d4ab8ed84a89dff395915340", [
      [ "TBT_IRQ_CLEARED", "d4/d35/tbt__io_8h.html#a494ff172d4ab8ed84a89dff395915340af2b2ac28f8edbc71bf8e81b73b39a6fb", null ],
      [ "TBT_IRQ_OVERFLOWED", "d4/d35/tbt__io_8h.html#a494ff172d4ab8ed84a89dff395915340afcc7b8728912193695b21ded6484c59b", null ]
    ] ]
];