var union_t__dirr =
[
    [ "__pad0__", "dc/d89/union_t__dirr.html#ada9a56a6a01c66b5ff3a74cf28a080ac", null ],
    [ "bit", "dc/d89/union_t__dirr.html#a60f4991582b8bbff75a95f6cc6cb4546", null ],
    [ "byte", "dc/d89/union_t__dirr.html#af6366e1f21fe91722384a266507bc52f", null ],
    [ "R0", "dc/d89/union_t__dirr.html#af8186054e3bc627ecd4807871339957c", null ]
];