var cpu_8h =
[
    [ "DisableGlobalInterrupt", "dc/da7/cpu_8h.html#a22e670fb1a07f6deec52732c77cecafa", null ],
    [ "EnableGlobalInterrupt", "dc/da7/cpu_8h.html#a62e34bce3a79df75612ea92015035028", null ],
    [ "EnterCriticalSection", "dc/da7/cpu_8h.html#ad57decaef1bf4ea888e56a337d85e93d", null ],
    [ "ExitCriticalSection", "dc/da7/cpu_8h.html#ae48502b9725eddc7800a3fcbc52f05c2", null ],
    [ "NoOperation", "dc/da7/cpu_8h.html#a270d6ca5321a46fe39ef00f02ecc1464", null ],
    [ "RestoreProcessorStatus", "dc/da7/cpu_8h.html#aadc4d5f056f4179d546e5348c185134d", null ],
    [ "ReturnFromInterrupt", "dc/da7/cpu_8h.html#a5fc9a18f00584acf90d5627991255af8", null ],
    [ "SaveProcessorStatus", "dc/da7/cpu_8h.html#aa345a71c7a587ab2e8193bbb138ceb07", null ],
    [ "SetInterruptLevelMask", "dc/da7/cpu_8h.html#adfe843835e38b6ffc6da5db29641f007", null ]
];