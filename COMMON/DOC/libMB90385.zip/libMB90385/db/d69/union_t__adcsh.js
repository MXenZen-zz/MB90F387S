var union_t__adcsh =
[
    [ "__pad0__", "db/d69/union_t__adcsh.html#ac80349fc89370e86b6a12a89949f8336", null ],
    [ "bit", "db/d69/union_t__adcsh.html#af2192bbc5f50c2e474156c2e336532af", null ],
    [ "BUSY", "db/d69/union_t__adcsh.html#a325559fa5e3ae156139fd123462905d4", null ],
    [ "byte", "db/d69/union_t__adcsh.html#a3b3e399c0f60cd80895b2b38a74e1b94", null ],
    [ "INT", "db/d69/union_t__adcsh.html#a70ed43dcdd3e693afd6898de20854295", null ],
    [ "INTE", "db/d69/union_t__adcsh.html#a30971ee74630afa3584c911ff5ba93b5", null ],
    [ "PAUS", "db/d69/union_t__adcsh.html#ae2437d513d6cb0c760953f3b0bb1efb9", null ],
    [ "STRT", "db/d69/union_t__adcsh.html#a4be62d70e4901b13712317753f7c74c5", null ],
    [ "STS", "db/d69/union_t__adcsh.html#a2a55fc8c4ee1b6b0732bcffafc43229f", null ]
];