var wtt__io_8h =
[
    [ "ClearWTTCounter", "db/d1a/wtt__io_8h.html#a242465c4a4a01f3460c93f4854dc90f6", null ],
    [ "ClearWTTIRQ", "db/d1a/wtt__io_8h.html#a788cc7b73b1049e9b6ceb26dc2c6d604", null ],
    [ "DisableWTTInterrupt", "db/d1a/wtt__io_8h.html#ad130dcfd148ee19b738afc9b2e2e6147", null ],
    [ "EnableWTTInterrupt", "db/d1a/wtt__io_8h.html#a18f322e0fd64b136e1141fc4f147d342", null ],
    [ "GetWTT_WTC", "db/d1a/wtt__io_8h.html#aa3355f019df95d72dd2e9ba273c71311", null ],
    [ "IsWTTOscStabilized", "db/d1a/wtt__io_8h.html#a616698659c5910c57afe43fec0a08f5e", null ],
    [ "SetWTT_WTC", "db/d1a/wtt__io_8h.html#a04305be1b2a202e6d03b8ac35c63956b", null ],
    [ "SetWTTCountClock", "db/d1a/wtt__io_8h.html#a42d48fa2028f292da6927af8b34295b3", null ],
    [ "SetWTTWDGClockSource", "db/d1a/wtt__io_8h.html#a1371bcedada5110ad1e296435099a630", null ],
    [ "WTT_CLEAR_CTR", "db/d1a/wtt__io_8h.html#a0ccc945437022e099c098adfe69fbf63", null ],
    [ "T_wttINTEnable", "db/d1a/wtt__io_8h.html#a3d0164c3adb6eb6884a1499d0c28c14d", [
      [ "WTT_INT_DISABLED", "db/d1a/wtt__io_8h.html#a3d0164c3adb6eb6884a1499d0c28c14daeded0dd78b93e6ddb99f69a562880e63", null ],
      [ "WTT_INT_ENABLED", "db/d1a/wtt__io_8h.html#a3d0164c3adb6eb6884a1499d0c28c14dac2d15dd5ed7d888c432cdea8f1f06f1d", null ]
    ] ],
    [ "T_wttInterval", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88", [
      [ "WTT_CLK_2T8", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88a2081e4fb3a55c7bd7985b1d99408d7fd", null ],
      [ "WTT_CLK_2T9", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88a477cf79e140cd8954409b13dced679a4", null ],
      [ "WTT_CLK_2T10", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88a9ce61bd712a1fd08ff9b917fb61c4f96", null ],
      [ "WTT_CLK_2T11", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88aca8da3d2f716119b89e8ae73b3c846fd", null ],
      [ "WTT_CLK_2T12", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88a576095c6b33d4091479bf6464d9fc727", null ],
      [ "WTT_CLK_2T13", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88ab314aef15d364086ce525722b158c0eb", null ],
      [ "WTT_CLK_2T14", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88a47887ff22dd985cadf88de9590084d7d", null ],
      [ "WTT_CLK_2T15", "db/d1a/wtt__io_8h.html#a2ad85b8c493d219cd4c54aa62cfbad88a15021384fc0ef82c84bbe780f9957a33", null ]
    ] ],
    [ "T_wttIRQ", "db/d1a/wtt__io_8h.html#a587840fdeee62a79cbc3af1a3c5f930a", [
      [ "WTT_IRQ_CLEARED", "db/d1a/wtt__io_8h.html#a587840fdeee62a79cbc3af1a3c5f930aa94494d6fa2d584734fa2afd5457c8eda", null ],
      [ "WTT_IRQ_OVERFLOWED", "db/d1a/wtt__io_8h.html#a587840fdeee62a79cbc3af1a3c5f930aa63da00130f5bf4c23dcd4a91d848ec62", null ]
    ] ],
    [ "T_wttOSCStab", "db/d1a/wtt__io_8h.html#a5ea7b8887ee5f7965f1c396a3f39c13b", [
      [ "WTT_OSC_STAB_WAIT", "db/d1a/wtt__io_8h.html#a5ea7b8887ee5f7965f1c396a3f39c13ba20d5f7b0a49b1797f5cd0c2864237b0b", null ],
      [ "WTT_OSC_STAB_WAIT_END", "db/d1a/wtt__io_8h.html#a5ea7b8887ee5f7965f1c396a3f39c13ba8ccd92bf13aec6f9f179d6cb133a0840", null ]
    ] ],
    [ "T_wttWDTClkSrc", "db/d1a/wtt__io_8h.html#a489296ea9837f7cd1ad1b552a84688cc", [
      [ "WTT_WDG_CLKSRC_WTC", "db/d1a/wtt__io_8h.html#a489296ea9837f7cd1ad1b552a84688ccaf82fc3813e65f15d24a732cb87a450d2", null ],
      [ "WTT_WDG_CLKSRC_TBT", "db/d1a/wtt__io_8h.html#a489296ea9837f7cd1ad1b552a84688cca816af1bb3f4429e4b5de91040351c1ed", null ]
    ] ]
];