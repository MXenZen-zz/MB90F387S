var dio_8h =
[
    [ "T_ioBitPin", "db/dd8/dio_8h.html#a13793207f2a9aa3b7d60b35c92daab9d", null ],
    [ "T_pinGroupSize", "db/dd8/dio_8h.html#ac69b9dc76afc34508050b89ceec003e8", null ],
    [ "T_shiftData", "db/dd8/dio_8h.html#a9014005249742745b0e76b9bcdbf29e4", null ],
    [ "T_swDebBuffer", "db/dd8/dio_8h.html#a608ad0614e6006f4973c3862eaac512b", null ],
    [ "T_swDebSampCnt", "db/dd8/dio_8h.html#adc9db2232d9781c630d2cb6c5f2159cd", null ],
    [ "pinModeDigital", "db/dd8/dio_8h.html#a4e6486b6389d3e6a76c05b8f885bf167", null ],
    [ "pinModeDigitalGroup", "db/dd8/dio_8h.html#a0af332301d37e22fee3fd93fd9b86a07", null ],
    [ "readDebouncedNegTrig", "db/dd8/dio_8h.html#a39cac509d22b412373a81664aabbd910", null ],
    [ "readDebouncedPosTrig", "db/dd8/dio_8h.html#aee2093af254affe283896899f3e19f6e", null ],
    [ "readDigital", "db/dd8/dio_8h.html#a5ac751531f357e70c74044b87a68ffbb", null ],
    [ "readDigitalGroup", "db/dd8/dio_8h.html#a3b12d540478d7b51687034203ef8c21e", null ],
    [ "shiftIn", "db/dd8/dio_8h.html#a66c12c8b1437ab13756fca0cddc44cce", null ],
    [ "shiftOut", "db/dd8/dio_8h.html#a76ced26f6d8add5fea70970f9b5f1364", null ],
    [ "writeDigital", "db/dd8/dio_8h.html#ac2bd977b48d47406efdf77e90f598411", null ],
    [ "writeDigitalGroup", "db/dd8/dio_8h.html#acb99abaa1a536d77128c4b6b78fd6f15", null ]
];