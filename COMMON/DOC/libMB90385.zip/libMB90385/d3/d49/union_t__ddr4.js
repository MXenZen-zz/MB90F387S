var union_t__ddr4 =
[
    [ "bit", "d3/d49/union_t__ddr4.html#a372b90e3f9d65c2836c8c879bf526f8e", null ],
    [ "byte", "d3/d49/union_t__ddr4.html#aef9eb0b0c9fdb6ae951ba12655955559", null ],
    [ "D40", "d3/d49/union_t__ddr4.html#af275cc46701318257a6310a0d3f11097", null ],
    [ "D41", "d3/d49/union_t__ddr4.html#a258560f42b24be303a5ffb7369d2fc99", null ],
    [ "D42", "d3/d49/union_t__ddr4.html#a9b8078acee1735028464ed1e8bf2e156", null ],
    [ "D43", "d3/d49/union_t__ddr4.html#aa6b374787ebff87b62fbf4c04bffd894", null ],
    [ "D44", "d3/d49/union_t__ddr4.html#ae4a7b13d34112877a643457effb12a1c", null ],
    [ "D45", "d3/d49/union_t__ddr4.html#acf4d605892a19acb6e473a14ae07f76d", null ],
    [ "D46", "d3/d49/union_t__ddr4.html#a46e656e4fe1ad2618985a396e6ca0c77", null ],
    [ "D47", "d3/d49/union_t__ddr4.html#a74f167d27eff811729ec87f0241b0733", null ]
];