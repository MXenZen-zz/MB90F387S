var ser__io_8h =
[
    [ "ClearSERReceiveErrorFlag", "d3/d46/ser__io_8h.html#aad7fc59fd9fd1f7bebac0afc1cc8251b", null ],
    [ "DisableSERClockPin", "d3/d46/ser__io_8h.html#a452e5556d386c0ef1079fe93bf629fdc", null ],
    [ "DisableSERDataOutputPin", "d3/d46/ser__io_8h.html#aced584422102396ccc00f3a110dc6c86", null ],
    [ "DisableSERReceive", "d3/d46/ser__io_8h.html#a30e5bd5aca21b3b32b4514194c0ba55b", null ],
    [ "DisableSERReceiveInterrupt", "d3/d46/ser__io_8h.html#a71ee287d6d0a7bc2b5228a712bec122e", null ],
    [ "DisableSERTransmit", "d3/d46/ser__io_8h.html#ac3042e3871115202e82c7eec019e8665", null ],
    [ "DisableSERTransmitInterrupt", "d3/d46/ser__io_8h.html#aacea2b650adf9caca3a676779da74039", null ],
    [ "EnableSERClockPin", "d3/d46/ser__io_8h.html#afb8e1cd0c7bf06bb45a4c95230d07894", null ],
    [ "EnableSERCommPrescaler", "d3/d46/ser__io_8h.html#a70a68a9d8895e9869abdf849ec8ee1be", null ],
    [ "EnableSERDataOutputPin", "d3/d46/ser__io_8h.html#ac48c29f958e1591dc1542e46b7340c81", null ],
    [ "EnableSERReceive", "d3/d46/ser__io_8h.html#aedcfa4b54e7d2f74153bc6d2c436ef38", null ],
    [ "EnableSERReceiveInterrupt", "d3/d46/ser__io_8h.html#ac683a280c04f1bc7ba1d5a85b1ebe3ba", null ],
    [ "EnableSERTransmit", "d3/d46/ser__io_8h.html#a80ef5772d74e4c3917796be1ccf14c5d", null ],
    [ "EnableSERTransmitInterrupt", "d3/d46/ser__io_8h.html#a19e3d23b5c0f6fab22921fee4ad025c6", null ],
    [ "GetSER_CDCR", "d3/d46/ser__io_8h.html#ab4c5c5945edaa1abb05503da620de150", null ],
    [ "GetSER_SCR", "d3/d46/ser__io_8h.html#afe9312f09afb187493677ff8443668ed", null ],
    [ "GetSER_SIDR", "d3/d46/ser__io_8h.html#ab34ee56c7acc7dd7741df0bc1ccd46ec", null ],
    [ "GetSER_SMR", "d3/d46/ser__io_8h.html#a36b35aa175256c5970bb9ca86b05d8e0", null ],
    [ "GetSER_SSR", "d3/d46/ser__io_8h.html#a4dd1630b75995bc3a6bb50e96b78d101", null ],
    [ "InitializeSERRegisters", "d3/d46/ser__io_8h.html#afe38ccd21d7c74e3056167078305583d", null ],
    [ "IsSERFramingError", "d3/d46/ser__io_8h.html#a7e81a41c14ca9767c54050fecdc6dcc4", null ],
    [ "IsSEROverrunError", "d3/d46/ser__io_8h.html#a1c183be973ecaa687a7c02955ca79ee7", null ],
    [ "IsSERParityError", "d3/d46/ser__io_8h.html#a03b078f7b683de70e66376d7567d7562", null ],
    [ "IsSERReceiveDataRegFull", "d3/d46/ser__io_8h.html#ad02316e2138f29b6e0ad57a75148c3ce", null ],
    [ "IsSERTransmitDataRegEmpty", "d3/d46/ser__io_8h.html#a4732e905d73fcdfd7e38451fac8cd9f1", null ],
    [ "SetSER1bitStopLength", "d3/d46/ser__io_8h.html#a87d4f7838886d8eae997101903992044", null ],
    [ "SetSER2bitStopLength", "d3/d46/ser__io_8h.html#a6e7ed2b3bed7b8398f68ed2da68c7a37", null ],
    [ "SetSER7bitDataLength", "d3/d46/ser__io_8h.html#a9d9136c7d8c799188b68168706aeace9", null ],
    [ "SetSER8bitDataLength", "d3/d46/ser__io_8h.html#ad280478833ba915db71b5ba147313f6e", null ],
    [ "SetSER_CDCR", "d3/d46/ser__io_8h.html#ae0e1afadf7a55521d36d5742b30eb14f", null ],
    [ "SetSER_SCR", "d3/d46/ser__io_8h.html#a85dee60e2324db94ab298dc1c85f0a18", null ],
    [ "SetSER_SMR", "d3/d46/ser__io_8h.html#a6703a6437dee8764f753afaa8fa33902", null ],
    [ "SetSER_SODR", "d3/d46/ser__io_8h.html#a85bd0e867d713fcf8290342511a93b4a", null ],
    [ "SetSER_SSR", "d3/d46/ser__io_8h.html#af6edde85ea5494976bce7142a23af182", null ],
    [ "SetSERAsAddressFrame", "d3/d46/ser__io_8h.html#a6ef908b6e3559d857d407c6e2ff7d355", null ],
    [ "SetSERAsDataFrame", "d3/d46/ser__io_8h.html#a9f02771c7b865902a30432e1aca9303b", null ],
    [ "SetSERClockInputSource", "d3/d46/ser__io_8h.html#a38d3aadb515c0249c031a4de983aecce", null ],
    [ "SetSEREvenParity", "d3/d46/ser__io_8h.html#ae9d865736787c184f90f84d7c5c6dff9", null ],
    [ "SetSERNoParity", "d3/d46/ser__io_8h.html#a317bdc657a520ebd3bfd7ab5b7685481", null ],
    [ "SetSEROddParity", "d3/d46/ser__io_8h.html#a539c0b1aa7956016f860564ede91a3d1", null ],
    [ "SetSEROperationMode", "d3/d46/ser__io_8h.html#acb9117a599a9ef93934c2e0ad7d69162", null ],
    [ "StopSERCommPrescaler", "d3/d46/ser__io_8h.html#ab059459dc0f2423bd948908889b5cf00", null ],
    [ "TransferSERLSBFirst", "d3/d46/ser__io_8h.html#aae3dc26181ab354462631d301fb96ee2", null ],
    [ "TransferSERMSBFirst", "d3/d46/ser__io_8h.html#a2911c0c9a1160afa6e74d85ef78a54fd", null ],
    [ "T_serBaud", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844a", [
      [ "SER_BAUD_ASYNC_76923", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa90f9380bce116d9af7a7a7a617e6b35b", null ],
      [ "SER_BAUD_SYNC_2000K", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa31a3eb40c9cac74e43d9dd0542a830fd", null ],
      [ "SER_BAUD_ASYNC_38461", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa0441f97304c067ba24ae9989ce997282", null ],
      [ "SER_BAUD_SYNC_1000K", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa96af256108d7097dddd44033ab1a6a49", null ],
      [ "SER_BAUD_ASYNC_19230", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa00df456b9befc46b95391c402423ef6d", null ],
      [ "SER_BAUD_SYNC_500K", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa36a3b863d8bbb876753fde7b7eccbb7f", null ],
      [ "SER_BAUD_ASYNC_9615", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aac3f4cdd3c46985642852b2ff42e08b99", null ],
      [ "SER_BAUD_SYNC_250K", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aaa129c7b9a04bbe0a0288271ede138c01", null ],
      [ "SER_BAUD_ASYNC_500K", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa2512469c4b10d37d86c45b1c6fa7d36c", null ],
      [ "SER_BAUD_SYNC_125K", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa0dc5f428e5094005f75e2cccd5a5bf26", null ],
      [ "SER_BAUD_ASYNC_250K", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aaba4acfd06be374900c3a48072d945c8f", null ],
      [ "SER_BAUD_SYNC_62500", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aac60cd8cc4e2af97cb0e2187a8e55924f", null ],
      [ "SER_BAUD_INTERNAL", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa6fe1ef27995747626d04bfb9c3762d55", null ],
      [ "SER_BAUD_EXTERNAL", "d3/d46/ser__io_8h.html#ad8e2668d86b75e3c7e96ce6d62eb844aa1dfa331e453315e4e70da9d5a20c5269", null ]
    ] ],
    [ "T_serDataLength", "d3/d46/ser__io_8h.html#a5019b0a09943c5aa309631581273519a", [
      [ "SER_DL_7BITS", "d3/d46/ser__io_8h.html#a5019b0a09943c5aa309631581273519aab6d283af422ae7ca5e0e664505180ddc", null ],
      [ "SER_DL_8BITS", "d3/d46/ser__io_8h.html#a5019b0a09943c5aa309631581273519aa665cb0404f03b9eaadfaf86f79e8f87d", null ]
    ] ],
    [ "T_serDirection", "d3/d46/ser__io_8h.html#ae14dfecefd39f06b0482ef2e2a300ae6", [
      [ "SER_LSB_FIRST", "d3/d46/ser__io_8h.html#ae14dfecefd39f06b0482ef2e2a300ae6a67876ced8ef2ee7add42a657dc2d59c1", null ],
      [ "SER_MSB_FIRST", "d3/d46/ser__io_8h.html#ae14dfecefd39f06b0482ef2e2a300ae6a3c254460b8a8be70f88369d5c97fc6de", null ]
    ] ],
    [ "T_serError", "d3/d46/ser__io_8h.html#af79cf4514b3afa93511d8a5765d60b45", [
      [ "SER_ERR_NONE", "d3/d46/ser__io_8h.html#af79cf4514b3afa93511d8a5765d60b45a1de729ede99eb2fe0eefff3d9616a1c0", null ],
      [ "SER_ERR_CLEAR", "d3/d46/ser__io_8h.html#af79cf4514b3afa93511d8a5765d60b45a1b89b00573baee31f3e59ed46de87bf6", null ],
      [ "SER_ERR_FRAME", "d3/d46/ser__io_8h.html#af79cf4514b3afa93511d8a5765d60b45aca1774e089949e6333fd86573c8d6f37", null ],
      [ "SER_ERR_OVERRUN", "d3/d46/ser__io_8h.html#af79cf4514b3afa93511d8a5765d60b45ab568ce4f8fbd8c4bed930c6f52f57a0c", null ],
      [ "SER_ERR_PARITY", "d3/d46/ser__io_8h.html#af79cf4514b3afa93511d8a5765d60b45ab88a8e240491db84788d58fb34e10bb1", null ]
    ] ],
    [ "T_serFrameType", "d3/d46/ser__io_8h.html#a4fea55fb5d4b172cdd58247d94bfc7f1", [
      [ "SER_FRAME_DATA", "d3/d46/ser__io_8h.html#a4fea55fb5d4b172cdd58247d94bfc7f1af64dd39df56557e4ac6f8bb464c5a587", null ],
      [ "SER_FRAME_ADDRESS", "d3/d46/ser__io_8h.html#a4fea55fb5d4b172cdd58247d94bfc7f1a828e3858a2727385a0667afce2cb5513", null ]
    ] ],
    [ "T_serINT", "d3/d46/ser__io_8h.html#a15ceaf6481e8765bce469d26378e6642", [
      [ "SER_INT_DISABLED", "d3/d46/ser__io_8h.html#a15ceaf6481e8765bce469d26378e6642a8e2986392643a607951e2e952a7ee4bc", null ],
      [ "SER_INT_ENABLED", "d3/d46/ser__io_8h.html#a15ceaf6481e8765bce469d26378e6642a9b477364c484a3d35ae34914b6183cac", null ]
    ] ],
    [ "T_serMode", "d3/d46/ser__io_8h.html#a51ee6941909b36d7326b4275454ceba3", [
      [ "SER_MODE_ASYNC", "d3/d46/ser__io_8h.html#a51ee6941909b36d7326b4275454ceba3a9b54e5af75c4c022322d5ce5fddbd7a4", null ],
      [ "SER_MODE_ASYNC_MULTI", "d3/d46/ser__io_8h.html#a51ee6941909b36d7326b4275454ceba3aa6172d0ab2cd2f480db1c25c6a47727a", null ],
      [ "SER_MODE_SYNC_CLK", "d3/d46/ser__io_8h.html#a51ee6941909b36d7326b4275454ceba3adaef76ff1de09f3e7146c36ff98bce64", null ],
      [ "SER_MODE_DISABLED", "d3/d46/ser__io_8h.html#a51ee6941909b36d7326b4275454ceba3a4333cf8257297e0b1e4a6e3ca2e5fead", null ]
    ] ],
    [ "T_serParity", "d3/d46/ser__io_8h.html#a1ae88390b688e946568fe7f0fc3e3c75", [
      [ "SER_PARITY_EVEN", "d3/d46/ser__io_8h.html#a1ae88390b688e946568fe7f0fc3e3c75ae82193f0e05d233d120a06fa3ff4f985", null ],
      [ "SER_PARITY_ODD", "d3/d46/ser__io_8h.html#a1ae88390b688e946568fe7f0fc3e3c75aa0655116c10674e1e39d2e1b5696f936", null ]
    ] ],
    [ "T_serParityEnable", "d3/d46/ser__io_8h.html#ab732fe66687f69413d895d07a4ea2731", [
      [ "SER_PARITY_NONE", "d3/d46/ser__io_8h.html#ab732fe66687f69413d895d07a4ea2731a4c44795547b94ae05165a0112a78feca", null ],
      [ "SER_PARITY_SET", "d3/d46/ser__io_8h.html#ab732fe66687f69413d895d07a4ea2731aab57a5352415d52b364405005862437e", null ]
    ] ],
    [ "T_serPin", "d3/d46/ser__io_8h.html#a09e0fd5eea45447f7e4fecb13ff011ac", [
      [ "SER_PIN_GPIO", "d3/d46/ser__io_8h.html#a09e0fd5eea45447f7e4fecb13ff011aca8eb0d09a122bd4edefa6178cf43bf061", null ],
      [ "SER_PIN_OUTPUT", "d3/d46/ser__io_8h.html#a09e0fd5eea45447f7e4fecb13ff011aca1f0d229c27f234fe435aad4ab57792b8", null ]
    ] ],
    [ "T_serPrescaleControl", "d3/d46/ser__io_8h.html#ac4e30d51a21031842a0ec0bdb4971f2d", [
      [ "SER_PRESCALE_STOPPED", "d3/d46/ser__io_8h.html#ac4e30d51a21031842a0ec0bdb4971f2da6785393816d9fd47b9281728dd320080", null ],
      [ "SER_PRESCALE_ENABLED", "d3/d46/ser__io_8h.html#ac4e30d51a21031842a0ec0bdb4971f2da09046a36573809073f3ef7c370a051ae", null ]
    ] ],
    [ "T_serPrescaler", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390c", [
      [ "SER_PRESCALE_DIV_1", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390cac4b78f427ccbbe6c61c2d2ac707c1187", null ],
      [ "SER_PRESCALE_DIV_2", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390ca40527027edce13e1a84649680c92b1b7", null ],
      [ "SER_PRESCALE_DIV_3", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390ca52b3d1fd7150fe8a33f4ab2333c71cb0", null ],
      [ "SER_PRESCALE_DIV_4", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390ca12fca101e734be740f59d9b502635d6f", null ],
      [ "SER_PRESCALE_DIV_5", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390caebfbb3ba00909f321e20cf2fa4fa448b", null ],
      [ "SER_PRESCALE_DIV_6", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390cabafb147d7c950fad9a40519721045901", null ],
      [ "SER_PRESCALE_DIV_7", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390caa618ae1347991bd0b0a59bf787d172a3", null ],
      [ "SER_PRESCALE_DIV_8", "d3/d46/ser__io_8h.html#a6effa70962030ebaa06d17aee381390ca7f9a7eb13ee145ddc3eda7623f7d40e8", null ]
    ] ],
    [ "T_serRXLoadTXWrite", "d3/d46/ser__io_8h.html#a4aef11b2c2d9a2c59aeea8d7bd1fd893", [
      [ "SER_TX_WITHDATA", "d3/d46/ser__io_8h.html#a4aef11b2c2d9a2c59aeea8d7bd1fd893a438a3fb2e1834db4721cc06225a8e6de", null ],
      [ "SER_RX_NODATA", "d3/d46/ser__io_8h.html#a4aef11b2c2d9a2c59aeea8d7bd1fd893a33f9e5d2c4f8e05fa43d3b2f6987d046", null ],
      [ "SER_TX_NODATA", "d3/d46/ser__io_8h.html#a4aef11b2c2d9a2c59aeea8d7bd1fd893aec319dc4c38179801e5287cf0d623cb9", null ],
      [ "SER_RX_WITHDATA", "d3/d46/ser__io_8h.html#a4aef11b2c2d9a2c59aeea8d7bd1fd893a6b0c9956157eeadf0f2ef7cce8184b25", null ]
    ] ],
    [ "T_serRXTXEnable", "d3/d46/ser__io_8h.html#a438a8fb410431f913ec95e8041149574", [
      [ "SER_DISABLED", "d3/d46/ser__io_8h.html#a438a8fb410431f913ec95e8041149574af78a1fe0b498a20a3c234f367fb5cfed", null ],
      [ "SER_ENABLED", "d3/d46/ser__io_8h.html#a438a8fb410431f913ec95e8041149574a2a4890ca2cd9b4e133cd0a74ce4dc283", null ]
    ] ],
    [ "T_serStopLength", "d3/d46/ser__io_8h.html#af288f10907494637cdb1e3276c633f4f", [
      [ "SER_SL_1BIT", "d3/d46/ser__io_8h.html#af288f10907494637cdb1e3276c633f4faf231f0fffb471e52a0e463fe913b5c4b", null ],
      [ "SER_SL_2BITS", "d3/d46/ser__io_8h.html#af288f10907494637cdb1e3276c633f4fad8abc5733723855fbfb72940d15a07c2", null ]
    ] ]
];