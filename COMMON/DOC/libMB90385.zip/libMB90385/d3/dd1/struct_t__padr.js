var struct_t__padr =
[
    [ "HIGH", "d3/dd1/struct_t__padr.html#a803446ba517de56582c55ddf12887986", null ],
    [ "LOW", "d3/dd1/struct_t__padr.html#a79ec78833d07f53e3eae89f564338822", null ],
    [ "MID", "d3/dd1/struct_t__padr.html#a5da8d2d3a1f205f9d900ac5b3a2645a9", null ]
];