var globals_vars =
[
    [ "a", "globals_vars.html", null ],
    [ "i", "globals_vars_i.html", null ],
    [ "p", "globals_vars_p.html", null ],
    [ "r", "globals_vars_r.html", null ]
];